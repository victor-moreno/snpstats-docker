#Log function
cat.log <- function(cputime,nsub,nsnps,num.status)
{
	t <- unlist(strsplit(format(Sys.time())," "));
	cat(ip,tmp,t[1],t[2],cputime,nsub,nsnps,num.status,descr.covdesc,descr.allfreq,
		descr.hweq,descr.snpassoc,interact,descr.ldd,descr.lddp,descr.ldr,descr.ldpval,
		descr.haplofreq,hapassoc,hap.interact,descr.subpop,file=paste(log.path,"snpstats_log",sep=""),sep="\t",append=TRUE);
	cat("\n",file=paste(log.path,"snpstats_log",sep=""),append=TRUE);
}

#Error log function
cat.log.err <- function(err)
{
	t <- unlist(strsplit(format(Sys.time())," "));
	cat(ip,tmp,t[1],t[2],err,file=paste(log.path,"snpstats_log_err",sep=""),sep="\t",append=TRUE);
	cat("\n",file=paste(log.path,"snpstats_log_err",sep=""),append=TRUE);

	sink(paste(docroot,"/",tmp.html.path,tmp,"/snp.html",sep=""),append=TRUE);
	cat("\nSome error ocurred:<br><br>");
	cat(err);
	cat("<br><br>");
	sink();
}

#Error message printer (for the user's information)
cat.error.msg <- function()
{
	sink(paste(docroot,"/",tmp.html.path,tmp,"/snp.html",sep=""),append=TRUE);
	cat("\nExecution halted due to an internal error. Bug has been automatically reported to the software administrator for appropiate revision.");
	sink();
}

#Auxiliary function which reverses a string
revstr <- function(x)
{
	sapply(lapply(strsplit(x, NULL), rev), paste, collapse="");
}

reorder.geno.matrix <- function(geno.matrix,ref)
{
    if ("NA" %in% rownames(geno.matrix))
    {
        nas <- geno.matrix[rownames(geno.matrix)=="NA",];
        res <- geno.matrix[rownames(geno.matrix)!="NA",];
        res <- res[ref,];
        res <- rbind(res,nas);
        rownames(res)[length(rownames(res))] <- "NA";
    }
    else
    {
        res <- geno.matrix[ref,];
    }

    res;
}

print.snp.summary <- function(snp,ref,st,st.name,num.status,m.cov,keep.snp,keep.cov,snp.name)
{
	#We get the summary of the SNP
	#snp.geno <- genotype(snp[!is.na(st)]);
	
	#print(length(snp));
	
	#print(snp);
	snp.geno <- genotype(snp);
	snp.sum <- summary(snp.geno);

	cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif">');
	cat("<b>Percentage of typed samples: </b>",snp.sum$n.typed,"/",snp.sum$n.total," (",round(snp.sum$n.typed/snp.sum$n.total * 100,2),"%)",sep="");
	cat('</font>');
	cat('<p></p>');

    if (num.status==0) #Categorical response variable
    {
		#Allele frequencies
		if (descr.allfreq==1)
		{
			#Perform subpopulation analysis
			if (descr.subpop==1)
			{
	            cat('<table border>');
	            cat('<tr bgcolor="#C0C0C0"><td colspan=',3+(length(levels(st))*2),'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' allele frequencies (n=',length(snp[keep.snp]),')</b></center></font></td></tr>',sep="");

	            cat('<tr><td></td><td colspan=2><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>All subjects</center></b></font></td>');

	            i <- 1;
	            while (i <= length(levels(st)))
	            {
	                cat('<td colspan=2><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>',st.name,"=",levels(st)[i],"</center></b></font></td>",sep="");
	                i <- i + 1;
	            }

	            cat("</tr>");
	            cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Allele</center></b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Count</center></b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Proportion</center></b></font></td>');

	            i <- 1;
	            while (i <= length(levels(st)))
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Count</center></b></font></td>');
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Proportion</center></b></font></td>');
	                i <- i + 1;
	            }
	
	            cat("</tr>");
	
	            j <- 1;
	            while (j <= snp.sum$nallele) #For every allele (not including NAs)
	            {
	                #First we display the information about the complete population
	                cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(snp.sum$allele.freq)[j],"</font></td>",sep="");
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',snp.sum$allele.freq[j,1],"</font></td>",sep="");
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(snp.sum$allele.freq[j,2],2),"</font></td>",sep="");
	
	                i <- 1;
	                while (i <= length(levels(st)))
	                {
	                    aux <- summary(snp.geno[st==levels(st)[i]]);
	                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',aux$allele.freq[j,1],'</font></td>',sep="");
	                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(aux$allele.freq[j,2],2),"</font></td>",sep="");
	                    i <- i + 1;
	                }
	                cat("</tr>");
	                j <- j + 1;
	            }
	            cat("</table><p></p>");
	        }
	        else #Do not perform subpopulation analysis
	        {
				cat("<table border>");
				cat('<tr bgcolor="#C0C0C0"><td colspan=3><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' allele frequencies (n=',length(snp[keep.snp]),')</b></center></font></td></tr>',sep="");

				cat("<tr>");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Allele</b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Count</b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Proportion</b></font></td>');
				cat("</tr>");

	            i <- 1;
	            while (i <= snp.sum$nallele) #For every allele (not including NAs)
	            {
	                cat("<tr>");
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(snp.sum$allele.freq)[i],"</td>",sep="");
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',snp.sum$allele.freq[i,1],"</td>",sep="");
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(snp.sum$allele.freq[i,2],2),"</td>",sep="");
	                cat("</tr>");
	                i <- i + 1;
	            }

	            cat("</table><p></p>");
	        }
	    }

	    #Genotype frequencies    
	    if (descr.genofreq==1)
	    {
	        if (descr.subpop==1)
	        {
		        #First we reorder the genotypes
				if (length(ref)>1)
				{
		            snp.sum$genotype.freq <- reorder.geno.matrix(snp.sum$genotype.freq,ref);
		        }
	
	            cat("<table border>");
	            cat('<tr bgcolor="#C0C0C0"><td colspan=',3+(length(levels(st))*2),'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' genotype frequencies (n=',length(snp),')</b></center></font></td></tr>',sep="");
	            cat('<tr><td></td><td colspan=2><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>All subjects</center></b></font></td>');

	            i <- 1;
	            while (i <= length(levels(st)))
	            {
	                cat('<td colspan=2><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>',st.name,"=",levels(st)[i],'</center></b></font></td>',sep="");
	                i <- i + 1;
	            }

	            cat("</tr>");
	            cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Genotype</center></b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Count</center></b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Proportion</center></b></font></td>');

	            i <- 1;
	            while (i <= length(levels(st)))
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Count</center></b></font></td>');
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><center>Proportion</center></b></font></td>');
	                i <- i + 1;
	            }

	            cat("</tr>");

	            j <- 1;
	            while (j <= nrow(snp.sum$genotype.freq)) #For every genotype (including NAs)
	            {
	                #First we display the information about the complete population
	                cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(snp.sum$genotype.freq)[j],'</font></td>',sep="");

	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',snp.sum$genotype.freq[j,1],'</font></td>',sep="");
	                if (is.na(snp.sum$genotype.freq[j,2]))
	                {
	                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>');
	                }
	                else
	                {
	                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(snp.sum$genotype.freq[j,2],2),'</font></td>',sep="");
	                }

	                i <- 1;
	                while (i <= length(levels(st)))
	                {
	                    aux <- summary(snp.geno[(st==levels(st)[i]) & (!is.na(st))]);
						if (length(ref)>1) #Non-monomorphic SNP
						{
			                aux <- reorder.geno.matrix(aux$genotype.freq,ref);

							if (j <= nrow(aux))
							{
			                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',aux[j,1],'</font></td>',sep="");
			                    if (is.na(aux[j,2]))
			                    {
									cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>');
			                    }
			                    else
			                    {
									cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(aux[j,2],2),'</font></td>',sep="");
			                    }
			                }
			                else
			                {
								cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">0</font></td>',sep="");
								cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>');
			                }
			            }
			            else
			            {
							if (rownames(snp.sum$genotype.freq)[j]=="NA")
							{
				                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(st[(!is.na(st)) & (is.na(snp)) & (st==levels(st)[i])]),'</font></td>',sep="");
				                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>',sep="");
				            }
				            else
				            {
				                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(st[(!is.na(st)) & (st==levels(st)[i])]),'</font></td>',sep="");
				                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">1</font></td>',sep="");
				            }
			            }
	                    i <- i + 1;
	                }
	                cat("</tr>");
	                j <- j + 1;
	            }
	            cat("</table><p></p>");
	        }
	        else
	        {
	            if (length(ref)>1)
	            {
	            	snp.sum$genotype.freq <- reorder.geno.matrix(snp.sum$genotype.freq,ref);
	           	}

	            cat("<table border>");
	            cat('<tr bgcolor="#C0C0C0"><td colspan=3><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' genotype frequencies (n=',length(snp),')</b></center></font></td></tr>',sep="");
	            cat("<tr>");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Genotype</b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Count</b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Proportion</b></font></td>');
	            cat("</tr>");
	
	            i <- 1;
	            while (i <= nrow(snp.sum$genotype.freq)) #For every genotype (including NAs)
	            {
	                cat("<tr>");
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(snp.sum$genotype.freq)[i],'</font></td>',sep="");
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',snp.sum$genotype.freq[i,1],'</font></td>',sep="");
	                if (is.na(snp.sum$genotype.freq[i,2]))
	                {
	                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>');
	                }
	                else
	                {
	                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(snp.sum$genotype.freq[i,2],2),'</font></td>',sep="");
	                }
	                cat("</tr>");
	                i <- i + 1;
	            }
	            cat("</table><p></p>");
	        }
	    }
	
	    #Hardy-Weinberg equilibrium
	    if (descr.hweq==1)
	    {
			if (length(ref)>1)
			{
		        hw.snp <- HWE.exact(snp.geno);
		
		        cat("<table border>");
		        cat('<tr bgcolor="#C0C0C0"><td colspan=7><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' exact test for Hardy-Weinberg equilibrium (n=',length(snp[keep.snp]),')</b></center></font></td></tr>',sep="");
		        cat('<tr><td></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N11</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N12</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N22</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N1</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N2</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">P-value</font></b></td></tr>');
	
		        cat('<tr>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">All subjects</font></b></td>');
	
		        i <- 1;
		        while (i <= length(hw.snp$statistic))
		        {
		            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',hw.snp$statistic[i],'</font></td>',sep="");
		            i <- i + 1;
		        }
		
		        i <- 1;
		        while (i <= length(hw.snp$parameter))
		        {
		            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',hw.snp$parameter[i],'</font></td>',sep="");
		            i <- i + 1;
		        }
		
		        if (hw.snp$p.value>=0.05)
		        {
		            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',format.pval(hw.snp$p.value),'</font></td>',sep="");
		        }
		        else
		        {
		            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>',format.pval(hw.snp$p.value),'</b></font></td>',sep="");
		        }
		        cat('</tr>')
		
		        if (descr.subpop==1)
		        {
		            j <- 1;
		            while (j <= length(levels(st)))
		            {
		                hw.snp <- HWE.exact(snp.geno[st==levels(st)[j]]);
		
		                cat('<tr>');
		                cat('<td nowrap><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',st.name,"=",levels(st)[j],'</font></b></td>',sep="");
		
		                i <- 1;
		                while (i <= length(hw.snp$statistic))
		                {
		                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',hw.snp$statistic[i],'</font></td>',sep="");
		                    i <- i + 1;
		                }
		
		                i <- 1;
		                while (i <= length(hw.snp$parameter))
		                {
		                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',hw.snp$parameter[i],'</font></td>',sep="");
		                    i <- i + 1;
		                }
		
		                if (hw.snp$p.value>=0.05)
		                {
		                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',format.pval(hw.snp$p.value),'</font></td>',sep="");
		                }
		                else
		                {
		                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>',format.pval(hw.snp$p.value),'</b></font></td>',sep="");
		                }
		
		                cat('</tr>');
		                j <- j + 1;
		            }
		        }
		        cat('</table>');
		        cat('<p></p>')
		    }
		    else
		    {
		        cat("<table border>");
		        cat('<tr bgcolor="#C0C0C0"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' exact test for Hardy-Weinberg equilibrium (n=',length(snp[keep.snp]),')</b></center></font></td></tr>',sep="");
		        cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>Monomorphic SNP</b></font></td></tr>');
		        cat('</table><p></p>');
		    }
	    }

	    #SNP association with response
	    if (descr.snpassoc)
	    {
	        if (length(ref)>1)
	        {
	            res <- associacio(snp,st,m.cov,cont=FALSE);

	            if (!is.null(m.cov))
	            {
	                stradj <- paste(names(m.cov), collapse="+");
	                n <- length(snp[keep.snp & keep.cov]);
	            }
	            else
	            {
	                stradj <- "no adjustment";
	                n <- length(snp[keep.snp]);
				}

				cat.snp.assoc.matrix(res,st,st.name,stradj,length(levels(snp)),n,snp.name);
	        }
	        else
	        {
	            cat('<table border>');
	            cat('<tr bgcolor="#C0C0C0"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' association with response</b></center></font></td></tr>');
	            cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>Monomorphic SNP</b></font></td></tr>');
	            cat('</table>');
	        }
	    }
	}
	else #Continuous response variable
	{
	    #Allele frequencies
	    if (descr.allfreq==1)
	    {
            cat("<table border>");
            cat('<tr bgcolor="#C0C0C0"><td colspan=3><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' allele frequencies (n=',length(snp[keep.snp]),')</b></center></font></td></tr>',sep="");

            cat("<tr>");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Allele</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Count</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Proportion</b></font></td>');
            cat("</tr>");

            i <- 1;
            while (i <= snp.sum$nallele) #For every allele (not including NAs)
            {
                cat("<tr>");
                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(snp.sum$allele.freq)[i],"</td>",sep="");
                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',snp.sum$allele.freq[i,1],"</td>",sep="");
                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(snp.sum$allele.freq[i,2],2),"</td>",sep="");
                cat("</tr>");
                i <- i + 1;
            }

            cat("</table><p></p>");
	    }	

	    #Genotype frequencies    
	    if (descr.genofreq==1)
	    {
			if (length(ref)>1)
			{
				snp.sum$genotype.freq <- reorder.geno.matrix(snp.sum$genotype.freq,ref);
			}

            cat("<table border>");
            cat('<tr bgcolor="#C0C0C0"><td colspan=4><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' genotype frequencies (n=',length(snp),')</b></center></font></td></tr>',sep="");
            cat("<tr>");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Genotype</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Count</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Proportion</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Response mean (s.e.)</b></font></td>');
            cat("</tr>");

            i <- 1;
            while (i <= nrow(snp.sum$genotype.freq)) #For every genotype (including NAs)
            {
                cat("<tr>");
                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(snp.sum$genotype.freq)[i],'</font></td>',sep="");
                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',snp.sum$genotype.freq[i,1],'</font></td>',sep="");
                if (is.na(snp.sum$genotype.freq[i,2]))
                {
                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>');
                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>');
                }
                else
                {
                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(snp.sum$genotype.freq[i,2],2),'</font></td>',sep="");
                    st.aux <- st[!is.na(snp)];
                    snp.aux <- snp[!is.na(snp)];
                    if (rownames(snp.sum$genotype.freq)[i] %in% as.character(snp.aux))
                    {
	                    m.st <- mean(st.aux[((as.character(snp.aux))==(rownames(snp.sum$genotype.freq)[i]))],na.rm=TRUE);
	                    sd.st <- sd(st.aux[((as.character(snp.aux))==(rownames(snp.sum$genotype.freq)[i]))],na.rm=TRUE);
	                    num.st <- length(st.aux[((as.character(snp.aux))==(rownames(snp.sum$genotype.freq)[i]))]);
	                    se.st <- sd.st/sqrt(num.st);
	                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(m.st,2),' (',round(se.st,2),') (n=',length(snp.aux[(!is.na(st.aux)) & (((as.character(snp.aux))==(rownames(snp.sum$genotype.freq)[i])))]),')','</font></td>',sep="");
	                }
	                else
	                {
	                	geno.rev <- revstr(rownames(snp.sum$genotype.freq)[i]);
	                    m.st <- mean(st.aux[((as.character(snp.aux))==(geno.rev))],na.rm=TRUE);
	                    sd.st <- sd(st.aux[((as.character(snp.aux))==(geno.rev))],na.rm=TRUE);
	                    num.st <- length(st.aux[((as.character(snp.aux))==(geno.rev))]);
	                    se.st <- sd.st/sqrt(num.st);
	                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(m.st,2),' (',round(se.st,2),') (n=',length(snp.aux[(!is.na(st.aux)) & (((as.character(snp.aux))==(geno.rev)))]),')','</font></td>',sep="");
	                }
                }
                cat("</tr>");
                i <- i + 1;
            }
            cat("</table><p></p>");
		}

		#Hardy-Weinberg equilibrium
		if (descr.hweq==1)
		{
			if (length(ref)>1)
			{
		        hw.snp <- HWE.exact(snp.geno);
		
		        cat("<table border>");
		        cat('<tr bgcolor="#C0C0C0"><td colspan=7><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' exact test for Hardy-Weinberg equilibrium (n=',length(snp[keep.snp]),')</b></center></font></td></tr>',sep="");
		        cat('<tr><td></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N11</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N12</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N22</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N1</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">N2</font></b></td>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">P-value</font></b></td></tr>');
	
		        cat('<tr>');
		        cat('<td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif">All subjects</font></b></td>');
	
		        i <- 1;
		        while (i <= length(hw.snp$statistic))
		        {
		            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',hw.snp$statistic[i],'</font></td>',sep="");
		            i <- i + 1;
		        }
		
		        i <- 1;
		        while (i <= length(hw.snp$parameter))
		        {
		            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',hw.snp$parameter[i],'</font></td>',sep="");
		            i <- i + 1;
		        }
		
		        if (hw.snp$p.value>=0.05)
		        {
		            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',format.pval(hw.snp$p.value),'</font></td>',sep="");
		        }
		        else
		        {
		            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>',format.pval(hw.snp$p.value),'</b></font></td>',sep="");
		        }
		        cat('</tr>');
		        cat('</table>');
		        cat('<p></p>');
		    }
		    else
		    {
		        cat("<table border>");
		        cat('<tr bgcolor="#C0C0C0"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.name,' exact test for Hardy-Weinberg equilibrium (n=',length(snp[keep.snp]),')</b></center></font></td></tr>',sep="");
		        cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>Monomorphic SNP</b></font></td></tr>');
		        cat('</table><p></p>');
		    }
		}

		#SNP association with response
		if (descr.snpassoc)
		{
			if (length(levels(snp))>1)
			{
				res <- associacio(snp,st,m.cov,cont=TRUE);

	            if (!is.null(m.cov))
	            {
	                stradj <- paste(names(m.cov), collapse="+");
	                n <- length(snp[keep.snp & keep.cov]);
	            }
	            else
	            {
	                stradj <- "no adjustment";
	                n <- length(snp[keep.snp]);
				}

	            cat.snp.assoc.matrix.cont(res,st,st.name,stradj,length(levels(snp)),n,snp.name);
	        }
	        else
	        {
	            cat('<table border>');
                cat('<tr bgcolor="#C0C0C0"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>SNP association with response</b></center></font></td></tr>');
                cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>Monomorphic SNP: cannot compute association with response</b></font></td></tr>');
	            cat('</table>');
	        }
	    }
	}
}

print.status.desc <- function(st,st.name,num.status)
{
	if (num.status==0) #Status is a factor
	{
		cat('<table border><tr bgcolor="#C0C0C0">');
		cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif">');
		cat('<td bgcolor="#FFFFB0"></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>n</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>missing</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>unique</b></font></td>');
		cat('</font></tr>');

		cat('<tr><td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>All subjects</b></font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(st),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(st[is.na(st)]),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(unique(st[!is.na(st)])),'</font></td></tr>',sep="");

		i <- 1;
		while (i <= length(levels(st)))
		{
			cat('<tr><td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',st.name,"=",levels(st)[i],'</b></font></td>',sep="");
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(st[(!is.na(st)) & (st==levels(st)[i])]),' (',round(length(st[(!is.na(st)) & (st==levels(st)[i])])/length(st[(!is.na(st))])*100,2),'%)</font></td>',sep="");
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>',sep="");
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td></tr>',sep="");
			i <- i + 1;
        }

        cat('</table>');
        cat('<p></p>');
	}
	else
	{
		cat('<table border><tr bgcolor="#C0C0C0"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>n</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>missing</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>unique</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>mean</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.05</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.10</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.25</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.50</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.75</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.90</b></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.95</b></font></td>');
		cat('</font></tr><tr>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(st),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(st[is.na(st)]),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(unique(st)),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(mean(st),2),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(st,.05,na.rm=TRUE),2),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(st,.10,na.rm=TRUE),2),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(st,.25,na.rm=TRUE),2),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(st,.50,na.rm=TRUE),2),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(st,.75,na.rm=TRUE),2),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(st,.90,na.rm=TRUE),2),'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(st,.95,na.rm=TRUE),2),'</font></td>',sep="");
		cat('</tr></table>');
		
		cat('<font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">');
		if (length(unique(st))>=5)
		{
		    cat('lowest: ',sort(unique(st))[1],", ",sort(unique(st))[2],", ",sort(unique(st))[3],", ",sort(unique(st))[4],", ",sort(unique(st))[5]," ",sep="");
		    cat('highest: ',sort(unique(st))[length(unique(st))-4],", ",sort(unique(st))[length(sort(unique(st)))-3],", ",sort(unique(st))[length(sort(unique(st)))-2],", ",sort(unique(st))[length(sort(unique(st)))-1],", ",sort(unique(st))[length(sort(unique(st)))],sep="");
		}
		cat('</font>');
	}
}

print.cov.desc <- function(cova, cova.type, num.status, subpop, st, st.name)
{
    if (num.status==0) #Status is categorical
    {
        if (cova.type=="ccov") #ccov: categorical covariate
        {
            cat('<table border><tr bgcolor="#C0C0C0"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">');
            cat('<td bgcolor="#FFFFB0"></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>n</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>missing</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>unique</b></font></td>');
            cat('</font></tr>');
            cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>All subjects</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[is.na(cova)]),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(unique(cova[!is.na(cova)])),'</font></td>',sep="");
            cat('</tr>');

            if (subpop==1)
            {
                i <- 1;
                while (i <= length(levels(st)))
                {
                    cat('<tr><td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',st.name,"=",levels(st)[i],'</b></font></td>',sep="");
                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[(st==levels(st)[i]) & (!is.na(st))]),'</font></td>',sep="");
                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[(st==levels(st)[i]) & (is.na(cova))]),'</font></td>',sep="");
                    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(unique(cova[(st==levels(st)[i]) & (!is.na(cova))])),'</font></td></tr>',sep="");
                    i <- i + 1;
                }
            }
            cat('</table>');
            cat('<p></p>');

            cat('<table border><tr bgcolor="#C0C0C0">');
            cat('<td bgcolor="#FFFFB0"></td>');

            i <- 1;
            while (i <= length(levels(cova)))
            {
                cat('<td><center><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',levels(cova)[i],'</b></font></center></td>',sep="");
                i <- i + 1;
            }
            cat('</tr>');

            cat('<tr>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>All subjects</b></font></td>');
            i <- 1;
            while (i <= length(levels(cova)))
            {
                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[cova==levels(cova)[i] & !is.na(cova)]),' (',round(length(cova[cova==levels(cova)[i] & !is.na(cova)])/length(cova[!is.na(cova)]),2)*100,'%)</font></td>',sep="");
                i <- i + 1;
            }
            cat('</tr>');

            if (subpop==1)
            {
                j <- 1;
                while (j <= length(levels(st)))
                {
                    cat('<tr>');
                    cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',st.name,"=",levels(st)[j],'</b></font></td>',sep="");
                    i <- 1;
                    while (i <= length(levels(cova)))
                    {
                        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[cova==levels(cova)[i] & (!is.na(cova)) & (st==levels(st)[j]) & (!is.na(st))]),' (',round(length(cova[cova==levels(cova)[i] & !is.na(cova) & (st==levels(st)[j])])/length(cova[!is.na(cova) & (st==levels(st)[j])]),2)*100,'%)</font></td>',sep="");
                        i <- i + 1;
                    }
                    cat('</tr>');
                    j <- j + 1;
                }
            }
            cat('</table>');
        }
        else #qcov: quantitative covariate
        {
            cat('<table border><tr bgcolor="#C0C0C0">');
            cat('<td></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>n</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>missing</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>unique</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>mean</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.05</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.10</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.25</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.50</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.75</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.90</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.95</b></font></td>');
            cat('</tr>');
            cat('<tr>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>All subjects</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[is.na(cova)]),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(unique(cova[!is.na(cova)])),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(mean(cova,na.rm=T),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.05,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.10,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.25,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.50,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.75,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.90,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.95,na.rm=TRUE),2),'</font></td>',sep="");
            cat('</tr>');

            i <- 1;
            while (i <= length(levels(st)))
            {
	            cat('<tr>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',st.name,"=",levels(st)[i],'</b></font></td>');
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[(st==levels(st)[i]) & (!is.na(st))]),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[(is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))]),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(unique(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))])),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(mean(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))]),2),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))],.05,na.rm=TRUE),2),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))],.10,na.rm=TRUE),2),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))],.25,na.rm=TRUE),2),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))],.50,na.rm=TRUE),2),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))],.75,na.rm=TRUE),2),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))],.90,na.rm=TRUE),2),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova[(!is.na(cova)) & (st==levels(st)[i]) & (!is.na(st))],.95,na.rm=TRUE),2),'</font></td>',sep="");
	            cat('</tr>');

				i <- i + 1;
            }

			cat('</table>');
            cat('<font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">');
            if (length(unique(cova))>=5)
            {
                cat(paste('lowest: ',sort(unique(cova))[1],", ",sort(unique(cova))[2],", ",sort(unique(cova))[3],", ",sort(unique(cova))[4],", ",sort(unique(cova))[5]," ",sep=""));
                cat(paste('highest: ',sort(unique(cova))[length(unique(cova))-4],", ",sort(unique(cova))[length(sort(unique(cova)))-3],", ",sort(unique(cova))[length(sort(unique(cova)))-2],", ",sort(unique(cova))[length(sort(unique(cova)))-1],", ",sort(unique(cova))[length(sort(unique(cova)))],sep=""));
            }
            cat('</font>');
        }
    }
    else #Status is continuous
    {
        if (cova.type=="ccov") #ccov: categorical covariate
        {
            cat('<table border><tr bgcolor="#C0C0C0"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">');
            cat('<td bgcolor="#FFFFB0"></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>n</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>missing</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>unique</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Response mean (s.e.)</b></font></td>');
            cat('</font></tr>');
            cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>All subjects</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[is.na(cova)]),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(unique(cova[!is.na(cova)])),'</font></td>',sep="");
			m <- round(mean(st,na.rm=T),2);
			se <- round(sd(st,na.rm=T)/sqrt(length(st[!is.na(st)])),2);
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',m,' (',se,')</font></td>',sep="");
            cat('</tr>');

            i <- 1;
            while (i <= length(levels(cova)))
            {
				cat('<tr>');
				cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',levels(cova)[i],'</b></font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[(!is.na(cova)) & (cova==levels(cova)[i])]),'</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>',sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</font></td>',sep="");
				m <- round(mean(st[(!is.na(cova)) & (cova==levels(cova)[i])],na.rm=T),2);
				se <- round(sd(st[(!is.na(cova)) & (cova==levels(cova)[i])],na.rm=T)/sqrt(length(st[(!is.na(st)) & (!is.na(cova)) & (cova==levels(cova)[i])])),2);
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',m,' (',se,')</font></td>',sep="");
	            cat('</tr>');

                i <- i + 1;
            }
            cat('</table>');
        }
        else #qcov: quantitative covariate
        {
            cat('<table border><tr bgcolor="#C0C0C0">');
            cat('<td></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>n</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>missing</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>unique</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>mean</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.05</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.10</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.25</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.50</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.75</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.90</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>.95</b></font></td>');
            cat('</tr>');
            cat('<tr>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>All subjects</b></font></td>');
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(cova[is.na(cova)]),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',length(unique(cova[!is.na(cova)])),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(mean(cova,na.rm=T),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.05,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.10,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.25,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.50,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.75,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.90,na.rm=TRUE),2),'</font></td>',sep="");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(quantile(cova,.95,na.rm=TRUE),2),'</font></td>',sep="");
            cat('</tr>');
			cat('</table>');

            cat('<font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">');
            if (length(unique(cova))>=5)
            {
                cat(paste('lowest: ',sort(unique(cova))[1],", ",sort(unique(cova))[2],", ",sort(unique(cova))[3],", ",sort(unique(cova))[4],", ",sort(unique(cova))[5]," ",sep=""));
                cat(paste('highest: ',sort(unique(cova))[length(unique(cova))-4],", ",sort(unique(cova))[length(sort(unique(cova)))-3],", ",sort(unique(cova))[length(sort(unique(cova)))-2],", ",sort(unique(cova))[length(sort(unique(cova)))-1],", ",sort(unique(cova))[length(sort(unique(cova)))],sep=""));
            }
            cat('</font>');
        }
    }
}

cat.ld.matrix <- function(m)
{
    cat("<table>");
    i <- 1;
    cat("<tr>");
    cat('<td><font size="1">   </font></td>');
    while (i <= nrow(m))
    {
        cat('<td><font face="Verdana, Arial, Helvetica, sans-serif" size="1">',colnames(m)[i],'</font></td>',sep="");
        i <- i + 1;
    }
    cat("</tr>");
    i <- 1;
    while (i <= nrow(m))
    {
        j <- 1;
        cat('<tr><td><font face="Verdana, Arial, Helvetica, sans-serif" size="1">',rownames(m)[i],"</font></td>",sep="");
        while(j <= ncol(m))
        {
            if (is.na(m[i,j]))
            {
                cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">.</font></td>',sep="");
            }
            else
            {
                cat('<td align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">',round(m[i,j],4),"</font></td>",sep="");
            }
            j <- j + 1;
        }
        cat("</tr>");
        i <- i + 1;
    }
    cat("</table>");
    cat("<p></p>");
}

cat.haplo.matrix <- function(m,n,freqmin,num.snps)
{
    cat("<table border>");
    i <- 1;
    cat('<tr bgcolor="#C0C0C0"><td colspan=',ncol(m)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotype frequencies estimation (n=',n,')</b></center></font></td></tr>',sep="");
    cat("<tr>");
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>');
    while (i <= ncol(m))
    {
        if (colnames(m)[i]=="CumFreq")
        {
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Cumulative<br>frequency</b></center></font></td>',sep="");
        }
        else
        {
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',colnames(m)[i],"</b></center></font></td>",sep="");
		}
        i <- i + 1;
    }
    cat("</tr>");
    i <- 1;
    while (i <= nrow(m))
    {
        j <- 1;
        if (i==1) #Base haplotype, we print it in green
        {
        	cat('<tr bgcolor="#00CC00"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[i],"</font></td>",sep="");
        }
        else
        {
			if (is.na(m[i,num.snps+1]))
			{
				cat('<tr bgcolor="#FF0000"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[i],"</font></td>",sep="");
			}
			else
			{
				if (freqmin > m[i,num.snps+1])
				{
					cat('<tr bgcolor="#FF0000"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[i],"</font></td>",sep="");
				}
				else
				{
					cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[i],"</font></td>",sep="");
				}
			}
        }
        while(j <= ncol(m))
        {
            if (is.numeric(m[i,j]))
            {
                cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',round(m[i,j],4),"</font></td>",sep="");
            }
            else
            {
                cat('<td align="right"><center><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',m[i,j],"</font></center></td>",sep="");
            }

            j <- j + 1;
        }
        cat("</tr>");
        i <- i + 1;
    }
    cat("</table>");
    cat("<p></p>");
}

cat.assoc.matrix <- function(m,snp.names,stradj,n,pval)
{
    cat("<table border>");
    i <- 1;
    if (stradj=="no adjustment")
    {
        cat('<tr bgcolor="#C0C0C0"><td colspan=',ncol(m)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotype association with response (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
    }
    else
    {
        cat('<tr bgcolor="#C0C0C0"><td colspan=',ncol(m)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotype association with response (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
    }
    cat("<tr>");
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>');

    while (i <= length(snp.names))
    {
        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.names[i],'</b></center></font></td>',sep="");
        i <- i + 1;
    }

    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Freq</b></center></font></td>',sep="");
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>OR (95% CI)</b></center></font></td>',sep="");
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>P-value</b></center></font></td>',sep="");
    cat("</tr>");
    i <- 1;
    while (i <= nrow(m))
    {
    	if (i==1)
    	{
        	cat('<tr bgcolor="#00CC00"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[i],"</font></td>",sep="");
    	}
    	else
    	{
        	cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[i],"</font></td>",sep="");
        }

        j <- 1;
        while(j <= length(snp.names))
        {
            cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',as.character(m[i,j]),"</center></font></td>",sep="");
            j <- j + 1;
        }
        cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[i,j],4),"</center></font></td>",sep="");
        j <- j + 1;
        if (i==1) #Base haplotype, there is no CI
        {
            cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>1.00</center></font></td>',sep="");
            cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
        }
        else
        {
            if (m[i,j+1] != m[i,j+2]) #There have been no problems with the or estimation
            {
                if (m[i,j+3]>=0.05)  #We check the p-val
                {
                    cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[i,j])," (",format.or(m[i,j+1])," - ",format.or(m[i,j+2]),")","</center></font></td>",sep="");
                }
                else
                {
                    if (m[i,j]<1) #Lower risk - print in green
                    {
                        cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><font color="#00CC00"><b>',format.or(m[i,j])," (",format.or(m[i,j+1])," - ",format.or(m[i,j+2]),")","</b></font></center></font></td>",sep="");
                    }
                    else #Higher risk - print in red
                    {
                        cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><font color="#FF0000"><b>',format.or(m[i,j])," (",format.or(m[i,j+1])," - ",format.or(m[i,j+2]),")","</b></font></center></font></td>",sep="");
                    }
                }
                j <- j + 3;
                cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[i,j]),'</center></font></td>',sep="");
            }
            else
            {
                cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[i,j]),' (-Inf - Inf)</center></font></td>',sep="");
                cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>1</center></font></td>',sep="");
            }

        }

        cat("</tr>");
        i <- i + 1;
    }

	#Now we print the pvalue
    cat('<tr><td colspan=',ncol(m)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Global haplotype association p-value: </b>');

	if (pval > 0.05)
	{
		cat(format.pval(pval));
	}
	else
	{
		cat('<font color="#FF0000"><b>',format.pval(pval),'</b></font>',sep="");
	}
    cat('</font></td></tr>');

    cat("</table>");
    cat("<p></p>");
}

cat.assoc.matrix.cont <- function(m,snp.names,stradj,n, pval)
{
    cat("<table border>");
    i <- 1;
    if (stradj=="no adjustment")
    {
        cat('<tr bgcolor="#C0C0C0"><td colspan=',ncol(m)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotype association with response (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
    }
    else
    {
        cat('<tr bgcolor="#C0C0C0"><td colspan=',ncol(m)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotype association with response (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
    }
    cat("<tr>");
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>');

    while (i <= length(snp.names))
    {
        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snp.names[i],'</b></center></font></td>',sep="");
        i <- i + 1;
    }

    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Frequency</b></center></font></td>',sep="");
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Difference (95% CI)</b></center></font></td>',sep="");
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>P-value</b></center></font></td>',sep="");
    cat("</tr>");
    i <- 1;
    while (i <= nrow(m))
    {
    	if (i==1)
    	{
        	cat('<tr bgcolor="#00CC00"><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[i],"</font></td>",sep="");
    	}
    	else
    	{
        	cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[i],"</font></td>",sep="");
        }

        j <- 1;
        while(j <= length(snp.names))
        {
            cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',as.character(m[i,j]),"</center></font></td>",sep="");
            j <- j + 1;
        }
        cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[i,j],4),"</center></font></td>",sep="");
        j <- j + 1;
        if (i==1) #Base haplotype, there is no CI nor pvalue
        {
            cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>0.00</center></font></td>',sep="");
            cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
        }
        else
        {
			dif <- ifelse(is.na(m[i,j]),"NA",round(m[i,j],2));
			lo <- ifelse(is.na(m[i,j+1]),"NA",round(m[i,j+1],2));
			up <- ifelse(is.na(m[i,j+2]),"NA",round(m[i,j+2],2));
			pval <- ifelse(is.na(m[i,j+3]),"NA",format.pval(m[i,j+3]));

			if ((dif!="NA") & (lo!="NA") & (up!="NA"))
			{
				if (m[i,j+1] != m[i,j+2])
				{
		            if (m[i,j+1]>0)
		            {
						cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',dif,' (',lo,' - ',up,')',"</b></center></font></td>",sep="");
		            }
		            else if (m[i,j+2]<0)
		            {
						cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',dif,' (',lo,' - ',up,')',"</b></center></font></td>",sep="");
		            }
		            else
		            {
						cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',dif,' (',lo,' - ',up,')',"</center></font></td>",sep="");
		            }
				}
				else
				{
					cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',dif,' (-Inf - Inf)</center></font></td>',sep="");
				}
			}
			else
			{
				cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',dif,' (',lo,' - ',up,')',"</center></font></td>",sep="");
			}
			cat('<td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',pval,'</center></font></td>',sep="");
        }

        cat("</tr>");
        i <- i + 1;
    }

	#Now we print the pvalue
    cat('<tr><td colspan=',ncol(m)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Global haplotype association p-value: </b>');

	if (pval > 0.05)
	{
		cat(format.pval(pval));
	}
	else
	{
		cat('<font color="#FF0000"><b>',format.pval(pval),'</b></font>',sep="");
	}
    cat('</font></td></tr>');

    cat("</table>");
    cat("<p></p>");
}

format.or <- function(n)
{
    if (n=="NA")
    {
        r <- "NA";
    }
    else
    {
        r <- formatC(n,digits=2,width=-1,format="f");
    }
    r;
}

format.perc <- function(n)
{
    r <- round(n,1);
    r;
}

format.pval <- function(n)
{
	if (!is.na(n))
	{
	    if (n < 0.0001)
	    {
			r <- "<0.0001";
	    }
	    else
	    {
	        r <- signif(n,2);
	    }
	}
	else
	{
		r <- "NA";
	}
	r;
}

format.aic <- function(n)
{
    r <- round(n,1);
    r;
}

cat.snp.assoc.matrix <- function(m,st,st.name,stradj,num.levels,n,snpname)
{
    cat('<table border rules=groups>');
    if (stradj=="no adjustment")
    {
        cat('<tr bgcolor="#C0C0C0"><td colspan=8><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snpname,' association with response ',st.name,' (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
    }
    else
    {
        cat('<tr bgcolor="#C0C0C0"><td colspan=8><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snpname,' association with response ',st.name,' (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
    }

    #Headers #########
    cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Model</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Genotype</b></center></font></td>');
    i <- 1;
    while(i <= length(levels(st)))
    {
        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',st.name,'=',levels(st)[i],'</b></center></font></td>',sep="");
        i <- i + 1;
    }

    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>OR (95% CI)</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>P-value</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>AIC</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>BIC</b></center></font></td>');

    cat('</tr>');

    if (num.levels==3)
    {
	    #Codominant model #########
	    cat('<tbody>');
	    cat('<tr><td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Codominant</center></font></td>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[1],'</font></td>',sep=""); #SNP
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[1,1],' (',format.perc(m[1,2]),'%)','</center></font></td>',sep=""); #Pop 1: Number of elements (%)
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[1,3],' (',format.perc(m[1,4]),'%)','</center></font></td>',sep=""); #Pop 2: Number of elements (%)
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[1,5]),'</center></font></td>',sep=""); #OR for the bse category (will always be 1.00)
	    cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[1,8]),'</center></font></td>',sep=""); #P-value
	    cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[1,9]),'</center></font></td>',sep=""); #AIC
	    cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[1,10]),'</center></font></td>',sep=""); #BIC
		cat('</tr>');

	    cat('<tr>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[2],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[2,1],' (',format.perc(m[2,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[2,3],' (',format.perc(m[2,4]),'%)','</center></font></td>',sep="");
	
	    if (!is.na(m[2,5]) & !is.na(m[2,6]) & !is.na(m[2,7]))
	    {
	        if (m[2,6]>1) #ORlow > 1, we print it in red
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#FF0000">',format.or(m[2,5]),' (',format.or(m[2,6]),'-',format.or(m[2,7]),')','</font></b></center></font></td>',sep="");
	        }
	        else
	        {
	            if (m[2,7]<1) #ORup < 1, we print it in green
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#00CC00">',format.or(m[2,5]),' (',format.or(m[2,6]),'-',format.or(m[2,7]),')','</font></b></center></font></td>',sep="");
	            }
	            else #Non-significant OR
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[2,5]),' (',format.or(m[2,6]),'-',format.or(m[2,7]),')','</center></font></td>',sep="");
	            }
	        }
	    }
	    else
	    {
	    	or <- ifelse(is.na(m[2,5]),"NA",m[2,5]);
	        orlo <- ifelse(is.na(m[2,6]),"NA",m[2,6]);
	        orup <- ifelse(is.na(m[2,7]),"NA",m[2,7]);

	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),' (',format.or(orlo),'-',format.or(orup),')','</center></font></td>',sep="");
	    }
	    cat('</tr>');
	
	    cat('<tr>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[3],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[3,1],' (',format.perc(m[3,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[3,3],' (',format.perc(m[3,4]),'%)','</center></font></td>',sep="");

            if (!is.na(m[3,5]) & !is.na(m[3,6]) & !is.na(m[3,7]))
	    {
	        if (m[3,6]>1) #ORlow > 1, we print it in red
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#FF0000">',format.or(m[3,5]),' (',format.or(m[3,6]),'-',format.or(m[3,7]),')','</font></b></center></font></td>',sep="");
	        }
	        else
	        {
	            if (m[3,7]<1) #ORup < 1, we print it in green
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#00CC00">',format.or(m[3,5]),' (',format.or(m[3,6]),'-',format.or(m[3,7]),')','</font></b></center></font></td>',sep="");
	            }
	            else #Non-significant OR
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[3,5]),' (',format.or(m[3,6]),'-',format.or(m[3,7]),')','</center></font></td>',sep="");
	            }
	        }
	    }
	    else
	    {
	    	or <- ifelse(is.na(m[3,5]),"NA",m[3,5]);
	        orlo <- ifelse(is.na(m[3,6]),"NA",m[3,6]);
	        orup <- ifelse(is.na(m[3,7]),"NA",m[3,7]);

	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),' (',format.or(orlo),'-',format.or(orup),')','</center></font></td>',sep="");
	    }
	    cat('</tr>');
	    cat('</tbody>');
    
	    #Dominant model #########
	    cat('<tbody>');
	    cat('<tr><td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Dominant</center></font></td>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[4],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[4,1],' (',format.perc(m[4,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[4,3],' (',format.perc(m[4,4]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[4,5]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[4,8]),'</center></font></td>',sep="");
		cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[4,9]),'</center></font></td>',sep="");
		cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[4,10]),'</center></font></td>',sep="");
		cat('</tr>');

		cat('<tr>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[5],'</font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[5,1],' (',format.perc(m[5,2]),'%)','</center></font></td>',sep="");
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[5,3],' (',format.perc(m[5,4]),'%)','</center></font></td>',sep="");

		if (!is.na(m[5,5]) & !is.na(m[5,6]) & !is.na(m[5,7]))
	    {
	        if (m[5,6]>1) #ORlow > 1, we print it in red
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#FF0000">',format.or(m[5,5]),' (',format.or(m[5,6]),'-',format.or(m[5,7]),')','</font></b></center></font></td>',sep="");
	        }
	        else
	        {
	            if (m[5,7]<1) #ORup < 1, we print it in green
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#00CC00">',format.or(m[5,5]),' (',format.or(m[5,6]),'-',format.or(m[5,7]),')','</font></b></center></font></td>',sep="");
	            }
	            else #Non-significant OR
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[5,5]),' (',format.or(m[5,6]),'-',format.or(m[5,7]),')','</center></font></td>',sep="");
	            }
	        }
	    }
	    else
	    {
	    	or <- ifelse(is.na(m[5,5]),"NA",m[5,5]);
	        orlo <- ifelse(is.na(m[5,6]),"NA",m[5,6]);
	        orup <- ifelse(is.na(m[5,7]),"NA",m[5,7]);

	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),' (',format.or(orlo),'-',format.or(orup),')','</center></font></td>',sep="");
	    }
	    cat('</tr>');
	    cat('</tbody>');
	
	    #Recessive model #########
	    cat('<tbody>');
	    cat('<tr><td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Recessive</center></font></td>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[6],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[6,1],' (',format.perc(m[6,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[6,3],' (',format.perc(m[6,4]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[6,5]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[6,8]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[6,9]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[6,10]),'</center></font></td>',sep="");
	    cat('</tr>');

	    cat('<tr>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[7],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[7,1],' (',format.perc(m[7,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[7,3],' (',format.perc(m[7,4]),'%)','</center></font></td>',sep="");
	
	    if (!is.na(m[7,5]) & !is.na(m[7,6]) & !is.na(m[7,7]))
	    {
	        if (m[7,6]>1) #ORlow > 1, we print it in red
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#FF0000">',format.or(m[7,5]),' (',format.or(m[7,6]),'-',format.or(m[7,7]),')','</font></b></center></font></td>',sep="");
	        }
	        else
	        {
	            if (m[7,7]<1) #ORup < 1, we print it in green
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#00CC00">',format.or(m[7,5]),' (',format.or(m[7,6]),'-',format.or(m[7,7]),')','</font></b></center></font></td>',sep="");
	            }
	            else #Non-significant OR
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[7,5]),' (',format.or(m[7,6]),'-',format.or(m[7,7]),')','</center></font></td>',sep="");
	            }
	        }
	    }
	    else
	    {
	    	or <- ifelse(is.na(m[7,5]),"NA",m[7,5]);
	        orlo <- ifelse(is.na(m[7,6]),"NA",m[7,6]);
	        orup <- ifelse(is.na(m[7,7]),"NA",m[7,7]);

	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),' (',format.or(orlo),'-',format.or(orup),')','</center></font></td>',sep="");
	    }
	    cat('</tr>');
	    cat('</tbody>');
    
	    #Overdominant model #########
	    cat('<tbody>');
	    cat('<tr><td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Overdominant</center></font></td>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[8],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[8,1],' (',format.perc(m[8,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[8,3],' (',format.perc(m[8,4]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[8,5]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[8,8]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[8,9]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[8,10]),'</center></font></td>',sep="");
	    cat('</tr>');
	
	    cat('<tr>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[9],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[9,1],' (',format.perc(m[9,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[9,3],' (',format.perc(m[9,4]),'%)','</center></font></td>',sep="");
	
	    if (!is.na(m[9,5]) & !is.na(m[9,6]) & !is.na(m[9,7]))
	    {
	        if (m[9,6]>1) #ORlow > 1, we print it in red
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#FF0000">',format.or(m[9,5]),' (',format.or(m[9,6]),'-',format.or(m[9,7]),')','</font></b></center></font></td>',sep="");
	        }
	        else
	        {
	            if (m[9,7]<1) #ORup < 1, we print it in green
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#00CC00">',format.or(m[9,5]),' (',format.or(m[9,6]),'-',format.or(m[9,7]),')','</font></b></center></font></td>',sep="");
	            }
	            else #Non-significant OR
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[9,5]),' (',format.or(m[9,6]),'-',format.or(m[9,7]),')','</center></font></td>',sep="");
	            }
	        }
	    }
	    else
	    {
	    	or <- ifelse(is.na(m[9,5]),"NA",m[9,5]);
	        orlo <- ifelse(is.na(m[9,6]),"NA",m[9,6]);
	        orup <- ifelse(is.na(m[9,7]),"NA",m[9,7]);

	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),' (',format.or(orlo),'-',format.or(orup),')','</center></font></td>',sep="");
	    }
	    cat('</tr>');
	    cat('</tbody>');

	    #Additive model #########
	    cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Log-additive</center></font></td>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
	
	    if (!is.na(m[10,5]) & !is.na(m[10,6]) & !is.na(m[10,7]))
	    {
	        if (m[10,6]>1) #ORlow > 1, we print it in red
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#FF0000">',format.or(m[10,5]),' (',format.or(m[10,6]),'-',format.or(m[10,7]),')','</font></b></center></font></td>',sep="");
	        }
	        else
	        {
	            if (m[10,7]<1) #ORup < 1, we print it in green
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#00CC00">',format.or(m[10,5]),' (',format.or(m[10,6]),'-',format.or(m[10,7]),')','</font></b></center></font></td>',sep="");
	            }
	            else #Non-significant OR
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[10,5]),' (',format.or(m[10,6]),'-',format.or(m[10,7]),')','</center></font></td>',sep="");
	            }
	        }
	    }
	    else
	    {
	    	or <- ifelse(is.na(m[10,5]),"NA",m[10,5]);
	        orlo <- ifelse(is.na(m[10,6]),"NA",m[10,6]);
	        orup <- ifelse(is.na(m[10,7]),"NA",m[10,7]);

	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),' (',format.or(orlo),'-',format.or(orup),')','</center></font></td>',sep="");
	    }
	    
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[10,8]),'</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[10,9]),'</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[10,10]),'</center></font></td>',sep="");
	    cat('</tr>');
    }
    else
    {
	    cat('<tbody>');
	    cat('<tr><td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[1],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[1,1],' (',format.perc(m[1,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[1,3],' (',format.perc(m[1,4]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[1,5]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[1,8]),'</center></font></td>',sep="");
	    cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[1,9]),'</center></font></td>',sep="");
		cat('<td rowspan="2" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[1,10]),'</center></font></td>',sep="");
		cat('</tr>');

		cat('<tr>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[2],'</font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[2,1],' (',format.perc(m[2,2]),'%)','</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[2,3],' (',format.perc(m[2,4]),'%)','</center></font></td>',sep="");

	    if (!is.na(m[2,5]) & !is.na(m[2,6]) & !is.na(m[2,7]))
	    {
	        if (m[2,6]>1) #ORlow > 1, we print it in red
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#FF0000">',format.or(m[2,5]),' (',format.or(m[2,6]),'-',format.or(m[2,7]),')','</font></b></center></font></td>',sep="");
	        }
	        else
	        {
	            if (m[2,7]<1) #ORup < 1, we print it in green
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b><font color="#00CC00">',format.or(m[2,5]),' (',format.or(m[2,6]),'-',format.or(m[2,7]),')','</font></b></center></font></td>',sep="");
	            }
	            else #Non-significant OR
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[2,5]),' (',format.or(m[2,6]),'-',format.or(m[2,7]),')','</center></font></td>',sep="");
	            }
	        }
	    }
	    else
	    {
	    	or <- ifelse(is.na(m[2,5]),"NA",m[2,5]);
	        orlo <- ifelse(is.na(m[2,6]),"NA",m[2,6]);
	        orup <- ifelse(is.na(m[2,7]),"NA",m[2,7]);

	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),' (',format.or(orlo),'-',format.or(orup),')','</center></font></td>',sep="");
	    }
	    cat('</tr>');
	    cat('</tbody>');
    }

    cat("</table>");
    cat("<p></p>");
}

cat.snp.assoc.matrix.cont <- function(m,st,st.name,stradj,num.levels,n,snpname)
{
    cat('<table border rules=groups>');
    if (stradj=="no adjustment")
    {
        cat('<tr bgcolor="#C0C0C0"><td colspan=8><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snpname,' association with response ',st.name,' (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
    }
    else
    {
        cat('<tr bgcolor="#C0C0C0"><td colspan=8><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',snpname,' association with response ',st.name,' (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
    }

    #Headers #########
    cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Model</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Genotype</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>n</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Response mean (s.e.)</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Difference (95% CI)</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>P-value</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>AIC</b></center></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>BIC</b></center></font></td>');

    cat('</tr>');

    if (num.levels==3)
    {
		#Codominant model #########
		cat('<tbody>');
		cat('<tr><td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Codominant</center></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[1],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[1,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[1,2],2),' (',round(m[1,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[1,4]),'</center></font></td>',sep=""); #Response difference (95% CI)
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[1,7]),'</center></font></td>',sep=""); #P-value
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[1,8]),'</center></font></td>',sep=""); #AIC
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[1,9]),'</center></font></td>',sep=""); #BIC
		cat('</tr>');
	    cat('<tr>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[2],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[2,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[2,2],2),' (',round(m[2,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		if (m[2,5]>0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',format.or(m[2,4]),' (',format.or(m[2,5]),' - ',format.or(m[2,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else if (m[2,6]<0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',format.or(m[2,4]),' (',format.or(m[2,5]),' - ',format.or(m[2,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[2,4]),' (',format.or(m[2,5]),' - ',format.or(m[2,6]),')</center></font></td>',sep="");  #Response difference (95% CI)
		}
	    cat('</tr>');
	    cat('<tr>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[3],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[3,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[3,2],2),' (',round(m[3,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		if (m[3,5]>0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',format.or(m[3,4]),' (',format.or(m[3,5]),' - ',format.or(m[3,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else if (m[3,6]<0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',format.or(m[3,4]),' (',format.or(m[3,5]),' - ',format.or(m[3,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[3,4]),' (',format.or(m[3,5]),' - ',format.or(m[3,6]),')</center></font></td>',sep="");  #Response difference (95% CI)
		}
	    cat('</tr>');
	    cat('</tr>');
	    cat('</tbody>');

	    #Dominant model #########
	    cat('<tbody>');
		cat('<tr><td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Dominant</center></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[4],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[4,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[4,2],2),' (',round(m[4,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[4,4]),'</center></font></td>',sep=""); #Response difference (95% CI)
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[4,7]),'</center></font></td>',sep=""); #P-value
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[4,8]),'</center></font></td>',sep=""); #AIC
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[4,9]),'</center></font></td>',sep=""); #BIC
		cat('</tr>');
	    cat('<tr>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[5],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[5,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[5,2],2),' (',round(m[5,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		if (m[5,5]>0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',format.or(m[5,4]),' (',format.or(m[5,5]),' - ',format.or(m[5,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else if (m[5,6]<0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',format.or(m[5,4]),' (',format.or(m[5,5]),' - ',format.or(m[5,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[5,4]),' (',format.or(m[5,5]),' - ',format.or(m[5,6]),')</center></font></td>',sep="");  #Response difference (95% CI)
		}
	    cat('</tr>');
	    cat('</tbody>');

	    #Recessive model #########
	    cat('<tbody>');
		cat('<tr><td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Recessive</center></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[6],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[6,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[6,2],2),' (',round(m[6,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[6,4]),'</center></font></td>',sep=""); #Response difference (95% CI)
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[6,7]),'</center></font></td>',sep=""); #P-value
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[6,8]),'</center></font></td>',sep=""); #AIC
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[6,9]),'</center></font></td>',sep=""); #BIC
		cat('</tr>');
	    cat('<tr>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[7],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[7,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[7,2],2),' (',round(m[7,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		if (m[7,5]>0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',format.or(m[7,4]),' (',format.or(m[7,5]),' - ',format.or(m[7,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else if (m[7,6]<0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',format.or(m[7,4]),' (',format.or(m[7,5]),' - ',format.or(m[7,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[7,4]),' (',format.or(m[7,5]),' - ',format.or(m[7,6]),')</center></font></td>',sep="");  #Response difference (95% CI)
		}
	    cat('</tr>');
	    cat('</tbody>');

	    #Overdominant model #########
	    cat('<tbody>');
		cat('<tr><td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Overdominant</center></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[8],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[8,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[8,2],2),' (',round(m[8,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[8,4]),'</center></font></td>',sep=""); #Response difference (95% CI)
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[8,7]),'</center></font></td>',sep=""); #P-value
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[8,8]),'</center></font></td>',sep=""); #AIC
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[8,9]),'</center></font></td>',sep=""); #AIC
		cat('</tr>');
	    cat('<tr>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[9],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[9,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[9,2],2),' (',round(m[9,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		if (m[9,5]>0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',format.or(m[9,4]),' (',format.or(m[9,5]),' - ',format.or(m[9,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else if (m[9,6]<0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',format.or(m[9,4]),' (',format.or(m[9,5]),' - ',format.or(m[9,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[9,4]),' (',format.or(m[9,5]),' - ',format.or(m[9,6]),')</center></font></td>',sep="");  #Response difference (95% CI)
		}
	    cat('</tr>');
	    cat('</tbody>');

	    #Additive model #########
	    cat('<tr><td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Log-additive</center></font></td>');
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">---</td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
		if (m[10,5]>0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',format.or(m[10,4]),' (',format.or(m[10,5]),' - ',format.or(m[10,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else if (m[10,6]<0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',format.or(m[10,4]),' (',format.or(m[10,5]),' - ',format.or(m[10,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[10,4]),' (',format.or(m[10,5]),' - ',format.or(m[10,6]),')</center></font></td>',sep="");  #Response difference (95% CI)
		}
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[10,7]),'</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[10,8]),'</center></font></td>',sep="");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[10,9]),'</center></font></td>',sep="");
	    cat('</tr>');
    }
    else
    {
	    cat('<tbody>');
		cat('<tr><td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[1],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[1,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[1,2],2),' (',round(m[1,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[1,4]),'</center></font></td>',sep=""); #Response difference (95% CI)
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.pval(m[1,7]),'</center></font></td>',sep=""); #P-value
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[1,8]),'</center></font></td>',sep=""); #AIC
		cat('<td rowspan="3" valign="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.aic(m[1,9]),'</center></font></td>',sep=""); #AIC
	    cat('</tr>');
	
	    cat('<tr>');
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">',rownames(m)[2],'</font></td>',sep=""); #SNP
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[2,1],'</center></font></td>',sep=""); #n
		cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[2,2],2),' (',round(m[2,3],2),')','</center></font></td>',sep=""); #Response mean (se)
		if (m[2,5]>0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',format.or(m[2,4]),' (',format.or(m[2,5]),' - ',format.or(m[2,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else if (m[2,6]<0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',format.or(m[2,4]),' (',format.or(m[2,5]),' - ',format.or(m[2,6]),')</b></center></font></td>',sep="");  #Response difference (95% CI)
		}
		else
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[2,4]),' (',format.or(m[2,5]),' - ',format.or(m[2,6]),')</center></font></td>',sep="");  #Response difference (95% CI)
		}
	    cat('</tr>');
	    cat('</tbody>');
    }

    cat("</table>");
    cat("<p></p>");
}

haplo.df <- function(x)
{
    z <- x$haplo.common
    df <- as.matrix(x$haplo.unique[z, , drop = FALSE])
    y <- x$haplo.freq[z]
    if (x$haplo.rare.term)
    {
        df <- rbind(df, rep("*", ncol(df)))
        y <- c(y, sum(x$haplo.freq[x$haplo.rare]))
    }
    dimnames(df)[[1]] <- x$haplo.names
    df <- rbind(x$haplo.unique[x$haplo.base, ], df)  #We put the base haplotype in the first row of the data frame
    dimnames(df)[[1]][1] <- "haplo.base"
    y <- c(x$haplo.freq[x$haplo.base], y)
    data.frame(df, hap.freq = y)
}

intervals.hap <- function(x, level=.95, sign = 1, FUN=exp)
{
  ncoef <- length(x$coef)
  coef <- x$coef
  se <- sqrt(x$var.mat[cbind(1:ncoef, 1:ncoef)])
  wt <- x$prior.weights * x$haplo.post.info$post
  df.residual <- sum(wt) - length(x$coef)
  df.null <- sum(wt) - 1
  t.stat <- coef/se
  pval <- 2 * (1 - pt(abs(t.stat), df.residual))

    z <- abs(qnorm((1-level)/2));
    or <- exp(x$coefficients * sign);
    li <- exp(x$coefficients * sign -z * se);
    ls <- exp(x$coefficients * sign +z * se);
    r <- cbind(round(or,2), round(li,2), round(ls,2), round(pval,4));

    r <- r[2:(nrow(r)),]; # We keep only the interesting rows (including "rare")
    
    r <- rbind(c(1,NA,NA,NA),r); #We add a new row for the base haplotype

    colnames(r) <- c("OR","Lower","Upper","p");
    rownames(r)[1] <- "haplo.base";
    r
}


intervals.or <- function(x, x.b, var)
{
	# intervals.or(m.co, m.b, var)
	mat.coef <- merge(x$coef, summary(x)$coef, by=0, all.x=T, sort=F)
	nom.pos <- data.frame(names(x$coef), ordre=1:length(x$coef))
	mat.ordre <- merge(nom.pos, mat.coef, by.x=1, by.y=1, all.x=T, sort=F)
	mat.ordre <- mat.ordre[order(mat.ordre$ordre),]

	a <- as.matrix(mat.ordre[,c("Estimate")])
	se <- as.matrix(mat.ordre[,c("Std. Error")])
    
	or <- exp(a)
	li <- exp(a - 1.96 * se)
	ls <- exp(a + 1.96 * se)
	if(missing(var))
	{
		focus <- dim(a)[1.]
		or.ic <- round(cbind(or[focus,  ], li[focus,  ], ls[focus,  ]), 2.)
		or.ic[or.ic > 999.] <- NA
		p.as <- round(anova(x, x.b, test = "Chi")$"Pr(>Chi)"[2], 4)
		or.ic <- cbind(or.ic, p.as)
		dimnames(or.ic) <- NULL
	}
    else
	{
		focus <- dim(a)[1.] - length(levels(var)) + 2:length(levels(var))
		or.ic <- round(cbind(or[focus,  ], li[focus,  ], ls[focus,  ]), 2)
		or.ic[or.ic > 999.] <- NA
		or.ic <- round(rbind(c(1, NA, NA), or.ic), 2)
		p.as <- round(anova(x, x.b, test = "Chi")$"Pr(>Chi)"[2], 4)
		or.ic <- cbind(or.ic, c(p.as, rep(NA, times = length(levels(var)) - 1)))
		dimnames(or.ic) <- list(levels(var), c("   OR ", "li", "ls", "Pvalor"))
	}
	list(or.ic = or.ic)
}

intervals.dif <- function(x, x.b, var, pval=TRUE)
{
	# intervals.dif(m.co, m.b, var)

	mat.coef <- merge(x$coef, summary(x)$coef, by=0, all.x=T, sort=F)
	nom.pos <- data.frame(names(x$coef), ordre=1:length(x$coef))
	mat.ordre <- merge(nom.pos, mat.coef, by.x=1, by.y=1, all.x=T, sort=F)
	mat.ordre <- mat.ordre[order(mat.ordre$ordre),]

	a <- as.matrix(mat.ordre[,c("Estimate")])
	se <- as.matrix(mat.ordre[,c("Std. Error")])

	li <- a - (1.96 * se)
	ls <- a + (1.96 * se)

	if (missing(var))
	{
		focus <- nrow(a);
		m <- cbind(a[focus,],li[focus,],ls[focus,])

		if (pval)
		{
			p.as <- round(anova(x, x.b, test = "F")$"Pr(>F)"[2], 4)
			m <- cbind(m, p.as)
			colnames(m) <- c("dif","lo","up","pval")
		}
		else
		{
			colnames(m) <- c("dif","lo","up")
		}
	}
	else
	{
		focus <- nrow(a) - length(levels(var)) + 2:length(levels(var))
		m <- cbind(a[focus,],li[focus,],ls[focus,])
		m <- rbind(c(0,NA,NA),m)
	
		if (pval)
		{
			p.as <- round(anova(x, x.b, test = "F")$"Pr(>F)"[2], 4)
			m <- cbind(m, c(p.as,rep(NA,times=length(levels(var))-1)))
			colnames(m) <- c("dif","lo","up","pval")
		}
		else
		{
			colnames(m) <- c("dif","lo","up")
		}
	}
	
	list(m=m);
}

glm2 <- function (formula, family = gaussian, data, weights, subset,
    na.action, start = NULL, etastart, mustart, offset, control = glm.control(...),
    model = TRUE, method = "glm.fit", x = FALSE, y = TRUE, contrasts = NULL,
    ...)
{
    call <- match.call()
    if (is.character(family))
        family <- get(family, mode = "function", envir = parent.frame())
    if (is.function(family))
        family <- family()
    if (is.null(family$family)) {
        print(family)
        stop("'family' not recognized")
    }
    if (missing(data))
        data <- environment(formula)
    mf <- match.call(expand.dots = FALSE)
    m <- match(c("formula", "data", "subset", "weights", "na.action",
        "etastart", "mustart", "offset"), names(mf), 0)
    mf <- mf[c(1, m)]

    #####################################################################################################################
    ################################ REMEMBER TO COMMENT THIS LINE WHEN INSTALLING FUTURE VERSIONS OF R #################
    #mf$drop.unused.levels <- TRUE
    #####################################################################################################################
    mf[[1]] <- as.name("model.frame")
    mf <- eval(mf, parent.frame())
    switch(method, model.frame = return(mf), glm.fit = 1, glm.fit.null = 1,
        stop("invalid 'method': ", method))
    mt <- attr(mf, "terms")
    Y <- model.response(mf, "numeric")
    if (length(dim(Y)) == 1) {
        nm <- rownames(Y)
        dim(Y) <- NULL
        if (!is.null(nm))
            names(Y) <- nm
    }
    X <- if (!is.empty.model(mt))
        model.matrix(mt, mf, contrasts)
    else matrix(, NROW(Y), 0)
    weights <- model.weights(mf)
    offset <- model.offset(mf)
    if (!is.null(weights) && any(weights < 0))
        stop("negative weights not allowed")
    if (!is.null(offset) && length(offset) != NROW(Y))
        stop(gettextf("number of offsets is %d should equal %d (number of observations)",
            length(offset), NROW(Y)), domain = NA)
    mustart <- model.extract(mf, "mustart")
    etastart <- model.extract(mf, "etastart")
    fit <- glm.fit(x = X, y = Y, weights = weights, start = start,
        etastart = etastart, mustart = mustart, offset = offset,
        family = family, control = control, intercept = attr(mt,
            "intercept") > 0)
    if (any(offset) && attr(mt, "intercept") > 0) {
        fit$null.deviance <- glm.fit(x = X[, "(Intercept)", drop = FALSE],
            y = Y, weights = weights, offset = offset, family = family,
            control = control, intercept = TRUE)$deviance
    }
    if (model)
        fit$model <- mf
    fit$na.action <- attr(mf, "na.action")
    if (x)
        fit$x <- X
    if (!y)
        fit$y <- NULL
    fit <- c(fit, list(call = call, formula = formula, terms = mt,
        data = data, offset = offset, control = control, method = method,
        contrasts = attr(X, "contrasts"), xlevels = .getXlevels(mt,
            mf)))
    class(fit) <- c("glm", "lm")
    fit
}

taula.corner <- function(var, dep, adj = NULL, int = NULL, num.status)
{
	# taula.corner(Datos$n.edad, Datos$grupo, Datos[,c("sexo","rcal.dia")], dominant(Datos$XRCC1.81))
	# taula.corner(Datos$n.edad, Datos$grupo, Datos[,c("sexo","rcal.dia")], Datos$XRCC1.81)

	if (num.status==0) #Categorical response variable
	{
		var <- as.factor(var)
		dep <- as.factor(dep)

		# Es crea la variable interacci?

	    var.int <- factor(paste(levels(var)[var],levels(int)[int]),levels = outer(levels(var),levels(int),paste), exclude=c(paste(levels(var),""), paste("",levels(int)), paste(" ")));

		# Models
		if (is.null(adj))
		{
	        m.var.int <- glm2(dep~var.int, family = binomial);
	        subset <- 1:length(var.int)%in%as.numeric(rownames(m.var.int$model));
	        m.b   <- glm2(dep~NULL, subset = subset, family = binomial)
	    
	    }
	    else
	    {
	        m.var.int <- glm2(dep~. + var.int, family = binomial, data=adj);
	        subset <- 1:length(var.int)%in%as.numeric(rownames(m.var.int$model));
	        m.b   <- glm2(dep~., subset = subset, family = binomial, data=adj)
	    }
	        
	    res <- cbind(table(var.int[subset], dep[subset]), intervals.or(m.var.int,m.b, var.int)$or.ic)[,1:5]
	
	    i <- 1;
	    j <- 1;
	    step <- length(levels(var));
	    taula.int <- NULL;
	    while (i <= nrow(res))
	    {
	        aux <- res[i:(i+step-1),];
	        colnames(aux)[3] <- levels(int)[j];
	        taula.int <- cbind(taula.int, aux);
	        i <- i + step;
	        j <- j + 1;
	    }
	    rownames(taula.int) <- levels(var);
	
	    taula.int
	}
	else #continuous response variable
	{
		var <- as.factor(var)

		# Es crea la variable interacci?

	    var.int <- factor(paste(levels(var)[var],levels(int)[int]), levels=outer(levels(var),levels(int),paste),
	                      exclude=c(paste(levels(var), ""), paste("", levels(int)), paste(" ")));

		# Models
		if (is.null(adj))
		{
	        m.var.int <- glm2(dep~var.int, family = gaussian);
	        subset <- 1:length(var.int)%in%as.numeric(rownames(m.var.int$model));
	        m.b   <- glm2(dep~NULL, subset = subset, family = gaussian)
	    }
	    else
	    {
	        m.var.int <- glm2(dep~. + var.int, family = gaussian, data=adj);
	        subset <- 1:length(var.int)%in%as.numeric(rownames(m.var.int$model));
	        m.b   <- glm2(dep~., subset = subset, family = gaussian, data=adj)
	    }

	    res <- cbind(Taula.mean.se(var.int, dep, subset)$tp, intervals.dif(m.var.int,m.b, var.int,pval=FALSE)$m);

	    i <- 1;
	    j <- 1;
	    step <- length(levels(var));
	    taula.int <- NULL;
	    while (i <= nrow(res))
	    {
	        aux <- res[i:(i+step-1),];
	        colnames(aux)[3] <- levels(int)[j];
	        taula.int <- cbind(taula.int, aux);
	        i <- i + step;
	        j <- j + 1;
	    }
	    rownames(taula.int) <- levels(var);

	    taula.int;
	}
}

p.haplo <- function(mod, dep, adj = NULL, fam, freqmin)
{
	# p.haplo(genotip, Datos$grupo)
	# p.haplo(genotip, Datos$grupo, Datos[,c("sexo")])
	 
	# Calculo la p d'associaci? pels haplotips
	 
	# La variable geno ?s del tipus: (genotip <- setupGeno(cbind(allele(g.81,1:2), allele(g.82,1:2), allele(g.83,1:2))) on g.81<-genotype(XRCC1.81)  )
	# dep (Variable depenent)
	# adj (Variables d'ajust)
	 
	# Haplo.freq.min ?s 0.01
	    
	# Models

	if (is.null(adj))
	{
		#mod <- haplo.glm(dep~geno, family=fam, allele.lev=attributes(geno)$unique.alleles, control=haplo.glm.control(haplo.freq.min=freqmin)) 
		#if (fam=="binomial")
		#{
		#	pval.haplo <- round(anova(mod, test = "Chi")$"Pr(>Chi)"[2], 4)
		#}
		#else
		#{
    #  pval.haplo <- round(anova(mod, test = "F")$"Pr(>F)"[2], 4)
		#}

    pval.haplo <- 1-pchisq(mod$lrt$lrt, mod$lrt$df)
	}
	else
	{
		adj <- as.data.frame(adj);
		#mod <- haplo.glm(dep~.+geno, family=fam, allele.lev=attributes(geno)$unique.alleles, control=haplo.glm.control(haplo.freq.min=freqmin), data=adj) 
		mod.b <- glm(dep~., family=fam, data=adj)
    dev.mod.b <- mod.b$null.dev-mod.b$dev
    df.mod.b <- mod.b$df.null-mod.b$df.resid

    #############################################################################
    #############################################################################
    ######### WARNING: WRONG COMMAND: NEED TO USE A F INTEAD oF CHISQ ###########
           
    pval.haplo <- 1-pchisq(mod$lrt$lrt-dev.mod.b, mod$lrt$df-df.mod.b)

    #############################################################################
    #############################################################################    
    
    
		#if (fam=="binomial")
		#{
		#	pval.haplo <- round(anova(mod, mod.b, test = "Chi")$"Pr(>Chi)"[2], 4)
		#}
		#else
		#{
    #  pval.haplo <- round(anova(mod, mod.b, test = "F")$"Pr(>F)"[2], 4)
		#}
	}

	pval.haplo;
}

haplo.inter <- function(geno, var2, dep, adj = NULL,fam,haplo.freq.min,num.status)
{
  
	param <- "var2"; #This is the name of the formal parameter that contains the interaction variable

	# haplo.inter(genotip, Datos$sexo, Datos$grupo)
	# haplo.inter(genotip, Datos$sexo, Datos$grupo, Datos[,c("rcal.dia", "n.edad")],0.005,1)

	# Funci? que retorna les tres taules d'interaccions a partir dels coef i se de l'ajust d'un model haplo.glm

	# Li passo els seguents par?metres per crear un model haplo.glm amb interaccions

	# La variable geno ?s del tipus: (genotip <- setupGeno(cbind(allele(g.81,1:2), allele(g.82,1:2), allele(g.83,1:2))) on g.81<-genotype(XRCC1.81)  )
	# var2 (Variable que interacciona amb l'haplotip)
	# dep (Variable depenent)
	# adj (Variables d'ajust)
	# fam (funci? pel glm "binomial"/"gaussian")
	# haplo.freq.min (haplo.freq.min = 0.01) Frequ?ncia m?nima haplot?pica.
	# num.status (variable resposta categ?rica o num?rica?)

	if(is.factor(dep)) dep<-as.numeric(dep)-1  ## VM must be numeric
	
	# Models
	if (is.null(adj))
	{
	  mod <- haplo.glm(dep~geno*var2, family=fam, allele.lev=attributes(geno)$unique.alleles, control=haplo.glm.control(haplo.freq.min=haplo.freq.min))
	  mod.b <- haplo.glm(dep~geno+var2, family=fam, allele.lev=attributes(geno)$unique.alleles, control=haplo.glm.control(haplo.freq.min=haplo.freq.min))
	}
	else
	{
		mod <- haplo.glm(dep~.+geno*var2, family=fam, allele.lev=attributes(geno)$unique.alleles, control=haplo.glm.control(haplo.freq.min=haplo.freq.min), data=adj)
		mod.b <- haplo.glm(dep~.+geno+var2, family=fam, allele.lev=attributes(geno)$unique.alleles, control=haplo.glm.control(haplo.freq.min=haplo.freq.min), data=adj)
	}


	# Calculo la p d'interacci? entre l'haplotip i la variable
	pval.haplo <- 1-pchisq(mod$lrt$lrt-mod.b$lrt$lrt, mod$lrt$df-mod.b$lrt$df)

	#  Guardo els coeficients en el vector co
	co <- mod$coef
	noms.coef <- names(co)

	# Matriu de covari?ncies
	# Selecciono les mateixes files i columnes que a la matriu de coef, ja que la matriu q retorna mod$var.mat no t? dimnames i estan tots els haplotips sense agrupar els rare. 

	mat.cov <- mod$var.mat[1:length(mod$coef), 1:length(mod$coef)]
	dimnames(mat.cov)<- list(names(mod$coef), names(mod$coef))

	# Creo la nova matriu (mat.coef) amb els resultats dels coeficients, per files var2 i columnes geno, amb el format de taula final.
	mat.coef <- matrix(nrow=1+length(mod$haplo.names), ncol=length(levels(var2)))
	dimnames(mat.coef) <- list(c(mod$haplo.base, mod$haplo.names), levels(var2))

	# Creo una matriu amb les vari?ncies del mateix format que la de coeficients.
	mat.var <- mat.coef
	mat.coef[1,1] <- 0 # Refer?ncia

	# creo matrius per taules marginals de row i col
	mat.coef.c <- mat.coef
	mat.var.c <- mat.var
	mat.coef.r <- mat.coef
	mat.var.r <- mat.var
 
	# Inicialitzo i, j
	i <- 1
	j <- 1

	# Selecciono la posici? dels efectes principals (de tot el conjunt elimino les interaccions)
	# Omplo la primera columna (correspon als efectes principals de la geno)
	for (i in 1:(dim(mat.coef)[1]-1))
	{
		pos <- rownames(mat.coef)[i+1];

		mat.coef[i+1,1] <- co[pos];
		mat.var[i+1,1] <- mat.cov[pos,pos];
		mat.coef.c[i+1,1] <- co[pos]
		mat.var.c[i+1,1] <- mat.cov[pos,pos]
		mat.coef.r[i+1,1] <- NA
		mat.var.r[i+1,1] <- NA
	}

	# Omplo la primera fila (correspon als efectes principals de la var2)
	for (j in 1:(dim(mat.coef)[2]-1))
	{
		pos <- paste(param,colnames(mat.coef)[j+1],sep="");

		mat.coef[1,j+1] <- co[pos];
		mat.var[1,j+1] <- mat.cov[pos,pos];

		mat.coef.c[1,j+1] <- NA
		mat.var.c[1,j+1] <- NA

		mat.coef.r[1,j+1] <- co[pos]
		mat.var.r[1,j+1] <- mat.cov[pos,pos]
	}

	# Omplo les interaccions

	for (j in 1:(dim(mat.coef)[2]-1))
	{
		for (i in 1:(dim(mat.coef)[1]-1))
		{

			pos.x <- rownames(mat.coef)[i+1];
			pos.y <- paste(param,colnames(mat.coef)[j+1],sep="");
			pos.xy <- paste(rownames(mat.coef)[i+1],":",param,colnames(mat.coef)[j+1],sep="");

			mat.coef[i+1,j+1] <- mat.coef[i+1,1] + mat.coef[1,j+1] + co[pos.xy]
			mat.var[i+1,j+1]  <- mat.var[i+1,1] + mat.var[1,j+1] + mat.cov[pos.xy, pos.xy] + 2*(mat.cov[pos.x, pos.y] + mat.cov[pos.x, pos.xy] + mat.cov[pos.y, pos.xy])

			mat.coef.c[i+1,j+1] <- mat.coef.c[i+1,1] + co[pos.xy]
			mat.var.c[i+1,j+1]  <- mat.var.c[i+1,1] +  mat.cov[pos.xy, pos.xy] + 2*mat.cov[pos.x, pos.xy]

			mat.coef.r[i+1,j+1] <- mat.coef.r[1,j+1] + co[pos.xy]
			mat.var.r[i+1,j+1]  <- mat.var.r[1,j+1] + mat.cov[pos.xy, pos.xy] + 2*mat.cov[pos.y, pos.xy]
		}
	}

	# Calculo la matriu d'ORs/coefs i ICs
	mat.or <- mat.coef
	mat.li <- mat.coef - (1.96 * sqrt(mat.var))
	mat.ls <- mat.coef + (1.96 * sqrt(mat.var))

	mat.or.c <- mat.coef.c
	mat.li.c <- mat.coef.c - (1.96 * sqrt(mat.var.c))
	mat.ls.c <- mat.coef.c + (1.96 * sqrt(mat.var.c))

	mat.or.r <- mat.coef.r
	mat.li.r <- mat.coef.r - (1.96 * sqrt(mat.var.r))
	mat.ls.r <- mat.coef.r + (1.96 * sqrt(mat.var.r))

	#En cas de regressi? log?stica transformem els coeficients a OR's
	if (fam=="binomial")
	{
		mat.or <- exp(mat.or)
		mat.li <- exp(mat.li)
		mat.ls <- exp(mat.ls)

		mat.or.c <- exp(mat.or.c)
		mat.li.c <- exp(mat.li.c)
		mat.ls.c <- exp(mat.ls.c)

		mat.or.r <- exp(mat.coef.r)
		mat.li.r <- exp(mat.coef.r - 1.96 * sqrt(mat.var.r))
		mat.ls.r <- exp(mat.coef.r + 1.96 * sqrt(mat.var.r))
	}

	# Ordeno les tres matrius d'ORs i IC en una taula final (mat.fi)
	mat.fi <- NULL
	mat.fi.c <- NULL
	mat.fi.r <- NULL
	i <- 1
	j <- 1

	for(i in 1:length(levels(var2)))
	{
		mat.fi <- cbind(mat.fi, mat.or[,i], mat.li[,i], mat.ls[,i])
		dimnames(mat.fi)[[2]][j:(j+2)] <- c(dimnames(mat.or)[[2]][i], "li", "ls")

		mat.fi.c <- cbind(mat.fi.c, mat.or.c[,i], mat.li.c[,i], mat.ls.c[,i])
		dimnames(mat.fi.c)[[2]][j:(j+2)] <- c(dimnames(mat.or.c)[[2]][i], "li", "ls")
		mat.fi.r <- cbind(mat.fi.r, mat.or.r[,i], mat.li.r[,i], mat.ls.r[,i])
		dimnames(mat.fi.r)[[2]][j:(j+2)] <- c(dimnames(mat.or.r)[[2]][i], "li", "ls")

		j <- j + 3
	}

	# Afegeixo una primera columna a mat.fi amb la frequ?ncia dels haplotips
	HapFreq <- NA
	mat.fi <- cbind(HapFreq, mat.fi)
	mat.fi.c <- cbind(HapFreq, mat.fi.c)
	mat.fi.r <- cbind(HapFreq, mat.fi.r)

	# Arreglo les etiquetes de les files de la matriu corresponent als haplotips.
	# Elimino de les etiquetes el "geno.", de forma que em quedi nom?s el n?mero (geno.1 per 1),
	# per aix? selecciono a partir de la posici? 6 i fins la 9 pensant que el m?xim de llargada s?n els rare.
	# I selecciono a partir de la segona fila pq a la primera hi ha el base que ja ?s sempre un n?mero.

	dimnames(mat.fi)[[1]][2:nrow(mat.fi)] <- substr(dimnames(mat.fi)[[1]][2:nrow(mat.fi)], 6,9)
	dimnames(mat.fi.c)[[1]][2:nrow(mat.fi.c)] <- substr(dimnames(mat.fi.c)[[1]][2:nrow(mat.fi.c)], 6,9)
	dimnames(mat.fi.r)[[1]][2:nrow(mat.fi.r)] <- substr(dimnames(mat.fi.r)[[1]][2:nrow(mat.fi.r)], 6,9)

	# Un cop tinc els dimnames amb n?meros (3,4,...), li ajunto les etiquetes i freq. haplot?piques que li corresponen.
	# Ex: geno.2, ara ?s 2, i correspon a CGA, freq 0.34.
	i <- 1

	for(i in 1:nrow(mat.fi))
	{
		if (dimnames(mat.fi)[[1]][i]!="rare")
		{
			num <- as.numeric(dimnames(mat.fi)[[1]][i]) 
			mat.fi[i,c("HapFreq")] <- mod$haplo.freq[num]
			dimnames(mat.fi)[[1]][i] <- paste(mod$haplo.unique[num,], collapse="")

			mat.fi.c[i,c("HapFreq")] <- mod$haplo.freq[num]
			dimnames(mat.fi.c)[[1]][i] <- paste(mod$haplo.unique[num,], collapse="")
			mat.fi.r[i,c("HapFreq")] <- mod$haplo.freq[num]
			dimnames(mat.fi.r)[[1]][i] <- paste(mod$haplo.unique[num,], collapse="")
		}
 		else if (dimnames(mat.fi)[[1]][i]=="rare")
 		{
			mat.fi[i,c("HapFreq")] <- 1-sum(mat.fi[1:(nrow(mat.fi)-1),1])
			mat.fi.c[i,c("HapFreq")] <- 1-sum(mat.fi.c[1:(nrow(mat.fi.c)-1),1])
			mat.fi.r[i,c("HapFreq")] <- 1-sum(mat.fi.r[1:(nrow(mat.fi.r)-1),1])
		}
	}

	# Ordeno la taula final per frequ?ncia haplot?pica (de major a menor), deixant els rare sempre al final.
	# I suposant que el haplobase sempre ser? el m?s frequent i quedar? a la primera categoria ( en cas que no fos aix? no passaria res, nom?s que 
	# la categoria de refer?ncia no es mostraria a la primera fila.

	mat.fi <- mat.fi[c(order(mat.fi[1:(nrow(mat.fi)-1),c("HapFreq")], decreasing=T), nrow(mat.fi)),]
	mat.fi.c <- mat.fi.c[c(order(mat.fi.c[1:(nrow(mat.fi.c)-1),c("HapFreq")], decreasing=T), nrow(mat.fi.c)),]
	mat.fi.r <- mat.fi.r[c(order(mat.fi.r[1:(nrow(mat.fi.r)-1),c("HapFreq")], decreasing=T), nrow(mat.fi.r)),]

	if (fam=="binomial")
	{
		# Si hi ha algun valor molt gran a la taula final li assigno el valor Inf.
		mat.fi[mat.fi>999] <- Inf
		mat.fi.c[mat.fi.c>999] <- Inf
		mat.fi.r[mat.fi.r>999] <- Inf
	}

	# Arrodoneixo a 4 decimals la frequ?ncia haplot?pica i la resta a 2.
	mat.fi[, c("HapFreq")] <- round(mat.fi[, c("HapFreq")], 4)
	mat.fi[, 2:ncol(mat.fi)] <- round(mat.fi[, 2:ncol(mat.fi)], 2)

	mat.fi.c[, c("HapFreq")] <- round(mat.fi.c[, c("HapFreq")], 4)
	mat.fi.c[, 2:ncol(mat.fi.c)] <- round(mat.fi.c[, 2:ncol(mat.fi.c)], 2)

	mat.fi.r[, c("HapFreq")] <- round(mat.fi.r[, c("HapFreq")], 4)
	mat.fi.r[, 2:ncol(mat.fi.r)] <- round(mat.fi.r[, 2:ncol(mat.fi.r)], 2)

	list(mat.fi=mat.fi, mat.fi.c=mat.fi.c, mat.fi.r=mat.fi.r, pval=pval.haplo)
}

taula.int <- function(var, dep, adj = NULL, int, num.status)
{       
	# taula.int(Datos$XRCC1.81, Datos$grupo, Datos[,c("sexo", "rcal.dia")], Datos$n.edad)
	# taula.int(Datos$XRCC1.81, Datos$grupo, NULL, Datos$n.edad)

	if (num.status==0) #Categorical response variable
	{
	    var <- as.factor(var)
	    dep <- as.factor(dep)

	    if (is.null(adj))
	    {
	        m.t  <- glm(dep~ as.numeric(var) + int, family = binomial)

	        subset <- 1:length(var)%in%as.numeric(rownames(m.t$model));

	        m.b   <- glm(dep~ var + int,         subset = subset, family = binomial)
	        m.int <- glm(dep~ var/int,         subset = subset, family = binomial)
	        m.t.int <- glm(dep~ as.numeric(var) * int, subset = subset, family = binomial)
	    }
	    else
	    {
	        m.t  <- glm(dep~. + as.numeric(var) + int, family = binomial, data=adj)

	        subset <- 1:length(var)%in%as.numeric(rownames(m.t$model));

	        m.b   <- glm(dep~. + var + int,         subset = subset, family = binomial, data=adj)
	        m.int <- glm(dep~. + var/int,         subset = subset, family = binomial, data=adj)
	        m.t.int <- glm(dep~. + as.numeric(var) * int, subset = subset, family = binomial, data=adj)
	    }

		var.int <- factor(paste(levels(var)[var], levels(int)[int]), levels = outer(levels(var), levels(int), paste),
						  exclude = c(paste(levels(var), ""), paste("", levels(int)), paste(" ")))
	
		ta <- table(var.int[subset], dep[subset])

		# Matriu de coeficients i cov
	
		mat.coef <- merge(m.int$coef, summary(m.int)$coef, by=0, all.x=T, sort=F)
		nom.pos <- data.frame(names(m.int$coef), ordre=1:length(m.int$coef))
		mat.ordre <- merge(nom.pos, mat.coef, by.x=1, by.y=1, all.x=T, sort=F)
		mat.ordre <- mat.ordre[order(mat.ordre$ordre),]
	
		a <- as.matrix(mat.ordre[,c("Estimate")])
		se <- as.matrix(mat.ordre[,c("Std. Error")])
		mat <- cbind(a, se)
		selec <- dim(mat)[1.] - (length(levels(int)) - 1.) * length(levels(var))
		o <- (selec + 1.):dim(mat)[1.]
		k <- matrix(nrow = length(levels(var)), ncol = 3.)
		k[, 1.] <- 1.
		taula <- cbind(exp(mat[o, 1.]), exp(mat[o, 1.] - 1.96 * mat[o, 2.]), exp(mat[o, 1.] + 1.96 * mat[o, 2.]))
		taula[taula > 999.] <- NA
		ktaula <- rbind(k, round(taula, 2.))

		ktaula <- cbind(ta, ktaula)
	
		i <- 1;
		j <- 1;
		step <- length(levels(var));
		taula.int <- NULL;
		while (i <= nrow(ktaula))
	    {
			aux <- ktaula[i:(i+step-1),];
			colnames(aux)[3] <- levels(int)[j];
			taula.int <- cbind(taula.int, aux);
			i <- i + step;
			j <- j + 1;
		}

		#Check if interaction pvalues are NA
		pval <- anova(m.b, m.int, test = "Chi")$"Pr(>Chi)"[2];
		if (is.na(pval))
		{
			pval <- "NA";
		}
		else
		{
			pval <- format.pval(pval);
		}
		
		pval.trend <- anova(m.t, m.t.int, test = "Chi")$"Pr(>Chi)"[2];
		if (is.na(pval.trend))
		{
			pval.trend <- "NA";
		}
		else
		{
			pval.trend <- format.pval(pval.trend);
		}
		rownames(taula.int) <- levels(var);
		list(table=taula.int,pval=pval,trend=pval.trend);
	}
	else #Continuous response variable
	{
	    var <- as.factor(var)

	    if (is.null(adj))
	    {
	        m.t  <- glm(dep~as.numeric(var) + int, family = gaussian)

	        subset <- 1:length(var)%in%as.numeric(rownames(m.t$model));

	        m.b   <-   glm(dep~ var + int,             subset = subset, family = gaussian)
	        m.int <-   glm(dep~ var/int,               subset = subset, family = gaussian)
	        m.t.int <- glm(dep~ as.numeric(var) * int, subset = subset, family = gaussian)
	    }
	    else
	    {
	        m.t  <- glm(dep~. + as.numeric(var) + int, family = gaussian, data=adj)

	        subset <- 1:length(var)%in%as.numeric(rownames(m.t$model));

	        m.b <-     glm(dep~. + var + int,             subset = subset, family = gaussian, data=adj)
	        m.int <-   glm(dep~. + var/int,               subset = subset, family = gaussian, data=adj)
	        m.t.int <- glm(dep~. + as.numeric(var) * int, subset = subset, family = gaussian, data=adj)
	    }
		var.int <- factor(paste(levels(var)[var], levels(int)[int]), levels = outer(levels(var), levels(int), paste),
						  exclude = c(paste(levels(var), ""), paste("", levels(int)), paste(" ")))

		# Matriu de coeficients i cov

		mat.coef <- merge(m.int$coef, summary(m.int)$coef, by=0, all.x=T, sort=F)
		nom.pos <- data.frame(names(m.int$coef), ordre=1:length(m.int$coef))
		mat.ordre <- merge(nom.pos, mat.coef, by.x=1, by.y=1, all.x=T, sort=F)
		mat.ordre <- mat.ordre[order(mat.ordre$ordre),]
	
		a <- as.matrix(mat.ordre[,c("Estimate")])
		se <- as.matrix(mat.ordre[,c("Std. Error")])
		mat <- cbind(dif=a, lo=a-(1.96*se), up=a+(1.96*se))
		selec <- dim(mat)[1] - (length(levels(int)) - 1.) * length(levels(var))
		o <- (selec + 1):dim(mat)[1]
		mat <- mat[o,];
		
		i <- 1;
		while (i <= length(levels(var)))
		{
			mat <- rbind(c(0,NA,NA),mat);
			i <- i + 1;
		}
        
	    res <- cbind(Taula.mean.se(var.int, dep, subset)$tp, mat);

	    i <- 1;
	    j <- 1;
	    step <- length(levels(var));
	    taula.int <- NULL;
	    while (i <= nrow(res))
	    {
	        aux <- res[i:(i+step-1),];
	        colnames(aux)[3] <- levels(int)[j];
	        taula.int <- cbind(taula.int, aux);
	        i <- i + step;
	        j <- j + 1;
	    }

		pval <- anova(m.b, m.int, test = "Chi")$"Pr(>Chi)"[2];
		if (is.na(pval))
		{
			pval <- "NA";
		}
		else
		{
			pval <- format.pval(pval);
		}
		
		pval.trend <- anova(m.t, m.t.int, test = "Chi")$"Pr(>Chi)"[2];
		if (is.na(pval.trend))
		{
			pval.trend <- "NA";
		}
		else
		{
			pval.trend <- format.pval(pval.trend);
		}
	    rownames(taula.int) <- levels(var);
		list(table=taula.int,pval=pval,trend=pval.trend);
	}
}

# Function which prints the interaction table.
cat.haplo.interaction.matrix <- function(m, st.name, mode, stradj, var.name, pval=NULL, n, num.status)
{
    #For each category in the 2nd interaction variable we have 3 columns (OR, ORlo, ORup)
    numcols <- (ncol(m)-1)/3;

    cat("<table border>");

    if (mode==1)
    {
        if (stradj=="no adjustment")
        {
			cat('<tr bgcolor="#C0C0C0"><td colspan=',numcols+2,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotype and ',var.name,' cross-classification interaction table (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
        }
        else
        {
			cat('<tr bgcolor="#C0C0C0"><td colspan=',numcols+2,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotype and ',var.name,' cross-classification interaction table (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
        }
    }
    else if (mode==2)
    {
        if (stradj=="no adjustment")
        {
            cat('<tr bgcolor="#C0C0C0"><td colspan=',numcols+2,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotypes within ',var.name,' (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
        }
        else
        {
            cat('<tr bgcolor="#C0C0C0"><td colspan=',numcols+2,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Haplotypes within ',var.name,' (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
        }
    }
    else
    {
        if (stradj=="no adjustment")
        { 
            cat('<tr bgcolor="#C0C0C0"><td colspan=',numcols+2,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',var.name,' within haplotypes (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
        }
        else
        {
            cat('<tr bgcolor="#C0C0C0"><td colspan=',numcols+2,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',var.name,' whithin haplotypes (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
        }
    }

    cat("<tr>");
    cat('<td><font size="2"></font></td>');
    cat('<td><font size="2"></font></td>');
    i <- 2;
    while (i <= ncol(m))
    {
        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',colnames(m)[i],'</b></center></font></td>',sep="");
        i <- i + 3;
    }
    cat("</tr>");

    cat("<tr>");
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Haplotype</b></font></td>');
    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Frequency</b></font></td>');
    i <- 1;
    while (i <= numcols)
    {
		if (num.status==0)
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>OR (95% CI)</b></center></font></td>');
		}
		else
		{
			cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Difference<br>(95% CI)</b></center></font></td>');
		}
		i <- i + 1;
    }
    cat("</tr>");

    j <- 1;
    while (j <= nrow(m))
    {
        cat("<tr>");
        cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',rownames(m)[j],"</b></font></td>",sep="");
        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[j,1],4),"</center></font></td>",sep="");

        i <- 2;
        while (i <= ncol(m))
        {
            if (((j==1) & (mode==2)) | ((i==2) & (mode==3)) | ((j==1) & (i==2) & (mode==1)))
            {
            	if (num.status==0)
            	{
                	cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>1.00</center></font></td>',sep="");
                }
                else
                {
                	cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>0.00</center></font></td>',sep="");
                }
            }
            else
            {
                if (!is.finite(m[j,i]) | !is.finite(m[j,i+1]) | !is.finite(m[j,i+2]))
                {
                	if (is.na(m[j,i])) #Case NA (NA-NA)
                	{
                        cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
					}
					else
					{
						if (!is.finite(m[j,i]))
						{
							cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>Inf</center></font></td>',sep="");
						}
						else
						{
							if (m[j,i]==0)
							{
								cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>0.00 (0.00 - Inf)</center></font></td>',sep="");
							}
						}
					}
                }
                else
                {
					if (m[j,i+1] != m[j,i+2])
					{
	                	if (num.status==0)
	                	{
	                        if (m[j,i+1]>1) #ORlo>1, we print it in red
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b><center>',format.or(m[j,i])," (",format.or(m[j,i+1])," - ",format.or(m[j,i+2]),")</center></b></font></td>",sep="");
	                        }
	                        else if (m[j,i+2]<1) #ORup<1, we print it in green
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><b><center>',format.or(m[j,i])," (",format.or(m[j,i+1])," - ",format.or(m[j,i+2]),")</center></b></font></td>",sep="");
	                        }
	                        else #Non-significant OR
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[j,i])," (",format.or(m[j,i+1])," - ",format.or(m[j,i+2]),")</center></font></td>",sep="");
	                        }
	                    }
	                    else
	                    {
	                        if (m[j,i+1]>0) #Diflo>0, we print it in red
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b><center>',format.or(m[j,i])," (",format.or(m[j,i+1])," - ",format.or(m[j,i+2]),")</center></b></font></td>",sep="");
	                        }
	                        else if (m[j,i+2]<0) #Difup<0, we print it in green
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><b><center>',format.or(m[j,i])," (",format.or(m[j,i+1])," - ",format.or(m[j,i+2]),")</center></b></font></td>",sep="");
	                        }
	                        else #Non-significant Difference
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[j,i])," (",format.or(m[j,i+1])," - ",format.or(m[j,i+2]),")</center></font></td>",sep="");
	                        }
	                    }
	                }
                    else #Possibly there are some calculation problems
                    {
						cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[j,i]),' (-Inf - Inf)</center></font></td>',sep="");
                    }
                }
            }
            i <- i + 3;
        }
        cat("</tr>");

        j <- j + 1;
    }

	if (mode==1) #We only write the pvalue for the corner table
	{
		cat('<tr><td colspan=',numcols+2,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Interaction p-value: </b>',sep="");
	    if (pval < 0.05)
	    {
	        cat('<font color="#FF0000"><b>',format.pval(pval),'</b></font>',sep="");
	    }
	    else
	    {
	        cat(format.pval(pval));
	    }
	    cat('</font></td></tr>');
	}
	cat("</table>");
	cat("<p></p>");
}

# Function which prints the interaction table.
cat.interaction.matrix <- function(m, st.name, mode, stradj, var1.name, var2.name, pval=NULL, trend=NULL, n)
{
    if (mode==1) #Corner table
    {
	    #For each category the 2nd interaction variable we have 5 columns (Ca, Co, OR, ORlo, ORup)
	    numcols <- ncol(m)/5;
	    cat1 <- colnames(m)[1];
	    cat2 <- colnames(m)[2];
	    
	    cat("<table border>");

            if (stradj=="no adjustment")
            {
                cat('<tr bgcolor="#C0C0C0"><td colspan=',(numcols*3)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',var1.name,' and ',var2.name,' cross-classification interaction table (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
            }
            else
            {
                cat('<tr bgcolor="#C0C0C0"><td colspan=',(numcols*3)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',var1.name,' and ',var2.name,' cross-classification interaction table (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
            }

	    cat("<tr>");
	    cat('<td><font size="2"></font></td>');
	    i <- 1;
	    while (i <= numcols)
	    {
	        cat('<td colspan=3><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',colnames(m)[(5*i)-2],'</b></center></font></td>',sep="");
	        i <- i + 1;
	    }
	    cat("</tr>");
	    
	    cat("<tr>");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>');
	    i <- 1;
	    while (i <= numcols)
	    {
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',st.name,'=',cat1,'</b></center></font></td>',sep="");
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',st.name,'=',cat2,'</b></center></font></td>',sep="");
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>OR (95% CI)</b></center></font></td>');
	        i <- i + 1;
	    }
	    cat("</tr>");
	
	    j <- 1;
	    while (j <= nrow(m))
	    {
	        cat("<tr>");
	        cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',rownames(m)[j],"</b></font></td>",sep="");
	
	        i <- 1;
	        while (i <= ncol(m))
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[j,i],"</center></font></td>",sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[j,i+1],"</center></font></td>",sep="");
	            if ((j == 1) & (i==1))
	            {
	                cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[j,i+2]),"</center></font></td>",sep="");
	            }
	            else
	            {
	                if (is.na(m[j,i+2]) | is.na(m[j,i+3]) | is.na(m[j,i+4]))
	                {
	                    or <- ifelse(is.na(m[j,i+2]),"NA",m[j,i+2]);
	                    orlo <- ifelse(is.na(m[j,i+3]),"NA",m[j,i+3]);
	                    orup <- ifelse(is.na(m[j,i+4]),"NA",m[j,i+4]);

                        if (or != "NA")
                        {
                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),'</center></font></td>',sep="");
                        }
                        else
                        {
                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
                        }
	                }
	                else
	                {
	                    if (is.na(m[j,i+3]) | is.na(m[j,i+4]))
	                    {
	                        cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[j,i+2]),"</center></font></td>",sep="");
	                    }
	                    else
	                    {
	                        if (m[j,i+3]>1) #ORlo>1, we print it in red
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b><center>',format.or(m[j,i+2])," (",format.or(m[j,i+3]),"-",format.or(m[j,i+4]),")</center></b></font></td>",sep="");
	                        }
	                        else if (m[j,i+4]<1) #ORup<1, we print it in green
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><b><center>',format.or(m[j,i+2])," (",format.or(m[j,i+3]),"-",format.or(m[j,i+4]),")</center></b></font></td>",sep="");
	                        }
	                        else #Non-significant OR
	                        {
	                            cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[j,i+2])," (",format.or(m[j,i+3]),"-",format.or(m[j,i+4]),")</center></font></td>",sep="");
	                        }
	                    }
	                }
	            }
	            i <- i + 5;
	        }
	        cat("</tr>");
	
	        j <- j + 1;
	    }
	    
		cat('<tr><td colspan=',(numcols*3)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Interaction p-value: </b>',sep="");
        if (pval < 0.05)
        {
            cat('<font color="#FF0000"><b>',pval,'</b></font>',sep="");
        }
        else
        {
            cat(pval);
        }
        cat('</font></td></tr>');
		cat("</table>");
		cat("<p></p>");
    }
    else #Within table
    {
	    numcols <- ncol(m)/5;
	    cat1 <- colnames(m)[1];
	    cat2 <- colnames(m)[2];

	    cat("<table border>");

        if (stradj=="no adjustment")
        {
            cat('<tr bgcolor="#C0C0C0"><td colspan=2><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',var2.name,' within ',var1.name,' (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
        }
        else
        {
            cat('<tr bgcolor="#C0C0C0"><td colspan=2><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',var2.name,' within ',var1.name,' (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
        }

	    i <- 1;
	    while (i<=nrow(m))
	    {
	        cat("<tr>");
			cat('<td valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',rownames(m)[i],"</b></center></font></td>",sep="");
			cat("<td>");
			cat("<table>");
			cat("<tr>");
			cat("<td>   </td>");
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',st.name,'=',cat1,'</b></center></font></td>',sep="");
		    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',st.name,'=',cat2,'</b></center></font></td>',sep="");
		    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>OR (95% CI)</b></center></font></td>');
			cat("</tr>");
			j <- 1;
			while (j<=ncol(m))
			{
			    cat("<tr>");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',colnames(m)[j+2],"</b></font></td>",sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[i,j],"</center></font></td>",sep="");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[i,j+1],"</center></font></td>",sep="");
	            if (is.na(m[i,j+2]) | is.na(m[i,j+3]) | is.na(m[i,j+4]))
	            {
	                or <- ifelse(is.na(m[i,j+2]),"NA",m[i,j+2]);
	                orlo <- ifelse(is.na(m[i,j+3]),"NA",m[i,j+3]);
	                orup <- ifelse(is.na(m[i,j+4]),"NA",m[i,j+4]);
	
	                    if (or != "NA")
	                    {
	                        cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(or),'</center></font></td>',sep="");
	                    }
	                    else
	                    {
	                        cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
	                    }
	                }
	            else
	            {
	                if (m[i,j+3]>1) #ORlo>1, we print it in red
	                {
	                    cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b><center>',format.or(m[i,j+2])," (",format.or(m[i,j+3]),"-",format.or(m[i,j+4]),")</center></b></font></td>",sep="");
	                }
	                else if (m[i,j+4]<1) #ORup<1, we print it in green
	                {
	                    cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><b><center>',format.or(m[i,j+2])," (",format.or(m[i,j+3]),"-",format.or(m[i,j+4]),")</center></b></font></td>",sep="");
	                }
	                else #Non-significant OR
	                {
	                    cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[i,j+2])," (",format.or(m[i,j+3]),"-",format.or(m[i,j+4]),")</center></font></td>",sep="");
	                }
	            }
	
			    cat("</tr>");
			    j <- j + 5;
			}
			cat("</table>")
			cat("</td>");
			cat("</tr>");
			i <- i + 1;
		}

        cat('<tr><td colspan=2>');
        cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Test for interaction in the trend: </b>',sep="");
        if (trend < 0.05)
        {
            cat('<font color="#FF0000"><b>',trend,'</b></font>',sep="");
        }
        else
        {
            cat(trend);
        }
        cat('</font></td></tr>');
	    cat("</table>");
	    cat("<p></p>")
    }
}

# Function which prints the interaction table.
cat.interaction.matrix.cont <- function(m, st.name, mode, stradj, var1.name, var2.name, pval=NULL, trend=NULL, n)
{
    if (mode==1) #Corner table
    {
		#For each category of the 2nd interaction variable we have 6 columns (n, me, se, diff, difflo, diffup)
	    numcols <- ncol(m)/6;

	    cat("<table border>");

		if (stradj=="no adjustment")
		{
			cat('<tr bgcolor="#C0C0C0"><td colspan=',(numcols*3)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Cross-classification interaction table (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
		}
		else
		{
			cat('<tr bgcolor="#C0C0C0"><td colspan=',(numcols*3)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Cross-classification interaction table (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
		}

	    cat("<tr>");
	    cat('<td><font size="2"></font></td>');
	    i <- 1;
	    while (i <= numcols)
	    {
	        cat('<td colspan=3><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',colnames(m)[(6*i)-3],'</b></center></font></td>',sep="");
	        i <- i + 1;
	    }
	    cat("</tr>");

	    cat("<tr>");
	    cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>');
	    i <- 1;
	    while (i <= numcols)
	    {
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>n</b></center></font></td>',sep="");
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Response mean (s.e.)</b></center></font></td>',sep="");
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Difference (95% CI)</b></center></font></td>');
	        i <- i + 1;
	    }
	    cat("</tr>");

		j <- 1;
		while (j <= nrow(m))
		{
			cat("<tr>");
			cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',rownames(m)[j],"</b></font></td>",sep=""); #Category name

			i <- 1;
	        while (i <= ncol(m))
	        {
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[j,i],2),"</center></font></td>",sep=""); #n
	            if (m[j,i]==0)
	            {
					cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
	            }
	            else if (m[j,i]==1)
	            {
					cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[j,i+1],2),' (---)</center></font></td>',sep="");
	            }
	            else
	            {
					cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',round(m[j,i+1],2),' (',round(m[j,i+2],2),')',"</center></font></td>",sep="");
	            }

	            if ((j == 1) & (i==1))
	            {
					cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[j,i+3]),"</center></font></td>",sep="");
	            }
	            else
	            {
	                if (m[j,i]==0)
	                {
						cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
	                }
	                else
	                {
						if (m[j,i+4]>0) #Higher value of the response, we print it in red
						{
		 					cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><center><b>',format.or(m[j,i+3]),'<br>(',format.or(m[j,i+4]),' - ',format.or(m[j,i+5]),')',"</b></center></font></td>",sep="");
						}
	                    else if (m[j,i+5]<0) #Lower values of the response, we print in green
	                    {
		 					cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><center><b>',format.or(m[j,i+3]),'<br>(',format.or(m[j,i+4]),' - ',format.or(m[j,i+5]),')',"</b></center></font></td>",sep="");
	                    }
	                    else #No difference
	                    {
		 					cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[j,i+3]),'<br>(',format.or(m[j,i+4]),' - ',format.or(m[j,i+5]),')',"</center></font></td>",sep="");
	                    }
	                }
	            }
	            i <- i + 6;
	        }
	        cat("</tr>");

	        j <- j + 1;
		}
		cat('<tr><td colspan=',(numcols*3)+1,'><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Interaction p-value: </b>',sep="");
        if (pval < 0.05)
        {
            cat('<font color="#FF0000"><b>',pval,'</b></font>',sep="");
        }
        else
        {
            cat(pval);
        }
        cat('</font></td></tr>');
		cat("</table>");
		cat("<p></p>");
    }
    else #Within table
    {
	    numcols <- ncol(m)/6;

	    cat("<table border>");

            if (stradj=="no adjustment")
            {
                cat('<tr bgcolor="#C0C0C0"><td colspan=7><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',var2.name,' within ',var1.name,' (n=',n,', crude analysis)</b></center></font></td></tr>',sep="");
            }
            else
            {
                cat('<tr bgcolor="#C0C0C0"><td colspan=7><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',var2.name,' within ',var1.name,' (n=',n,', adjusted by ',stradj,')</b></center></font></td></tr>',sep="");
            }

	    i <- 1;
	    while (i<=nrow(m))
	    {
	        cat("<tr>");

			cat('<td valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>',rownames(m)[i],"</b></center></font></td>",sep="");
			cat("<td>");
			cat("<table>");
			cat("<tr>");
			cat("<td>   </td>");
            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>n</b></center></font></td>',sep="");
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Response mean (s.e.)</b></center></font></td>',sep="");
	        cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center><b>Difference (95% CI)</b></center></font></td>');
			cat("</tr>");
			j <- 1;
			no.n <- FALSE;
			while (j<=ncol(m))
			{
		    	cat("<tr>");
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>',colnames(m)[j+2],"</b></font></td>",sep=""); #genotype
	            cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',m[i,j],"</center></font></td>",sep=""); #n

				if (j==1)
				{
                	if (m[i,j]==0)
                	{
                		no.n <- TRUE;
                	}
				}

                if (m[i,j]==0)
                {
					no.n <- TRUE;
					cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep=""); #n=0, no mean, no se
                    cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
                }
                else if (m[i,j]==1)
                {
					cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[i,j+1]),' (---)</center></font></td>',sep=""); #n=1, no se
                }
                else
                {
					cat('<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[i,j+1]),' (',format.or(m[i,j+2]),')',"</center></font></td>",sep=""); #Response mean (se)
                }

				if (m[i,j]>0) #Now we print the mean difference and the 95% CI
				{
					if (!no.n)
					{
						if (m[i,j+3]==0)
						{
							cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[i,j+3]),"</center></font></td>",sep="");
						}
						else
						{
							if (m[i,j+4]>0) #dif>0, we print it in red
							{
							    cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b><center>',format.or(m[i,j+3])," (",format.or(m[i,j+4])," - ",format.or(m[i,j+5]),")</center></b></font></td>",sep="");
							}
							else if (m[i,j+5]<0) #dif<0, we print it in green
							{
							    cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#00CC00"><b><center>',format.or(m[i,j+3])," (",format.or(m[i,j+4])," - ",format.or(m[i,j+5]),")</center></b></font></td>",sep="");
							}
							else #Non-significant difference
							{
							    cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>',format.or(m[i,j+3])," (",format.or(m[i,j+4])," - ",format.or(m[i,j+5]),")</center></font></td>",sep="");
							}
						}
					}
					else
					{
                    	cat('<td nowrap><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><center>---</center></font></td>',sep="");
					}
				}
			    cat("</tr>");
			    j <- j + 6;
			}
			cat("</table>")
			cat("</td>");
			cat("</tr>");
			i <- i + 1;
	    }
        cat('<tr><td colspan=2>');
        cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Test for interaction in the trend: </b>',sep="");
        if (trend < 0.05)
        {
            cat('<font color="#FF0000"><b>',trend,'</b></font>',sep="");
        }
        else
        {
            cat(trend);
        }
        cat('</font></td></tr>');

	    cat("</table>");
	    cat("<p></p>")
    }
}

Taula.mean.se <- function(var, dep, subset = !is.na(var))
{
    #  Taula.mean.se(OGG1.7, grup)
    var <- as.factor(var)

    n <- ifelse(is.na(tapply(dep[subset],var[subset],FUN=length)),0,tapply(dep[subset],var[subset],FUN=length));
    me <- ifelse(is.na(tapply(dep[subset],var[subset],FUN=mean)),0,tapply(dep[subset],var[subset],FUN=mean));
    se <- ifelse(is.na(tapply(dep[subset],var[subset],FUN=function(x){sd(x)/sqrt(length(x))})),0,tapply(dep[subset],var[subset],FUN=function(x){sd(x)/sqrt(length(x))}));
    ta <- cbind(n=n,me=me,se=se);
    rownames(ta) <- names(n);
    list(tp = ta);
}

dominant <- function(o)
{
    o[o==levels(o)[3]]<-levels(o)[2]
    levels(o)[2]<-paste(levels(o)[2:3],collapse="-")
    factor(o)
}

recessive <- function(o)
{
    o[o==levels(o)[1]]<-levels(o)[2]
    levels(o)[2]<-paste(levels(o)[1:2],collapse="-")
    factor(o)
}

overdominant <- function(o)
{
    o[o==levels(o)[3]]<-levels(o)[1]
    levels(o)[1]<-paste(levels(o)[c(1,3)],collapse="-")
    factor(o)
}

associacio <- function(var, dep, adj = NULL, cont)
{
    Taula.N.Per <- function(var, dep, subset = !is.na(var))
    {
        #  Taula.N.Per(OGG1.7, grup)
        var <- as.factor(var)
        dep <- as.factor(dep)
        ta <- table(var[subset], dep[subset])
        dimnames(ta) <- list(levels(var), levels(dep))
        per <- matrix(nrow = dim(ta)[1.], ncol = dim(ta)[2.])
        dimnames(per) <- list(levels(var[subset]), c("%", "%"))
        for(i in 1.:dim(ta)[1.]) {
                for(j in 1.:dim(ta)[2.]) {
                        per[i, j] <- cbind(as.matrix(round((ta[i, j] * 100.)/sum(ta[, j]), 2.)))
                }
        }
        tp <- cbind(ta, per)
        tp <- tp[, order(rep(1.:2., 2.))]
		list(tp = tp)
	}

	if (cont==FALSE)
    {
	    # associacio(OGG1.7, grup, edatr + sexe, article=T)
	    var <- as.factor(var)
	    dep <- as.factor(dep)
	
	    #Calculo tres noves variables (dominant, recessiva i overdominant)
	    if (length(levels(var))==3)
		{
	        var.dom <- dominant(var)
	        var.rec <- recessive(var)
	        var.over <- overdominant(var)
	
	        if (is.null(adj))
	        {
	            m.co <- glm(dep~var, family = binomial);
	
	            subset <- 1:length(var)%in%as.numeric(rownames(m.co$model));
	
	            m.b   <-  glm(dep~NULL,            subset = subset, family = binomial)
	            m.dom <-  glm(dep~var.dom,         subset = subset, family = binomial)
	            m.rec <-  glm(dep~var.rec,         subset = subset, family = binomial)
	            m.over <- glm(dep~var.over,        subset = subset, family = binomial)
	            m.ad  <-  glm(dep~as.numeric(var), subset = subset, family = binomial)
	        }
	        else
	        {
	            m.co <- glm(dep~. + var, family = binomial, data=adj);

	            subset <- 1:length(var)%in%as.numeric(rownames(m.co$model));

	            m.b    <- glm(dep~.,                   subset = subset, family = binomial, data=adj)
	            m.dom  <- glm(dep~. + var.dom,         subset = subset, family = binomial, data=adj)
	            m.rec  <- glm(dep~. + var.rec,         subset = subset, family = binomial, data=adj)
	            m.over <- glm(dep~. + var.over,        subset = subset, family = binomial, data=adj)
	            m.ad   <- glm(dep~. + as.numeric(var), subset = subset, family = binomial, data=adj)
	        }
	        # Creo una nova taula ajuntant :
	        # taula de les N's i Percentatges + Or's-PvalAsociacio + Pvalor del test que compara amb el model codominant

	        co  <-  cbind(Taula.N.Per(var, dep, subset)$tp,     intervals.or(m.co, m.b, var)$or.ic,         c(round(AIC(m.co),1), NA, NA), c(round(AIC(m.co, k=log(nrow(m.co$model))),1), NA, NA))
	        dom <-  cbind(Taula.N.Per(var.dom, dep, subset)$tp, intervals.or(m.dom, m.b, var.dom)$or.ic,    c(round(AIC(m.dom),1), NA),    c(round(AIC(m.dom, k=log(nrow(m.dom$model))),1), NA, NA))
	        rec <-  cbind(Taula.N.Per(var.rec, dep, subset)$tp, intervals.or(m.rec, m.b, var.rec)$or.ic,    c(round(AIC(m.rec),1), NA),    c(round(AIC(m.rec, k=log(nrow(m.rec$model))),1), NA, NA))
			over <- cbind(Taula.N.Per(var.over, dep, subset)$tp, intervals.or(m.over, m.b, var.over)$or.ic, c(round(AIC(m.over),1), NA),   c(round(AIC(m.over, k=log(nrow(m.over$model))),1), NA, NA))
	        Ad  <- c(rep(NA, times = 4), intervals.or(m.ad, m.b)$or.ic, round(AIC(m.ad),1),c(round(AIC(m.ad, k=log(nrow(m.ad$model))),1), NA, NA))

	        res <- rbind(co, dom, rec, over, Ad)

	        dimnames(res)[[2]][9] <- "AIC"
	        dimnames(res)[[2]][9] <- "BIC"

			res;
	    }
	    else if (length(levels(var))==2)
	    {
	        if (is.null(adj))
	        {
	            m.co <- glm(dep~var, family = binomial);
	
	            subset <- 1:length(var)%in%as.numeric(rownames(m.co$model));
	
	            m.b   <- glm(dep~NULL,            subset = subset, family = binomial)
	            m.ad  <- glm(dep~as.numeric(var), subset = subset, family = binomial)
	        }
	        else
	        {
	            m.co <- glm(dep~. + var, family = binomial, data=adj);
	
	            subset <- 1:length(var)%in%as.numeric(rownames(m.co$model));
	
	            m.b   <- glm(dep~.,                   subset = subset, family = binomial, data=adj)
	            m.ad  <- glm(dep~. + as.numeric(var), subset = subset, family = binomial, data=adj)
	        }
	        # Creo una nova taula ajuntant :
	        # taula de les N's i Percentatges + Or's-PvalAsociacio + Pvalor del test que compara amb el model codominant
	
	        co  <- cbind(Taula.N.Per(var, dep, subset)$tp,     intervals.or(m.co, m.b, var)$or.ic, c(round(AIC(m.co),1), NA, NA),c(round(AIC(m.co, k=log(nrow(m.co$model))),1), NA, NA))
	        Ad  <- c(rep(NA, times = 4), intervals.or(m.ad, m.b)$or.ic, round(AIC(m.ad),1),c(round(AIC(m.ad, k=log(nrow(m.ad$model))),1), NA, NA))
	
	        res <- rbind(co, Ad)
	
	        dimnames(res)[[2]][9] <- "AIC"
	        dimnames(res)[[2]][10] <- "BIC"	
	        res;
	    }
	}
	else #cont==TRUE (continuous response variable)
	{
	    # associacio(OGG1.7, grup, edatr + sexe, article=T)
	    var <- as.factor(var)
	
	    #Calculo tres noves variables (dominant, recessiva i overdominant)
	    if (length(levels(var))==3)
	    {
	        var.dom <- dominant(var)
	        var.rec <- recessive(var)
	        var.over <- overdominant(var)
	
	        if (is.null(adj))
	        {
	            m.co <- glm(dep~var, family = gaussian);

	            subset <- 1:length(var)%in%as.numeric(rownames(m.co$model));

	            m.b   <-  glm(dep~NULL,            subset = subset, family = gaussian)
	            m.dom <-  glm(dep~var.dom,         subset = subset, family = gaussian)
	            m.rec <-  glm(dep~var.rec,         subset = subset, family = gaussian)
	            m.over <- glm(dep~var.over,        subset = subset, family = gaussian)
	            m.ad  <-  glm(dep~as.numeric(var), subset = subset, family = gaussian)
	        }
	        else
	        {
	            m.co <- glm(dep~. + var, family = gaussian, data=adj);

	            subset <- 1:length(var)%in%as.numeric(rownames(m.co$model));

	            m.b    <- glm(dep~.,                   subset = subset, family = gaussian, data=adj)
	            m.dom  <- glm(dep~. + var.dom,         subset = subset, family = gaussian, data=adj)
	            m.rec  <- glm(dep~. + var.rec,         subset = subset, family = gaussian, data=adj)
	            m.over <- glm(dep~. + var.over,        subset = subset, family = gaussian, data=adj)
	            m.ad   <- glm(dep~. + as.numeric(var), subset = subset, family = gaussian, data=adj)
	        }
	        # Creo una nova taula ajuntant :
	        # taula de les mitjanes i s.e. + difer?ncia mitjanes + PvalAsociacio + AIC

			co  <-  cbind(Taula.mean.se(var, dep, subset)$tp,     intervals.dif(m.co, m.b, var)$m,        aic=c(round(AIC(m.co),1), NA, NA), c(round(AIC(m.co, k=log(nrow(m.co$model))),1), NA, NA))
	        dom <-  cbind(Taula.mean.se(var.dom, dep, subset)$tp, intervals.dif(m.dom, m.b, var.dom)$m,   aic=c(round(AIC(m.dom),1), NA), c(round(AIC(m.dom, k=log(nrow(m.dom$model))),1), NA, NA))
	        rec <-  cbind(Taula.mean.se(var.rec, dep, subset)$tp, intervals.dif(m.rec, m.b, var.rec)$m,   aic=c(round(AIC(m.rec),1), NA), c(round(AIC(m.rec, k=log(nrow(m.rec$model))),1), NA, NA))
	        over <- cbind(Taula.mean.se(var.over, dep, subset)$tp,intervals.dif(m.over, m.b, var.over)$m, aic=c(round(AIC(m.over),1), NA), c(round(AIC(m.over, k=log(nrow(m.over$model))),1), NA, NA))
	        ad  <- c(rep(NA,3), intervals.dif(m.ad, m.b)$m, AIC(m.ad), c(round(AIC(m.ad, k=log(nrow(m.ad$model))),1), NA, NA));

	        res <- rbind(co, dom, rec, over, ad)
	
	        res;
	    }
	    else if (length(levels(var))==2)
	    {
	        if (is.null(adj))
	        {
	            m.co <- glm(dep~var, family = gaussian);
	
	            subset <- 1:length(var)%in%as.numeric(rownames(m.co$model));
	
	            m.b   <- glm(dep~NULL,            subset = subset, family = gaussian)
	            m.ad  <- glm(dep~as.numeric(var), subset = subset, family = gaussian)
	        }
	        else
	        {
	            m.co <- glm(dep~. + var, family = gaussian, data=adj);
	
	            subset <- 1:length(var)%in%as.numeric(rownames(m.co$model));
	
	            m.b   <- glm(dep~.,                   subset = subset, family = gaussian, data=adj)
	            m.ad  <- glm(dep~. + as.numeric(var), subset = subset, family = gaussian, data=adj)
	        }
	        # Creo una nova taula ajuntant :
	        # taula de les N's i Percentatges + Or's-PvalAsociacio + Pvalor del test que compara amb el model codominant

	        co  <- cbind(Taula.mean.se(var, dep, subset)$tp, intervals.dif(m.co, m.b, var)$m, aic=c(AIC(m.co), NA, NA),c(round(AIC(m.co, k=log(nrow(m.co$model))),1), NA, NA))
	        ad  <- c(rep(NA,3), intervals.dif(m.ad, m.b)$m, round(AIC(m.ad),1),NA, c(round(AIC(m.ad, k=log(nrow(m.ad$model))),1), NA, NA))

	        res <- rbind(co, ad)

	        res;
	    }
	}
}

print.index <- function(covdesc,allfreq,genofreq,hweq,snpassoc,ldd,lddp,ldr,ldpval,haplofreq,hapassoc,int,snp.names)
{
    cat('<tr bgcolor="#00BB00">
             <td>
                 <font color="#FFFFFF" size="4" face="Verdana, Arial, Helvetica, sans-serif">
                     <b>Index</b>
                 </font>
             </td>
         </tr>
         <tr>
             <td>
                 <table>');

    if (covdesc==1)
    {
        cat('<tr>
                 <td colspan=2>
                     <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                         <a href="#covdesc"><b>Descriptive statistics</b></a>
                     </font>
                 </td>
             </tr>');
    }

    if (allfreq==1 | genofreq==1 | hweq==1 | snpassoc==1)
    {
        cat('<tr>
                 <td colspan=2>
                     <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                         <a href="#singlesnp"><b>Single-SNP analysis</b></a>
                     </font>
                 </td>
             </tr>');

        i <- 1;
        while (i <= length(snp.names))
        {
            cat('<tr>
                     <td width=10></td>
                     <td>
                         <font size="1" face="Verdana, Arial, Helvetica, sans-serif">
                             <a href="#snp',i,'">',snp.names[i],'</a>
                         </font>
                     </td>
                 </tr>',sep="");
            i <- i + 1;
        }
    }

    if (ldd==1 | lddp==1 | ldr==1 | ldpval==1 | haplofreq==1 | hapassoc==1)
    {
	    cat('<tr>
	             <td colspan=2>
	                 <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
	                     <a href="#multiplesnp"><b>Multiple-SNP analysis</b></a>
	                 </font>
	             </td>
	         </tr>');

	    if (ldd==1 | lddp==1 | ldr==1 | ldpval==1)
	    {
            cat('<tr>
                     <td width=10></td>
                     <td>
                         <font size="1" face="Verdana, Arial, Helvetica, sans-serif">
	                         <a href="#ldanalysis">Linkage disequilibrium analysis</a>
                         </font>
                     </td>
                 </tr>',sep="");
	    }

	    if (haplofreq==1 | hapassoc==1)
	    {
            cat('<tr>
                     <td width=10></td>
                     <td>
                         <font size="1" face="Verdana, Arial, Helvetica, sans-serif">
	                         <a href="#haploanalysis">Haplotype analysis</a>
                         </font>
                     </td>
                 </tr>',sep="");
	    }
    }

    cat('</table></td></tr>');
}

main <- function()
{
    #Global variables coming from snp_analyzer.php (or already found in the workspace):
    #  - discard: vector containing discarded columns
    #  - type: vector containing column types (snp, ccov, qcov, status)
    #  - refcat: vector containing reference category for the snps
    #  - descr.covdesc: perform covariate descriptive? (0/1)
    #  - descr.allfreq: calculate allele frequencies? (0/1)
    #  - descr.genofreq: calculate genotype frequencies? (0/1)
    #  - descr.hweq: calculate HW equilibrium? (0/1)
    #  - descr.snpassoc: calculate association between single SNPs and response
    #  - descr.ldd: calculate LD (D estimator)? (0/1)
    #  - descr.lddp: calculate LD (D' estimator)? (0/1)
    #  - descr.ldr: calculate LD (r estimator)? (0/1)
    #  - descr.ldpval: calculate LD (p-values)? (0/1)
    #  - descr.haplofreq: calculate haplotype frequencies? (0/1)
    #  - assoc: analyze haplotype association with response? (0/1)
    #  - interact: perform interaction analysis? (0/1)
    #  - descr.subpop: should we perform subanalysis for each one of the subpopulations?

	start.time <- Sys.time();
    save.image(file=paste(tmp.files.path,tmp,"/.RData",sep="")); #We save the workspace with all the loaded objects

    #Load the required libraries
    #BE CAREFUL! library genetics must be loaded BEFORE haplo.stats due to a masking problem

    #VM 161212 omit messages
    sink("/dev/null")
    # suppressMessages(library(Hmisc,verbose=FALSE,warn.conflicts=FALSE));
    suppressMessages(library(genetics,verbose=FALSE,warn.conflicts=FALSE));
    suppressMessages(library(haplo.stats,verbose=FALSE,warn.conflicts=FALSE));
    sink()
  #  library("Hmisc");
  #  library("genetics");
  #  library("haplo.stats");
    
    #We open the HTML output file
    sink(paste(docroot,"/",tmp.html.path,tmp,"/snp.html",sep=""));

    cat("<html><head><title>SNPStats: your web tool for SNP analysis.</title></head><body topmargin=0 leftmargin=0>");

    cat('<table width=800 bgcolor="#FFFFB0"><tr><td>');
    
    cat('<tr>
           <td valign="middle" bgcolor="#FF9900" colspan=2>
             <center><font color="#000000" size="5" face="Verdana, Arial, Helvetica, sans-serif">SNPStats results</font></center>
           </td>
         </tr>');

    #We look for the missing status values, and completely delete all the observations from the data matrix.
    aux <- length(m[,(type=="status") & (discard==0)][is.na(m[,(type=="status") & (discard==0)])]);

    status <- m[,(type=="status") & (discard==0)];
    #If status has more than 2 categories, it will be treated as a continuous variable.
    #If not, it will treated as a factor
	if (length(table(status))>2)
    {
		numerical.status <- 1;
		status <- as.numeric(status);
    }
    else
    {
        numerical.status <- 0;
		refcat.status <- paste("refcat",1:(ncol(m)),sep="");
		refcat.status <- refcat.status[(type=="status") & (discard==0)];        
        status <- as.factor(status);
        status <- factor(status,levels=levels(status)[get(refcat.status[1])]); #by now one and only one status variable allowed
    }
    status.name <- colnames(m)[(type=="status") & (discard==0)];

    #We build vectors for the reference category of the SNPs and the covariates.
    #We build a vector for the covariates type
    type.cov <- type[((type=="qcov") | (type=="ccov")) & (discard==0)];

    #We make a separate matrix for the SNPs, and coerce each column to class "genotype".
    m.snp <- m[,(type=="snp") & (discard==0)];
    refcat.snp <- paste("refcat",1:(ncol(m)),sep="");
    refcat.snp <- refcat.snp[(type=="snp") & (discard==0)];
    snp.names <- colnames(m)[(type=="snp") & (discard==0)];
    m.snp <- as.data.frame(m.snp); #Just to overcome the problem of just one snp
    names(m.snp) <- snp.names;
    i <- 1;
    while (i <= ncol(m.snp))
    {
        #We change the variable to a factor and relevel it according to the reference category
        #specified by the user.
        m.snp[,i] <- as.factor(m.snp[,i]);
        m.snp[,i] <- factor(m.snp[,i],levels=levels(m.snp[,i])[get(refcat.snp[i])]);

        i <- i + 1;
    }

    print.index(descr.covdesc,descr.allfreq,descr.genofreq,descr.hweq,descr.snpassoc,descr.ldd,descr.lddp,descr.ldr,descr.ldpval,descr.haplofreq,assoc,interact,snp.names);

    if (aux > 0)
    {
        if (aux==1)
        {
            cat('<tr><td><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>WARNING: ',aux,' observation with missing response value removed from association analyses.</b></font></td></tr>',sep="");
        }
        else
        {
            cat('<tr><td><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>WARNING: ',aux,' observations with missing response value removed from association analyses.</b></font></td></tr>',sep="");
        }
        #m <- m[!is.na(m[,(type=="status") & (discard==0)]),]; #Not needed to remove missing response subjects
        rownames(m) <- 1:(nrow(m));
    }

    #We make a separate matrix for the covariates and coerce it to a data frame,
    #just to overcome the problem of having just one covariate.
    m.cov <- NULL;
    refcat.cov <- paste("refcat",1:(ncol(m)),sep="");
    refcat.cov <- refcat.cov[((type=="qcov") | (type=="ccov")) & (discard==0)];
    exists.cov <- 0;
    if (length(type.cov)>0)
    {
        m.cov <- m[,((type=="qcov") | (type=="ccov")) & (discard==0)];
        exists.cov <- 1;
        m.cov <- as.data.frame(m.cov);
        names(m.cov) <- names(m[((type=="qcov") | (type=="ccov")) & (discard==0)])

        i <- 1;
        while(i <= ncol(m.cov))
        {
            if (type.cov[i]=="ccov")
            {
                m.cov[,i] <- as.factor(m.cov[,i]);
                m.cov[,i] <- factor(m.cov[,i],levels=levels(m.cov[,i])[get(refcat.cov[i])]);
            }
        	i <- i + 1;
		}
    }

    #SNP-response and #Haplotype-response interactions
    if ((interact==1) | (hap.interact==1))
    {
        m.others <- m[,(type=="ccov") | (type=="snp")];
        names(m.others) <- names(m[(type=="ccov") | (type=="snp")])

        refcat.others <- paste("refcat",1:(ncol(m)),sep="");
        refcat.others <- refcat.others[(type=="ccov") | (type=="snp")];

        i <- 1;
        while(i <= ncol(m.others))
        {
			if (interact==1)
			{
	            if (intvar1.name!="allsnps") #Check for interactions between all selected SNPS and one variable
	            {
	                if (names(m.others)[i]==intvar1.name) #Interaction variable 1 can only be a SNP
	                {
	                    intvar1 <- as.factor(m.others[,i]);
	                    intvar1 <- factor(intvar1,levels=levels(intvar1)[get(refcat.others[i])]);
	                    if (intmodel=="dom")
	                    {
	                    	intvar1 <- dominant(intvar1);
	                    }
	                    else if (intmodel=="rec")
	                    {
	                    	intvar1 <- recessive(intvar1);
	                    }
						else if (intmodel=="over")
						{
	                    	intvar1 <- overdominant(intvar1);
						}
	                }
	            }

	            if (names(m.others)[i]==intvar2.name) #Interaction variable 2 can only be a categorical covariate (by now)
	            {
	                intvar2 <- as.factor(m.others[,i]);
	                intvar2 <- factor(intvar2,levels=levels(intvar2)[get(refcat.others[i])]);
	            }
			}

			if (hap.interact==1)
			{
	            if (names(m.others)[i]==hap.intvar.name) #Interaction variable for the haplotypes
	            {
	                hap.intvar <- as.factor(m.others[,i]);
	                hap.intvar <- factor(hap.intvar,levels=levels(hap.intvar)[get(refcat.others[i])]);
	            }
			}
            i <- i + 1;
        }
    }

	#We build variable to select the subjects depending on the part of the analysis we are performing
	keep.status <- !is.na(status); #Missing response values
	keep.haplo <- !apply(is.na(m.snp),1,all); #Missings in all snps->used only for haplotypes
	if (exists.cov)
	{
		keep.cov <- !apply(is.na(m.cov),1,any); #Missings in one or more covariates
	}
	else
	{
		keep.cov <- rep(TRUE, nrow(m)); #If there are no covariates we put all the values to TRUE in order not to filter
	}
	if (interact==1)
	{
		keep.snpint <- !is.na(intvar2); #Missings SNP interaction variable
	}
	if (hap.interact==1)
	{
		keep.haploint <- !is.na(hap.intvar); #Missing haplotype interaction variable
	}

    if (descr.covdesc)
    {
        cat('<tr bgcolor="#00BB00"><td><a name="covdesc"></a><font color="#FFFFFF" size="4" face="Verdana, Arial, Helvetica, sans-serif"><b>Descriptive statistics</b></font></td></tr>');

        cat('<tr><td><font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b>Response variable: </b><font color="#FF0000">',status.name,'</font>',sep="");
        cat('&nbsp<b>Type: </b>',ifelse(numerical.status==0,"categorical", "quantitative"),'</font></td></tr>',sep="");

		cat('<tr><td>');
		print.status.desc(status,status.name,numerical.status);
		cat('<hr></td></tr>');

        if (exists.cov)
        {
            i <- 1;

            while (i <= ncol(m.cov))
            {
                cat('<tr><td><font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b>Covariate: </b><font color="#FF0000">',names(m.cov)[i],'</font>',sep="");
                cat('&nbsp<b>Type: </b>',ifelse(type.cov[i]=="ccov","categorical", "quantitative"),'</font></td></tr>',sep="");

                cat('<tr><td>');
                print.cov.desc(m.cov[,i],type.cov[i],numerical.status,descr.subpop,status,status.name);
                cat('<hr></td></tr>');

                i <- i + 1;
            }
        }
        #else
        #{
        #    cat('<tr><td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000">',sep="");
        #    cat('There are no selected covariates in the dataset');
        #    cat('</font></b></td></tr>');
        #}
    }

    if (descr.allfreq | descr.genofreq | descr.hweq | descr.snpassoc | interact)  #Single-SNP analysis
    {
        cat('<tr bgcolor="#00BB00"><td><a name="singlesnp"></a><font color="#FFFFFF" size="4" face="Verdana, Arial, Helvetica, sans-serif"><b>Single-SNP analysis</b></font></td></tr>');

        #We prepare the interaction analysis if needed
        if (interact==1)
        {
            #First we look if one of the interaction variables is also an adjustment covariate
			#If this is the case we drop it off the covariates matrix.
			m.cov.int <- m.cov;
			if (exists.cov)
			{
			    if (intvar2.name %in% names(m.cov.int))
			    {
			        if (ncol(m.cov.int)==1) #The only covariate is also an interaction variable
			        {
			            m.cov.int <- NULL;
			            stradj <- "no adjustment";
			        }
			        else #There are still some covariates left
			        {
			            names.m.cov.int <- names(m.cov.int)[which(names(m.cov.int)!=intvar2.name)];
			            m.cov.int <- data.frame(m.cov.int[,-which(names(m.cov.int)==intvar2.name)]);
			            names(m.cov.int) <- names.m.cov.int; #We do this just in case ncol(m.cov.int)==1
			            stradj <- paste(names(m.cov.int),collapse="+");
			        }
			    }
			    else
			    {
			        stradj <- paste(names(m.cov.int),collapse="+");
			    }
			}
			else
			{
			    stradj <- "no adjustment";
			}
        }

        i <- 1;
        while (i <= ncol(m.snp))
        {
        	go <- FALSE;
			#Only asking for ONE SNP interaction, we check if it is the proper SNP
    		if (!descr.allfreq & !descr.genofreq & !descr.hweq & !descr.snpassoc)
			{
				if (interact==1)
				{
					if ((intvar1.name=="allsnps") | (intvar1.name==names(m.snp)[i]))
					{
						go <- TRUE;
					}
				}
			}
			else
			{
				go <- TRUE;
			}

			if (go)
			{
	            cat('',sep="");
	            cat('<tr><td><a name="snp',i,'"></a><b><font size="3" face="Verdana, Arial, Helvetica, sans-serif">SNP: </b><font color="#FF0000">',names(m.snp)[i],'</font></font></td></tr>',sep="");
	            cat('<tr><td>');
	            g <- m.snp[,i];
	
				keep.snp <- !is.na(g);
	            #print(g);
	
	            print.snp.summary(g,get(refcat.snp[i]),status,status.name,numerical.status,m.cov,keep.snp,keep.cov,names(m.snp)[i]);
	
	            if ((interact==1) & (length(levels(m.snp[,i]))>1))
	            {
	                #We check if interaction SNP-response needs to be computed
	                if ((intvar1.name=="allsnps") | (intvar1.name==names(m.snp)[i]))
	                {
				        if (intvar1.name=="allsnps")
				        {
				        	intvar1 <- m.snp[,i];

							#We do not take into accout the inheritance model if the snp does not the three categories
							if (length(levels(intvar1))==3)
							{
			                    if (intmodel=="dom")
			                    {
			                    	intvar1 <- dominant(intvar1);
			                    }
			                    else if (intmodel=="rec")
			                    {
			                    	intvar1 <- recessive(intvar1);
			                    }
								else if (intmodel=="over")
								{
			                    	intvar1 <- overdominant(intvar1);
								}
								else if (intmodel=="ad")
								{
									intvar1 <- as.numeric(intvar1);
								}
							}

				        	var1.name <- names(m.snp)[i];
				        }
				        else
				        {
							var1.name <- intvar1.name;
				        }

				        cat('<table><tr><td>');
				        cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF9900">');
				        cat("<b>Interaction analysis with covariate ",intvar2.name,"</b><br>",sep="");
				        cat('</font>');
				        cat('</td></tr></table>');
	
						n <- sum(apply(cbind(keep.status,keep.snp,keep.snpint,keep.cov),1,all));
	
				        int.table1 <- taula.corner(intvar1, status, m.cov.int, intvar2, numerical.status);
	
				        #int.table1 <- taula.corner(intvar1[keep.status & keep.snp & keep.snpint & keep.cov],
				        #						   status[keep.status & keep.snp & keep.snpint & keep.cov],
				        #						   m.cov.int[keep.status & keep.snp & keep.snpint & keep.cov,],
				        #						   intvar2[keep.status & keep.snp & keep.snpint & keep.cov],numerical.status);
	
	                    victor.table1 <- taula.int(intvar1,status,m.cov.int,intvar2,numerical.status);
		                victor.table2 <- taula.int(intvar2,status,m.cov.int,intvar1,numerical.status);
	
				        if (numerical.status==0)
				        {
							cat.interaction.matrix(int.table1,status.name,1,stradj, var1.name, intvar2.name,victor.table1$pval,,n);
						}
						else
						{
				        	cat.interaction.matrix.cont(int.table1,status.name,1,stradj, var1.name, intvar2.name,victor.table1$pval,,n);
						}
	
		                if (numerical.status==0)
		                {
							cat.interaction.matrix(victor.table1$table,status.name,2,stradj, var1.name, intvar2.name,,victor.table1$trend,n);
							cat.interaction.matrix(victor.table2$table,status.name,2,stradj, intvar2.name, var1.name,,victor.table2$trend,n);
						}
						else
						{
							cat.interaction.matrix.cont(victor.table1$table,status.name,2,stradj, var1.name, intvar2.name,,victor.table2$trend,n);
							cat.interaction.matrix.cont(victor.table2$table,status.name,2,stradj, intvar2.name, var1.name,,victor.table1$trend,n);
						}
					}
				}

				cat('<hr></td></tr>');
			}
            i <- i + 1;
        }
    }

    if (descr.ldd | descr.lddp | descr.ldr | descr.ldpval | descr.haplofreq | assoc)  #Multiple-SNP analysis
    {
        cat('<tr bgcolor="#00BB00"><td><a name="multiplesnp"></a><font color="#FFFFFF" size="4" face="Verdana, Arial, Helvetica, sans-serif"><b>Multiple-SNP analysis</b></font></td></tr>');
    }

    if (descr.ldd | descr.lddp | descr.ldr | descr.ldpval)  #Linkage disequilibrium
    {
        cat('<tr><td>');
		cat('<table><tr><td><a name="ldanalysis"></a>');
		cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF9900">');
		cat("<b>Linkage disequilibrium analysis</b><br>");
		cat('</font>');
		cat('</td></tr></table>');

        if (ncol(m.snp)>1)
        {
            ld <- LD(makeGenotypes(m.snp,tol=0)); #tol=0 is to force the conversion of all columns to class genotype
            if (descr.ldd==1)
            {
                cat('<font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b>D statistic</b></font><br>');
                cat.ld.matrix(ld[["D"]]);
            }
            cat("<p></p>");
            if (descr.lddp==1)
            {
                cat('<font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b>D\' statistic</b></font><br>');
                cat.ld.matrix(ld[["D'"]]);
            }
            if (descr.ldr==1)
            {
                cat('<font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b>r statistic</b></font><br>');
                cat.ld.matrix(ld[["r"]]);
            }
            if (descr.ldpval==1)
            {
                cat('<font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b>P-values</b></font><br>');
                cat.ld.matrix(ld[["P-value"]]);
            }
            if (ncol(m.snp)>3)
            {
                ld.graph.filename <- paste(tmp.html.path,tmp,"/ld.png",sep="");

				if (os=="linux")
				{
                	bitmap(paste(docroot,"/",ld.graph.filename,sep=""));
				}
				else
				{
                	png(paste(docroot,"/",ld.graph.filename,sep=""));
				}

                LDtable(ld);
                dev.off();

                cat(paste('<center><img src="',"/",ld.graph.filename,'"/></center>',sep=""));
                cat("<p></p>");
            }
        }
        else
        {
            cat('<tr><td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000">',sep="");
            cat("To perform LD analysis at least two SNPs are required");
            cat('</font></b></td></tr>');
        }
        cat('</td></tr>');
    }

    ok.haplo <- 1;
    if (descr.haplofreq | assoc | hap.interact)
    {
        library(haplo.stats,verbose=FALSE,warn.conflicts=FALSE); #We load the package silently

		cat('<tr><td>');
		cat('<table><tr><td><a name="haploanalysis"></a>');
		cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF9900">');
		cat("<b>Haplotype analysis</b><br>");
		cat('</font>');
		cat('</td></tr></table>');

        if (ncol(m.snp)>1)
        {
            m.snp.sep <- NULL;

            i <- 1;
            while (i <= ncol(m.snp))
            {
                m.snp.sep <- cbind(m.snp.sep,allele(genotype(m.snp[,i])));
                i <- i + 1;
            }
        }
        else
        {
            cat('<tr><td><b><font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000">',sep="");
            cat("To calculate haplotype frequencies, their association with the response or their interaction with a covariate at least two SNPs are required");
            cat('</font></b></td></tr>');
            ok.haplo <- 0;
        }
        cat('</td></tr>');
    }

    if ((descr.haplofreq==1) & (ok.haplo==1))
    {
        if (((descr.subpop==1) & !is.null(status)) & (numerical.status==0))
        {
			#Calculate how many observations will be included in the haplotype frequency analysis
			n <- sum(apply(cbind(keep.status,keep.haplo),1,all));

			group <- status[keep.haplo & keep.status];
			haplofreq <- haplo.group(group,m.snp.sep[keep.haplo & keep.status,],locus.label=names(m.snp));
			res <- haplofreq$group.df;
        }
        else
        {
			#Calculate how many observations will be included in the haplotype frequency analysis
			n <- length(keep.haplo[keep.haplo]);

            haplofreq <- haplo.em(m.snp.sep[keep.haplo,],locus.label=names(m.snp));
            res <- data.frame(haplofreq$haplotype, Total=round(haplofreq$hap.prob,6));
        }
        res <- res[order(res$Total,decreasing=TRUE),];
        res <- data.frame(res,CumFreq=cumsum(res$Total));
        rownames(res) <- 1:(nrow(res));
        cat('<tr><td>');
        cat.haplo.matrix(res,n,haplo.freqmin,ncol(m.snp));
        cat('</td></tr>');
    }

    if ((assoc==1) & (ok.haplo==1))
    {
		geno <- setupGeno(m.snp.sep[keep.status & keep.cov & keep.haplo,]);


        if (exists.cov)
        {
			m.model <- data.frame(geno,m.cov[keep.status & keep.cov & keep.haplo,]);
		}
		else
		{
            m.model <- geno;
        }

		n <- sum(apply(cbind(keep.status,keep.cov,keep.haplo),1,all));
		group <- status[keep.status & keep.cov & keep.haplo];

		if(is.factor(group)) group<-as.numeric(group)-1
#geno <<- geno;
#m.model <<- m.model;
#group <<- group;
#save.image(file=paste(tmp.files.path,tmp,"/.RData",sep="")); #We save the workspace with all the loaded objects

        #First we build the glm formula
        if (numerical.status==0)
        {
            res <- haplo.glm(group~.,
                             family=binomial,
                             na.action="na.geno.keep",
                             allele.lev=attributes(geno)$unique.alleles,
                             control=haplo.glm.control(haplo.freq.min=haplo.freqmin),
                             data=m.model);

#,haplo.effect=hap.int.model afegir aquest tros de codi adalt

			pval.haplo <- p.haplo(res, group, m.cov[keep.haplo & keep.status & keep.cov,], "binomial", haplo.freqmin);

            if (exists.cov)
            {
                stradj <- paste(names(m.cov),collapse="+");
            }
            else
            {
                stradj <- "no adjustment";
            }

            haplo.mat <- haplo.df(res);

	        assoc.matrix <- cbind(haplo.mat,intervals.hap(res)[1:(nrow(haplo.mat)),]);
	        assoc.matrix <- assoc.matrix[order(haplo.mat[,ncol(haplo.mat)],decreasing=TRUE),];
            if (any(assoc.matrix[,1]=="*")) #There are rare haplotypes
            {
                rank.rare <- (1:(nrow(assoc.matrix)))[assoc.matrix[,1]=="*"];
                rare <- assoc.matrix[rank.rare,];
                assoc.matrix <- assoc.matrix[-rank.rare,];
                assoc.matrix <- rbind(assoc.matrix,rare);
                rownames(assoc.matrix) <- c(1:(nrow(assoc.matrix)-1),"rare");
            }
            else
            {
                rownames(assoc.matrix) <- 1:(nrow(assoc.matrix));
            }

            cat('<tr><td>');
            cat.assoc.matrix(assoc.matrix,colnames(m.snp),stradj,n,pval.haplo);
            cat('</td></tr>');
			
		}
		else #numerical.status==1
		{
            res <- haplo.glm(group~.,
                             family=gaussian,
                             na.action="na.geno.keep",
                             allele.lev=attributes(geno)$unique.alleles,
                             control=haplo.glm.control(haplo.freq.min=haplo.freqmin),
                             data=m.model);

#,haplo.effect=hap.int.model

			pval.haplo <- p.haplo(res, group, m.cov[keep.haplo & keep.status & keep.cov,], "gaussian", haplo.freqmin);

            if (exists.cov)
            {
                stradj <- paste(names(m.cov),collapse="+");
            }
            else
            {
                stradj <- "no adjustment";
            }

            haplo.mat <- haplo.df(res);
            haplo.coef <- coefficients(res)[2:(nrow(haplo.mat))];
            haplo.se <- sqrt(diag(res$var.mat))[2:(nrow(haplo.mat))];
            haplo.ci.min <- haplo.coef - (1.96*haplo.se);
            haplo.ci.max <- haplo.coef + (1.96*haplo.se);
            haplo.t <- haplo.coef/haplo.se;
            haplo.pval <- 2 * (1 - pt(abs(haplo.t), res$df.residual))

			#We add NA values for the base haplotype
            haplo.coef <- c(NA,haplo.coef);
            haplo.pval <- c(NA,haplo.pval);
            haplo.ci.min <- c(NA,haplo.ci.min);
            haplo.ci.max <- c(NA,haplo.ci.max);

	        assoc.matrix <- cbind(haplo.mat,haplo.coef,haplo.ci.min,haplo.ci.max,haplo.pval);
	        assoc.matrix <- assoc.matrix[order(haplo.mat[,ncol(haplo.mat)],decreasing=TRUE),];
            if (any(assoc.matrix[,1]=="*")) #There are rare haplotypes
            {
                rank.rare <- (1:(nrow(assoc.matrix)))[assoc.matrix[,1]=="*"];
                rare <- assoc.matrix[rank.rare,];
                assoc.matrix <- assoc.matrix[-rank.rare,];
                assoc.matrix <- rbind(assoc.matrix,rare);
                rownames(assoc.matrix) <- c(1:(nrow(assoc.matrix)-1),"rare");
            }
            else
            {
                rownames(assoc.matrix) <- 1:(nrow(assoc.matrix));
            }

            cat('<tr><td>');
            cat.assoc.matrix.cont(assoc.matrix,colnames(m.snp),stradj,n,pval.haplo);
            cat('</td></tr>');
		}
    }
    

    	if ((hap.interact==1) & (ok.haplo==1))
	{
		#First we look if the interaction variable is also an adjustment covariate
		#If this is the case we drop it off the covariates matrix.
		m.cov.haploint <- m.cov;
		if (exists.cov)
		{
			if (hap.intvar.name %in% names(m.cov.haploint))
			{
				if (ncol(m.cov.haploint)==1) #The only covariate is also an interaction variable
				{
					m.cov.haploint <- NULL;
					stradj <- "no adjustment";
				}
				else #There are still some covariates left
				{
					names.m.cov.haploint <- names(m.cov.haploint)[which(names(m.cov.haploint)!=hap.intvar.name)];
					m.cov.haploint <- data.frame(m.cov.haploint[,-which(names(m.cov.haploint)==hap.intvar.name)]);
					names(m.cov.haploint) <- names.m.cov.haploint; #We do this just in case ncol(names.m.cov.haploint)==1
					stradj <- paste(names(m.cov.haploint),collapse="+");
				}
			}
			else
			{
				stradj <- paste(names(m.cov.haploint),collapse="+");
			}
		}
		else
		{
			m.cov.haploint <- NULL;
		    stradj <- "no adjustment";
		}

		cat('<tr><td>');
        cat('<table><tr><td>');
        cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FF9900">');
        cat("<b>Haplotype interaction analysis with covariate ",hap.intvar.name,"</b><br>",sep="");
        cat('</font>');
        cat('</td></tr></table>');
        cat('</td></tr>');

		geno <- setupGeno(m.snp.sep[keep.haplo & keep.status & keep.haploint & keep.cov,]);

		n <- sum(apply(cbind(keep.haplo, keep.status, keep.haploint, keep.cov),1,all));

		if (numerical.status==0)
		{
		  
		  
			hap.int <- haplo.inter(geno,
	        					   hap.intvar[keep.haplo & keep.status & keep.haploint & keep.cov],
	        					   status[keep.haplo & keep.status & keep.haploint & keep.cov],
	        					   m.cov.haploint[keep.haplo & keep.status & keep.haploint & keep.cov,,drop=FALSE],
	        					   "binomial",haplo.freqmin,numerical.status);

		}
	    else
	    {
			hap.int <- haplo.inter(geno,
	        					   hap.intvar[keep.haplo & keep.status & keep.haploint & keep.cov],
	        					   status[keep.haplo & keep.status & keep.haploint & keep.cov],
	        					   m.cov.haploint[keep.haplo & keep.status & keep.haploint & keep.cov,,drop=FALSE],
	        					   "gaussian",haplo.freqmin,numerical.status);
		}

        cat('<tr><td>');
    	cat.haplo.interaction.matrix(hap.int$mat.fi,status.name,1,stradj, hap.intvar.name,hap.int$pval,n,numerical.status);
        cat('</td></tr>');

        cat('<tr><td>');
    	cat.haplo.interaction.matrix(hap.int$mat.fi.c,status.name,2,stradj, hap.intvar.name,,n,numerical.status);
        cat('</td></tr>');

        cat('<tr><td>');
    	cat.haplo.interaction.matrix(hap.int$mat.fi.r,status.name,3,stradj, hap.intvar.name,,n,numerical.status);
        cat('</td></tr>');
	}

    cat("<tr><td>");
    cat('<form name="frm_results" method="post" action="custom.php" enctype="multipart/form-data">');
    cat('<input type="hidden" name="tmp" value="',tmp,'">',sep="");
    cat('<input type="hidden" name="back" value="1">',sep="");
    cat('<input type="hidden" name="descr_covdesc" value="',descr.covdesc,'">',sep="");
    cat('<input type="hidden" name="descr_allfreq" value="',descr.allfreq,'">',sep="");
    cat('<input type="hidden" name="descr_genofreq" value="',descr.genofreq,'">',sep="");
    cat('<input type="hidden" name="descr_hweq" value="',descr.hweq,'">',sep="");
    cat('<input type="hidden" name="descr_snpassoc" value="',descr.snpassoc,'">',sep="");
    cat('<input type="hidden" name="descr_ldd" value="',descr.ldd,'">',sep="");
    cat('<input type="hidden" name="descr_lddp" value="',descr.lddp,'">',sep="");
    cat('<input type="hidden" name="descr_ldr" value="',descr.ldr,'">',sep="");
    cat('<input type="hidden" name="descr_ldpval" value="',descr.ldpval,'">',sep="");
    cat('<input type="hidden" name="descr_haplofreq" value="',descr.haplofreq,'">',sep="");
    cat('<input type="hidden" name="haplo_freqmin" value="',haplo.freqmin,'">',sep="");
    cat('<input type="hidden" name="assoc" value="',assoc,'">',sep="");
    cat('<input type="hidden" name="descr_subpop" value="',descr.subpop,'">',sep="");
    cat('<input type="hidden" name="interact" value="',interact,'">',sep="");
    cat('<input type="hidden" name="haplointeract" value="',hap.interact,'">',sep="");
    if (interact==1)
    {
        cat('<input type="hidden" name="intvar1" value="',intvar1.name,'">',sep="");
        cat('<input type="hidden" name="intvar2" value="',intvar2.name,'">',sep="");
    }
    if (hap.interact==1)
    {
        cat('<input type="hidden" name="hapintvarname" value="',hap.intvar.name,'">',sep="");
    }

    cat('<input type="submit" value="<<< Step 3: Customize analysis">');
    cat('</form>');
    cat("</td></tr>");
    cat('</td></tr></table>');
    cat("</body>");
    cat("</html>");
    sink();
    end.time <- Sys.time();
    cat.log(difftime(end.time,start.time,units="min"),nrow(m.snp),ncol(m.snp),numerical.status);
}

#Execution of the "main" function. We use a try to catch the error

err <- try(main());

if (class(err)=="try-error")
{
	cat.log.err(err);
	cat.error.msg();

	i <- 1;
	stop.loop <- FALSE;
	while (!stop.loop)
	{
		#We can keep several error workspaces
		if (!file.exists(paste(tmp.files.path,tmp,"/err",i,".RData",sep="")))
		{
    		save.image(file=paste(tmp.files.path,tmp,"/err.RData",sep="")); #We save the workspace which has generated the error
    		stop.loop <- TRUE;
    	}
    	else
    	{
    		i <- i + 1;
    	}
	}
}


