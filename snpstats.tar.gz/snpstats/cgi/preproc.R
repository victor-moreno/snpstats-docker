count.var <- 0;

get.ordered.categories <- function(snp)
{
    t <- table(snp);
    hmz <- NULL;
    maxvec <- NULL;
    maxval <- 0;
    i <- 1;
    while (i <= length(t))
    {
        if (length(unique(unlist(strsplit(names(t)[i],"/"))))==1)
        {
            hmz <- c(hmz,1);
            if (t[i]>maxval)
            {
                if (!is.null(maxvec))
                {
                    maxvec[maxvec!=0] <- 0;
                }
                maxvec <- c(maxvec,1);
                maxval <- t[i];
            }
            else
            {
                maxvec <- c(maxvec,0);
            }
        }
        else
        {
            hmz <- c(hmz,0);
            maxvec <- c(maxvec,0);
        }

        i <- i + 1;
    }
    
    res <- t[(hmz==1) & (maxvec==1)];
    res <- c(res,t[(hmz==0)]);
    res <- c(res,t[(hmz==1) & (maxvec==0)]);
    
    res;
}

print.col.report <- function(column,colname,colnumber)
{
    #We change the color of the odd rows
    
    if (exists("type"))
    {
        if (type[colnumber]=="snp") #Blue for SNP'a
        {
            cat('<tr id="r',colnumber,'" bgcolor="#7EE3EE">',sep="");
        }
        else if (type[colnumber]=="ccov") #Green for categorical covariates
        {
            cat('<tr id="r',colnumber,'" bgcolor="#00CCAA">',sep="");
        }
        else if (type[colnumber]=="qcov") #Yellow for quantitative covariates
        {
            cat('<tr id="r',colnumber,'" bgcolor="#EEEE33">',sep="");
        }
        else #Orange for status
        {
            cat('<tr id="r',colnumber,'" bgcolor="#DD5533">',sep="");
        }
    }
    else
    {
        if (class(column)=="factor") #Column may be a SNP, a covariate or status
        {
            if ((sort(unique(regexpr("[[:print:]]+/[[:print:]]+",as.character(column))))[1]==1) & length(levels(column))<=3) #Column is SNP
            {
                cat('<tr id="r',colnumber,'" bgcolor="#7EE3EE">',sep="");
            }
            else
            {
                cat('<tr id="r',colnumber,'" bgcolor="#00CCAA">',sep="");
            }
        }
        else
        {
            if ((class(column)=="integer") || (class(column)=="numeric"))
            {
                if (length(table(column))>5) #Assume quantitative
                {
                    cat('<tr id="r',colnumber,'" bgcolor="#EEEE33">',sep="");
                }
                else
                {
                    cat('<tr id="r',colnumber,'" bgcolor="#00CCAA">',sep="");
                }
            }
        }
    }

    #We write the column number and the column name
    cat('<td>',colnumber,'</td><td>',colname,'</td>',sep="");

    #To write the "type" column, we check if we already have a "type"
    #object in our workspace, which will only happen if we come from
    #the step forward
    if (exists("type"))
    {
        cat(paste('<td><select name="s',colnumber,'" onChange="JavaScript:ctrlDisplay(',"'",colnumber,"'",',this.value);">',sep=""));
        if (type[colnumber]=="snp")
        {
            count.var <<- count.var + 1;
            cat('<option value="snp" selected>SNP');
            coltype <- "snp";
        }
        else
        {
            if (sort(unique(regexpr("[[:print:]]+/[[:print:]]+",as.character(column))))[1]==1) #Column seems to be a SNP, but it isn't characterized as a SNP
            {
                cat('<option value="snp">SNP');
            }
        }

        if (type[colnumber]=="ccov")
        {
            cat('<option value="ccov" selected>Categorical covariate');
            coltype <- "ccov";
            count.var <<- count.var + 1;
        }
        else
        {
            cat('<option value="ccov">Categorical covariate');
        }

        if (type[colnumber]=="qcov")
        {
            cat('<option value="qcov" selected>Quantitative covariate');
            coltype <- "qcov";
            count.var <<- count.var + 1;
        }
        else
        {
            cat('<option value="qcov">Quantitative covariate');
        }

        if (type[colnumber]=="status")
        {
            cat('<option value="status" selected>Response');
            coltype <- "status";
            count.var <<- count.var + 1;     
        }
        else
        {
            cat('<option value="status">Response');
        }
        cat('</select></td>');
    }
    else
    {
        cat(paste('<td><select name="s',colnumber,'" onChange="JavaScript:ctrlDisplay(',"'",colnumber,"'",',this.value);">',sep=""));
        if (class(column)=="factor") #Column may be a SNP, a covariate or status
        {
            if ((sort(unique(regexpr("[[:print:]]+/[[:print:]]+",as.character(column))))[1]==1) & length(levels(column))<=3) #Column is SNP
            {
                coltype <- "snp";
                count.var <<- count.var + 1;
                cat('<option value="snp" selected>SNP');
                cat('<option value="ccov">Categorical covariate');
                cat('<option value="qcov">Quantitative covariate');
            }
            else
            {
                cat('<option value="ccov" selected>Categorical covariate');
                cat('<option value="qcov">Quantitative covariate');
                coltype <- "ccov";                
                count.var <<- count.var + 1;
            }

            cat('<option value="status">Response');
            cat('</select></td>');
        }

        #Quantitative or categorical, depending on the number of categories
        if ((class(column)=="integer") || (class(column)=="numeric"))
        {
            if (length(table(column))>5) #Assume quantitative
            {
                cat('<option value="ccov">Categorical covariate');
                cat('<option value="qcov" selected>Quantitative covariate');
                coltype <- "qcov";
            }
            else
            {
                cat('<option value="ccov" selected>Categorical covariate');
                cat('<option value="qcov">Quantitative covariate');
                coltype <- "ccov";
                count.var <<- count.var + 1;
            }
            cat('<option value="status">Response');
            cat('</select></td>');
        }
    }

    cat('<td><center>',length(table(column)),'</center></td>',sep="");
    cat('<input type="hidden" name="numcat',colnumber,'" value=',length(table(column)),' />',sep="");
    if (is.numeric(column))
    {
        cat('<input type="hidden" name="isnum',colnumber,'" value="1" />',sep="");
    }
    else
    {
        cat('<input type="hidden" name="isnum',colnumber,'" value="0" />',sep="");
    }
    cat('<td><center>',length(column[is.na(column)]),'</center></td>',sep="");

    if (!exists("refcat1"))
    {
        if (coltype == "snp")
        {
            aux <- get.ordered.categories(column);
            unordered.aux <- table(column);
            unordered.aux <- cbind(rank=1:(length(aux)),num=unordered.aux);

            cat('<td nowrap><table><tr><td><select multiple size="2" id="c',colnumber,'" name="c',colnumber,'[]">',sep="");
            i <- 1;
            while (i<=length(aux))
            {
                cat('<option value="',unordered.aux[,"rank"][rownames(unordered.aux)==names(aux)[i]],'">',names(aux)[i],' (', aux[i],')',sep="");
                i <- i + 1;
            }

            cat('</select></td>');
            cat('<td><table><tr><td>');
            cat('<img src="images/arrow_up.gif" title="Move category up" id="iu',colnumber,'" height="10" onClick="Javascript:reorder(\'up\',',colnumber,');">',sep="");
            cat('<tr><td><img src="images/arrow_down.gif" title="Move category down" id="id',colnumber,'" height="10" onClick="Javascript:reorder(\'down\',',colnumber,');">',sep="");
            cat('</td></tr></table></td></tr></table>');
            cat('</td>');
        }
        else
        {
            #We get the rank of the category with max number of repetitions. If there are two
            #or more categories with the same number of repetitions we will choose the first in
            #alphabetical order

            aux <- table(column);

            cat('<td nowrap><table><tr><td><select multiple size="2" id="c',colnumber,'" name="c',colnumber,'[]">',sep="");
            i <- 1;
            while (i<=length(aux))
            {
                cat('<option value="',i,'">',names(aux)[i],' (', aux[i],')',sep="");
                i <- i + 1;
            }
            cat('</select></td>');
            cat('<td><table><tr><td>');
            cat('<img src="images/arrow_up.gif" title="Move category up" id="iu',colnumber,'" height="10" onClick="Javascript:reorder(\'up\',',colnumber,');">',sep="");
            cat('<tr><td><img src="images/arrow_down.gif" title="Move category down" id="id',colnumber,'" height="10" onClick="Javascript:reorder(\'down\',',colnumber,');">',sep="");
            cat('</td></tr></table></td></tr></table>');
            cat('</td>');
        }
    }
    else
    {
        #categories contains the variable categories in the order specified by the user
        categories <- get(paste("refcat",colnumber,sep=""));
        aux <- table(column);

        cat('<td nowrap><table><tr><td><select multiple size="2" id="c',colnumber,'" name="c',colnumber,'[]">',sep="");
        i <- 1;
        while (i<=length(categories))
        {
            cat('<option value="',categories[i],'">',names(aux)[categories[i]],' (', aux[categories[i]],')',sep="");
            i <- i + 1;
        }

        cat('</select></td>');
        cat('<td><table><tr><td>');
        cat('<img src="images/arrow_up.gif" title="Move category up" id="iu',colnumber,'" height="10" onClick="Javascript:reorder(\'up\',',colnumber,');">',sep="");
        cat('<tr><td><img src="images/arrow_down.gif" title="Move category down" id="id',colnumber,'" height="10" onClick="Javascript:reorder(\'down\',',colnumber,');">',sep="");
        cat('</td></tr></table></td></tr></table>');
        cat('</td>');
    }

    if (exists("discard"))
    {
        if (discard[colnumber]==1)
        {
            cat(paste('<td><center><input type="checkbox" name="discard[]" id="ch',colnumber,'" value="',colnumber,'"/></center></td></tr>',sep=""));
        }
        else
        {
            cat(paste('<td><center><input type="checkbox" name="discard[]" id="ch',colnumber,'" value="',colnumber,'" checked/></center></td></tr>',sep=""));
        }
    }
    else
    {
        cat(paste('<td><center><input type="checkbox" name="discard[]" id="ch',colnumber,'" value="',colnumber,'"/></center></td></tr>',sep=""));
    }
}

generate.preproc.page <- function()
{
    #Global variables written by the PHP script (preproc.php)
    #header: does first line of data file contain column names?
    #delim: column-delimiter character (tab, whitespace, semi-colon)
    #na.string: missing indicator
    #file.name: original file name
    #docroot: document root path in the server
    #tmp: tmp string for current execution. Used to build temp paths
    #read.data (boolean): do we need to read data matrix from a text file?

    #Load the required libraries
    
    #VM 161212 supress messages
    # sink("/dev/null")
    # suppressMessages(library(genetics, warn.conflicts=FALSE));
    # sink()
    
    if (read.data)
    {
        #Read the data table
        if (delim=="tab")
        {
            m <- read.table(paste(tmp.files.path,tmp,"/orig_data.txt",sep=""),header=header,sep="\t",na.strings=c(na.string,""),dec=dec,fill=TRUE,strip.white=TRUE,comment.char="");
        }

        if (delim=="sp")
        {
            m <- read.table(paste(tmp.files.path,tmp,"/orig_data.txt",sep=""),header=header,sep="",na.strings=c(na.string,""),dec=dec,fill=TRUE,strip.white=TRUE,comment.char="");
        }

        if (delim=="semicol")
        {
            m <- read.table(paste(tmp.files.path,tmp,"/orig_data.txt",sep=""),header=header,sep=";",na.strings=c(na.string,""),dec=dec,fill=TRUE,strip.white=TRUE,comment.char="");
        }

        m <<- m; #We write the matrix in the workspace for further usage
    }

    sink(paste(docroot,"/",tmp.html.path,tmp,"/preproc.html",sep=""));

    cat("<html><head><title>SNPStats: your web tool for SNP analysis</title></head>");

    cat('

    <script LANGUAGE="Javascript">
    <!-- Begin
    var checkflag = "false";

    function changecov()
    {
        if (checkflag == "false")
        {
            for (var f=0; f < document.forms.length; f++)
            {
                for (var i=0;i < document.forms[f].elements.length;i++)
                {
                    var elemento = document.forms[f].elements[i];
                    if (elemento.type == "checkbox")
                    {
                        var seltxt = "document.forms[f].s" + elemento.value;

                        var selobj = eval(seltxt);
                        var ind = selobj.selectedIndex;
                        if ((selobj.options[ind].value == "qcov") | (selobj.options[ind].value == "ccov"))
                        {
                            elemento.checked = true
                        }
                    }
                }
            }
            checkflag = "true";
            return "Exclude all covariates";
        }
	else
	{
            for (var f=0; f < document.forms.length; f++)
            {
                for (var i=0;i < document.forms[f].elements.length;i++)
                {
                    var elemento = document.forms[f].elements[i];
                    if (elemento.type == "checkbox")
                    {
                        var seltxt = "document.forms[f].s" + elemento.value;

                        var selobj = eval(seltxt);
                        var ind = selobj.selectedIndex;
                        if ((selobj.options[ind].value == "qcov") | (selobj.options[ind].value == "ccov"))
                        {
                            elemento.checked = false
                        }
                    }
                }
            }
            checkflag = "false";
            return "Include all covariates";
        }
    }

    function changesnp()
    {
        if (checkflag == "false")
        {
            for (var f=0; f < document.forms.length; f++)
            {
                for (var i=0;i < document.forms[f].elements.length;i++)
                {
                    var elemento = document.forms[f].elements[i];
                    if (elemento.type == "checkbox")
                    {
                        var seltxt = "document.forms[f].s" + elemento.value;

                        var selobj = eval(seltxt);
                        var ind = selobj.selectedIndex;
                        if (selobj.options[ind].value == "snp")
                        {
                            elemento.checked = true
                        }
                    }
                }
            }
            checkflag = "true";
            return "Exclude all SNPs";
        }
		else
		{
            for (var f=0; f < document.forms.length; f++)
            {
                for (var i=0;i < document.forms[f].elements.length;i++)
                {
                    var elemento = document.forms[f].elements[i];
                    if (elemento.type == "checkbox")
                    {
                        var seltxt = "document.forms[f].s" + elemento.value;

                        var selobj = eval(seltxt);
                        var ind = selobj.selectedIndex;
                        if (selobj.options[ind].value == "snp")
                        {
                            elemento.checked = false
                        }
                    }
                }
            }
            checkflag = "false";
            return "Include all SNPs";
        }
    }

    function ErrControl()
    {
        var numstatus = 0;
        var numcatstatus = 0;
        var numsnp = 0;
        var contnotnum = 0;

        for (var i=1;i <= document.frm_prepro.numcols.value;i++)
        {
            var elem = eval("document.frm_prepro.s" + i);
            var ind = elem.selectedIndex;
            if (elem.options[ind].value == "status")
            {
                var elemdis = eval("document.frm_prepro.ch" + i);
                if (elemdis.checked == true)
                {
                    numstatus++;
                    aux = eval("document.frm_prepro.numcat" + i);
                    aux2 = eval("document.frm_prepro.isnum" + i);

                    numcatstatus = aux.value;
                    if (numcatstatus>2) //More than 2 categories: continuous status variable?
                    {
                        if (aux2.value==0) //Error: variable status not numerical
                        {
                            contnotnum = 1;
                        }
                    }
                }
            }
            else
            {
                if (elem.options[ind].value == "snp")
                {
                    var elemdis = eval("document.frm_prepro.ch" + i);
                    if (elemdis.checked == true)
                    {
                        numsnp++;
                    }
                }
            }
        }

        if (numsnp > 0)
        {
            if (numstatus == 1)
            {
                if (numcatstatus==2)
                {
                    chkall();
                    document.frm_prepro.submit();
                }
                else
                {
                    if (contnotnum==1)
                    {
                        alert("Response variable with more than two categories must be numerical");
                    }
                    else
                    {
                        chkall();
                        document.frm_prepro.submit();
                    }
                }
            }
            else
            {
                if (numstatus==0)
                {
                    alert("There must be one response variable.");
                }
                else
                {
                    if (numstatus > 0)
                    {
                        alert("There must be only one response variable.");
                    }
                }
            }
        }
        else
        {
            alert("There must be at least one snp.");
        }
    }

    function hide(e)
    {
        elem = eval("document.frm_prepro.c" + e);
        elem.style.display = "none";
        elem = eval("document.frm_prepro.iu" + e);
        elem.style.display = "none";
        elem = eval("document.frm_prepro.id" + e);
        elem.style.display = "none";
    } 

    function show(e)
    {
        elem = eval("document.frm_prepro.c" + e);
        elem.style.display = "";
        elem = eval("document.frm_prepro.iu" + e);
        elem.style.display = "";
        elem = eval("document.frm_prepro.id" + e);
        elem.style.display = "";

    }');

    cat('
    function ctrlDisplay(elemname,val)
    {
		//We first show or hide the reference category combo
        if (val=="qcov")
        {
            hide(elemname);
        }
        else
        {
            show(elemname);
        }

		//Now we deal with the colour of the row
        if (val=="snp")
        {
            eval("document.all[\\"r\\"+elemname].style.background=\'#7EE3EE\'");
        }
        else
        {
            if (val=="qcov")
            {
                eval("document.all[\\"r\\"+elemname].style.background=\'#EEEE33\'");
            }
            else
            {
                if (val=="ccov")
                {
                    eval("document.all[\\"r\\"+elemname].style.background=\'#00CCAA\'");
                }
                else
                {
					eval("document.all[\\"r\\"+elemname].style.background=\'#DD5533\'");
                    eval("document.frm_prepro.ch" + elemname + ".checked=true");

					for (var i=1;i <= document.frm_prepro.numcols.value;i++)
					{
						if (i!=elemname)
						{
							var seltxt = "document.frm_prepro.s" + i;
	
	                        var selobj = eval(seltxt);
	                        var ind = selobj.selectedIndex;
	                        if (selobj.options[ind].value == "status")
	                        {
								var aux = eval("document.frm_prepro.ch" + i);
	                        	if (aux.checked == true)
	                        	{
									aux.checked = false;
								}		
	                        }
	                    }
		            }
                }
            }
		}
    }

    function hideQuantitative()
    {
        for (var i=1;i <= document.frm_prepro.numcols.value;i++)
        {
            var elem = eval("document.frm_prepro.s" + i);
            var ind = elem.selectedIndex;
            if (elem.options[ind].value == "qcov")
            {
                hide(i);
            }
        }
    }');
    
    cat('
    function chkall()
    {
        i = 1;
        while (i <= document.frm_prepro.numcols.value)
        {
            obj = eval("document.frm_prepro.c" + i);

            j = 0;
            while (j<obj.length)
            {
                obj.options[ j ].selected=true;
                j = j + 1;
            }
            i = i + 1;
        }
        document.frm_prepro.submit();
    }');

    cat('
    function reorder(move,colnum)
    {
        obj = eval("document.frm_prepro.c" + colnum);
        
        if (obj.selectedIndex != -1)
        {
            if (move=="up")
            {
                if (obj.selectedIndex>0)
                {
                    aux_value = obj.options[obj.selectedIndex].value;
                    aux_text = obj.options[obj.selectedIndex].text;

                    obj.options[obj.selectedIndex].value = obj.options[obj.selectedIndex-1].value;
                    obj.options[obj.selectedIndex].text = obj.options[obj.selectedIndex-1].text;

                    obj.options[obj.selectedIndex-1].value = aux_value;
                    obj.options[obj.selectedIndex-1].text = aux_text;
                    obj.selectedIndex = obj.selectedIndex - 1;
                }
            }
            else
            {
                if (obj.selectedIndex<(obj.length-1))
                {
                    aux_value = obj.options[obj.selectedIndex].value;
                    aux_text = obj.options[obj.selectedIndex].text;

                    obj.options[obj.selectedIndex].value = obj.options[obj.selectedIndex+1].value;
                    obj.options[obj.selectedIndex].text = obj.options[obj.selectedIndex+1].text;

                    obj.options[obj.selectedIndex+1].value = aux_value;
                    obj.options[obj.selectedIndex+1].text = aux_text;
                    obj.selectedIndex = obj.selectedIndex + 1;
                }
            }
        }
        else
        {
            alert("There is no selected category");
        }
    }
    // End -->
    </script>');

    cat('<body bgcolor="#F5F5FF" topmargin=0 leftmargin=0 onLoad="JavaScript:hideQuantitative();">');

    cat('<table width=800 bgcolor="#F5F5FF"><tr><td colspan=7>');

    cat('<tr>
           <td valign="middle" bgcolor="#FF9900" colspan=7>
             <center>
               <font color="#000000" size="5" face="Verdana, Arial, Helvetica, sans-serif">Step 2: Data preprocessing</font>
             </center>
           </td>
         </tr>');

    cat('<tr><td colspan=7><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
        In this step you can see some information obtained for each one of the
        columns of your data matrix. Please check that the type we assume for every
        one of them is correct. If there is a SNP column which is considered by the
        a software as a covariate please check your data, as there may be a mistake
        in your data file. The default reference category for each SNPs is the most
        frequent homozygote, and for the covariates the first in alphabetical order.
        All SNPs and covariates not explicitly discarded will be included in the
        analysis. Only one variable of type "response" is allowed.<p></p></font></td></tr>');

    cat('<tr><td colspan=7><font size="2" face="Verdana, Arial, Helvetica, sans-serif">');

    cat(paste("<b>File name:</b>",file.name,"<br>"));
    cat(paste("<b>Number of processed rows:</b>",nrow(m),"<br>"));
    cat(paste("<b>Number of processed columns:</b>",ncol(m),"<br>"));
    cat(paste("<b>Column headers:</b>",ifelse(header,"Yes","No"),"<br>"));

    cat("<p></p>");

    cat("</font></td></tr>");

    cat('<form name="frm_prepro" method="post" action="custom.php" enctype="multipart/form-data">');

    cat('<tr>
             <td>
               <center><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Column</b></font></center>
             </td>
             <td>
               <center><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Name</b></font></center>
             </td>
             <td>
               <center><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Type</b></font></center>
             </td>
             <td>
               <center><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Number of different values</b></font></center>
             </td>
             <td>
               <center><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Number of<br>missings</b></font></center>
             </td>
             <td>
               <center><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Category<br>order</b></font></center>
             </td>
             <td>
               <center><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b>Include SNP/covariate</b></font></center>
             </td>
         </tr>');

    i <- 1;
    while (i <= ncol(m))
    {
        print.col.report(m[,i],colnames(m)[i],i);
        i <- i + 1;
    }

    cat('<tr><td colspan=7>');
    cat('<input type="button" onClick="JavaScript:this.value=changesnp();" value="Include all SNPs" />');
    cat('<input type="button" onClick="JavaScript:this.value=changecov();" value="Include all covariates" /><p></p>');
    cat('</td></tr>');

    cat('<tr><td colspan=7>');
    cat('<input type="button" onClick="JavaScript:document.frm_prepro_bck.submit();" value="<<< Step 1: Data uploading">');
    cat('<input type="button" onClick="JavaScript:ErrControl();" value="Step 3: Analysis customization >>>">');
    cat('</td></tr>');

    cat("</table>");

    cat(paste('<input type="hidden" name="numcols" value="',ncol(m),'">',sep=""));
    cat(paste('<input type="hidden" name="tmp" value="',tmp,'">',sep=""));

    cat('<p></p>');

    cat('<input type="hidden" name="direction" value="fwd">');
    cat("</form>");

    cat('<form name="frm_prepro_bck" action="start.htm" enctype="multipart/form-data">');
    cat("</form>");

    cat("</body></html>");

    sink();
}

#Execution of the "main" function.
generate.preproc.page();
save.image(paste(tmp.files.path,tmp,"/.RData",sep=""));
