#Function which generates the page of the analysis customization
generate.custom.page <- function()
{
    sink(paste(docroot,"/",tmp.html.path,tmp,"/custom.html",sep=""));

    #We write the HTML
    cat('
        <html>
            <head>
                <title>SNPStats: your web tool for SNP analysis</title>
            </head>
            <script LANGUAGE="Javascript">
            <!-- Begin
                function changeLD()
                {
                    if (document.frm_custom.chkLD.checked)
                    {
                        document.frm_custom.chk_descr_ldd.checked = true
                        document.frm_custom.chk_descr_lddp.checked = true
                        document.frm_custom.chk_descr_ldr.checked = true
                        document.frm_custom.chk_descr_ldpval.checked = true
                    }
                    else
                    {
                        document.frm_custom.chk_descr_ldd.checked = false
                        document.frm_custom.chk_descr_lddp.checked = false
                        document.frm_custom.chk_descr_ldr.checked = false
                        document.frm_custom.chk_descr_ldpval.checked = false
                    }
                }

                function changemultiple()
                {
                    if (document.frm_custom.chkmultiple.checked)
                    {
                        document.frm_custom.chkLD.checked = true
                        document.frm_custom.chk_descr_ldd.checked = true
                        document.frm_custom.chk_descr_lddp.checked = true
                        document.frm_custom.chk_descr_ldr.checked = true
                        document.frm_custom.chk_descr_ldpval.checked = true
                        document.frm_custom.chk_descr_haplofreq.checked = true
                        document.frm_custom.hapassoc.checked = true
                        if (document.frm_custom.chk_hapinteract.type=="checkbox")
                        {
							document.frm_custom.chk_hapinteract.checked = true
						}
                        ctrlHaploInteractionVar(true)
                    }
                    else
                    {
                        document.frm_custom.chkLD.checked = false
                        document.frm_custom.chk_descr_ldd.checked = false
                        document.frm_custom.chk_descr_lddp.checked = false
                        document.frm_custom.chk_descr_ldr.checked = false
                        document.frm_custom.chk_descr_ldpval.checked = false
                        document.frm_custom.chk_descr_haplofreq.checked = false
                        document.frm_custom.hapassoc.checked = false
                        if (document.frm_custom.chk_hapinteract.type=="checkbox")
                        {
                        	document.frm_custom.chk_hapinteract.checked = false
						}
                        ctrlHaploInteractionVar(false)
                    }
                }

                function changeSNP()
                {
                    if (document.frm_custom.chkSNP.checked)
                    {
                        document.frm_custom.chk_descr_allfreq.checked = true
                        document.frm_custom.chk_descr_genofreq.checked = true
                        document.frm_custom.chk_descr_hweq.checked = true
                        document.frm_custom.chk_snpassoc.checked = true
                        if (document.frm_custom.interact.type=="checkbox")
                        {
                        	document.frm_custom.interact.checked = true
                        }
                        ctrlInteractionVars(true)
                    }
                    else
                    {
                        document.frm_custom.chk_descr_allfreq.checked = false
                        document.frm_custom.chk_descr_genofreq.checked = false
                        document.frm_custom.chk_descr_hweq.checked = false
                        document.frm_custom.chk_snpassoc.checked = false
                        if (document.frm_custom.interact.type=="checkbox")
                        {
	                        document.frm_custom.interact.checked = false
	                    }
                        ctrlInteractionVars(false)
                    }
                }');

	cat('
                function ErrControl()
                {
                    var cont=0;
                    
                    if (document.frm_custom.chk_descr_covdesc.checked == false &
                        document.frm_custom.chk_descr_allfreq.checked == false &
                        document.frm_custom.chk_descr_genofreq.checked == false &
                        document.frm_custom.chk_descr_hweq.checked == false &
                        document.frm_custom.chk_snpassoc.checked == false &
                        document.frm_custom.chk_descr_ldd.checked == false &
                        document.frm_custom.chk_descr_lddp.checked == false &
                        document.frm_custom.chk_descr_ldr.checked == false &
                        document.frm_custom.chk_descr_ldpval.checked == false &
                        document.frm_custom.chk_descr_haplofreq.checked == false &
                        document.frm_custom.hapassoc.checked == false)
                    {
                        if (document.frm_custom.interact.type == "checkbox")
                        {
                        	if (document.frm_custom.interact.checked == true)
                        	{
                        		cont=1;
                        	}
                        }
						if (document.frm_custom.chk_hapinteract.type == "checkbox")
						{
							if (document.frm_custom.chk_hapinteract.checked == true)
							{
								cont=1;
							}
						}
                    }
                    else
                    {
                    	cont=1;
                    }

                    if (cont==1)
                    {
						document.frm_custom.submit();
                    }
                    else
                    {
						alert("Please choose at least one option");
                    }
                }

                function ctrlInteractionVars(checked)
                {
					if (document.frm_custom.interact.type == "checkbox")
					{
	                    if (checked==false)
	                    {
	                        hide("document.frm_custom.intvar1");
	                        hide("document.frm_custom.intvar2");
    	                	hide("document.frm_custom.intmodel");
	                    }
	                    else
	                    {
	                        show("document.frm_custom.intvar1");
	                        show("document.frm_custom.intvar2");
    	                	show("document.frm_custom.intmodel");
	                    }
	                }
                }');

	cat('
                function ctrlHaploInteractionVar(checked)
                {
					if (document.frm_custom.chk_hapinteract.type == "checkbox")
					{
	                    if (checked==false)
	                    {
	                        hide("document.frm_custom.haplointvar");
	                        hide("document.frm_custom.haplointmodel");
	                    }
	                    else
	                    {
	                        show("document.frm_custom.haplointvar");
	                        show("document.frm_custom.haplointmodel");
						}
					}
                }

                function hide(e)
                {
                    elem = eval(e);
                    elem.style.display = "none";
                }

                function show(e)
                {
                    elem = eval(e);
                    elem.style.display = "";
                }

                function hideInteractionVars()
                {
					if (document.frm_custom.interact.type == "checkbox")
					{
						if (document.frm_custom.interact.checked == false)
						{
		                    hide("document.frm_custom.intvar1");
	    	                hide("document.frm_custom.intvar2");
	    	                hide("document.frm_custom.intmodel");
						}
    	            }
					if (document.frm_custom.chk_hapinteract.type == "checkbox")
					{
						if (document.frm_custom.chk_hapinteract.checked == false)
						{
                    		hide("document.frm_custom.haplointvar");
                    		hide("document.frm_custom.haplointmodel");
                    	}
                   	}
                }');

    cat('
            // End -->
            </script>
            <body bgcolor="#F5F5FF" topmargin=0 leftmargin=0 onLoad="JavaScript:hideInteractionVars();">
               <table width=800 bgcolor="#F5F5FF">
                  <form name="frm_custom" method="post" action="analyzer.php" enctype="multipart/form-data">
                    <tr>
                        <td colspan=2 valign="middle" bgcolor="#FF9900">
                            <center><font size="5" face="Verdana, Arial, Helvetica, sans-serif">Step 3: Analysis customization</font></center>
                        </td>
                    </tr>
                    <tr>
                        <td colspan=2>
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>
                                In this section you can decide what kind of analysis you want to perform with your data.
                                Please choose among the following:<br><br>
                            </font>
                        </td>
                    </tr>
                    <tr bgcolor="#00BB00">
                        <td colspan=2>');
    if (covdesc==1)
    {
        cat('                   <input type="checkbox" name="chk_descr_covdesc" value="yes" checked>');
    }
    else
    {
        cat('                   <input type="checkbox" name="chk_descr_covdesc" value="yes">');
    }
    cat('
                            <font color="#FFFFFF" size="3" face="Verdana, Arial, Helvetica, sans-serif">
                                <b>Descriptive statistics</b>
                            </font>
                        </td>
                    </tr>
                    <tr bgcolor="#00BB00">
                        <td colspan=2>
                            <input type="checkbox" name="chkSNP" value="yes" onClick="JavaScript:changeSNP();">
                            <font color="#FFFFFF" size="3" face="Verdana, Arial, Helvetica, sans-serif">
                                <b>Single-SNP analysis</b>
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td width=10></td><td>');
    if (allfreq==1)
    {
        cat('               <input type="checkbox" name="chk_descr_allfreq" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_descr_allfreq" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                Allele frequencies
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td width=10></td><td>');
    if (genofreq==1)
    {
        cat('               <input type="checkbox" name="chk_descr_genofreq" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_descr_genofreq" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                Genotype frequencies
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td width=10></td><td>');
    if (hweq==1)
    {
        cat('               <input type="checkbox" name="chk_descr_hweq" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_descr_hweq" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                Hardy-Weinberg equilibrium
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td width=10></td><td>');
    if (snpassoc==1)
    {
        cat('               <input type="checkbox" name="chk_snpassoc" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_snpassoc" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                SNP association with response
                            </font>
                        </td>
                    </tr>');

    if ((length(type[(type=="snp") & (discard==0)])>=1) & (length(type[type=="ccov"])>=1))
    {
        cat('       <tr>
                        <td width=10></td>
                        <td>');
        if (interact==1)
        {
            cat('           <input type="checkbox" name="interact" value="yes" checked onClick="JavaScript:ctrlInteractionVars(this.checked)">');
        }
        else
        {
            cat('           <input type="checkbox" name="interact" value="yes" onClick="JavaScript:ctrlInteractionVars(this.checked)">');
        }
        cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                Check for interactions between SNP\'s and covariate
                            </font>
                            <select name="intvar1">');

		if (exists("intvar1.name"))
		{
			if (intvar1.name=="allsnps")
			{
				cat('<option value="allsnps" selected>All SNP\'s');
			}
			else
			{
				cat('<option value="allsnps">All SNP\'s');
			}
		}
		else
		{
			cat('<option value="allsnps">All SNP\'s');
		}

		i <- 1;
		while (i <= length(type))
		{
			if (type[i]=="snp")
            {
                if (exists("intvar1.name"))
                {
                    if (names(m)[i]==intvar1.name)
                    {
                        cat('       <option value="',names(m)[i],'" selected>',names(m)[i],sep="");
                    }
                    else
                    {
                        cat('       <option value="',names(m)[i],'">',names(m)[i],sep="");
                    }
                }
                else
                {
                    cat('           <option value="',names(m)[i],'">',names(m)[i],sep="");
                }
            }
            i <- i + 1;
        }
        cat('               </select>');
        cat('&nbsp');
        cat('               <select name="intvar2">');
        i <- 1;
        while (i <= length(type))
        {
            if (type[i]=="ccov")
            {
                if (exists("intvar2.name"))
                {
                    if (names(m)[i]==intvar2.name)
                    {
                        cat('       <option value="',names(m)[i],'" selected>',names(m)[i],sep="");
                    }
                    else
                    {
                        cat('       <option value="',names(m)[i],'">',names(m)[i],sep="");
                    }
                }
                else
                {
                    cat('           <option value="',names(m)[i],'">',names(m)[i],sep="");
                }
            }
            i <- i + 1;
        }
        cat('               </select>');
        cat('&nbsp');
        #We also allow the user to choose the inheritance model of the SNP(s) for the interaction
        if (exists("intmodel"))
        {
	        cat('           <select name="intmodel">');
	        if (intmodel=="cod")
	        {
	        	cat('           <option value="cod" selected>Codominant');
	       	}
	       	else
	       	{
	        	cat('           <option value="cod">Codominant');
	       	}

			if (intmodel=="dom")
			{
	            cat('           <option value="dom" selected>Dominant');
			}
			else
			{
	            cat('           <option value="dom">Dominant');
			}

			if (intmodel=="rec")
			{
	            cat('           <option value="rec" selected>Recessive');
			}
			else
			{
	            cat('           <option value="rec">Recessive');
			}

			if (intmodel=="over")
			{
	            cat('           <option value="over" selected>Overdominant');
			}
			else
			{
	            cat('           <option value="over">Overdominant');
			}

			if (intmodel=="ad")
			{
	            cat('           <option value="ad" selected>Log-additive');
			}
			else
			{
	            cat('           <option value="ad">Log-Additive');
			}
	        cat('           </select>');
		}
		else
		{
	        cat('           <select name="intmodel">');
	       	cat('               <option value="cod">Codominant');
	        cat('               <option value="dom">Dominant');
	        cat('               <option value="rec">Recessive');
	        cat('               <option value="over">Overdominant');
	        cat('               <option value="ad">Log-additive');
	        cat('           </select>');
		}
		cat('           </td>
                    </tr>');
    }
    else
    {
        cat('       <tr>
						<td colspan=2>
							<input type="hidden" name="interact" value="no">
						</td>
					</tr>');
    }

    cat('           <tr>
                        <td width=10></td>
                        <td nowrap>
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                 For descriptive statistics and SNP analysis, perform analysis on subpopulations? (only applies if response is categorical)
                            </font>');
    if (subpop==0)
    {
        cat('                   <input type="radio" name="subpop" value="yes">
                                <font size="2" face="Verdana, Arial, Helvetica, sans-serif">Yes</font>
                                <input type="radio" name="subpop" value="no" checked>
                                <font size="2" face="Verdana, Arial, Helvetica, sans-serif">No</font>');
    }
    else
    {
        cat('                   <input type="radio" name="subpop" value="yes" checked>
                                <font size="2" face="Verdana, Arial, Helvetica, sans-serif">Yes</font>
                                <input type="radio" name="subpop" value="no">
                                <font size="2" face="Verdana, Arial, Helvetica, sans-serif">No</font>');
    }
    cat('
                        </td>
                    </tr>
                    <tr bgcolor="#00BB00">
                        <td colspan=2>
                            <input type="checkbox" name="chkmultiple" value="yes" onClick="JavaScript:changemultiple();">
                            <font color="#FFFFFF" size="3" face="Verdana, Arial, Helvetica, sans-serif">
                                <b>Multiple-SNP analysis</b>
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td width=10></td>
                            <td>
                                <input type="checkbox" name="chkLD" value="yes" onClick="JavaScript:changeLD();">
                                <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                    Linkage disequilibrium (statistics:
                                </font>');
    if (ldd==1)
    {
        cat('               <input type="checkbox" name="chk_descr_ldd" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_descr_ldd" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                D
                            </font>');

    if (lddp==1)
    {
        cat('               <input type="checkbox" name="chk_descr_lddp" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_descr_lddp" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                D\'
                            </font>');

    if (ldr==1)
    {
        cat('               <input type="checkbox" name="chk_descr_ldr" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_descr_ldr" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                r
                            </font>');

    if (ldpval==1)
    {
        cat('               <input type="checkbox" name="chk_descr_ldpval" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_descr_ldpval" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                P-values)
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td width=10></td>
                        <td nowrap>');
    if (haplofreq==1)
    {
        cat('               <input type="checkbox" name="chk_descr_haplofreq" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="chk_descr_haplofreq" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                Haplotype frequencies estimation -> Frequency threshold for rare haplotypes:
                            </font>
                            <input type="text" name="txt_haplofreqmin" align="right" size=6 value="',haplo.freqmin,'">',sep="");
    cat('               </td>
                    </tr>
                    <tr>
                        <td width=10></td>
                        <td>');
    if (hapassoc==1)
    {
        cat('               <input type="checkbox" name="hapassoc" value="yes" checked>');
    }
    else
    {
        cat('               <input type="checkbox" name="hapassoc" value="yes">');
    }
    cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                Haplotype association with response
                            </font>
                        </td>
                    </tr>');
                    
    if ((length(type[(type=="snp") & (discard==0)])>=2) & (length(type[type=="ccov"])>=1))
    {
        cat('       <tr>
                        <td width=10></td>
                        <td>');
        if (exists("haplo.interact"))
        {
            if (haplo.interact==1)
            {
                cat('               <input type="checkbox" name="chk_hapinteract" value="yes" checked onClick="JavaScript:ctrlHaploInteractionVar(this.checked)">');
            }
            else
            {
                cat('               <input type="checkbox" name="chk_hapinteract" value="yes" onClick="JavaScript:ctrlHaploInteractionVar(this.checked)">');
            }
        }
        else
        {
            cat('               <input type="checkbox" name="chk_hapinteract" value="yes" onClick="JavaScript:ctrlHaploInteractionVar(this.checked)">');
        }
        cat('
                            <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                                Check for interactions between haplotypes and covariate (currently only additive model working)
                            </font>
                            <select name="haplointvar">');

        i <- 1;
        while (i <= length(type))
		{
			if (type[i]=="ccov")
			{
				if (exists("hap.intvar.name"))
                {
                    if (names(m)[i]==hap.intvar.name)
                    {
                        cat('       <option value="',names(m)[i],'" selected>',names(m)[i],sep="");
                    }
                    else
                    {
                        cat('       <option value="',names(m)[i],'">',names(m)[i],sep="");
                    }
                }
                else
                {
                    cat('           <option value="',names(m)[i],'">',names(m)[i],sep="");
                }
            }
			i <- i + 1;
		}
        cat('               </select>');

		if (exists("hap.int.model"))
		{
			cat('       <select name="haplointmodel">');
			if (hap.int.model=="ad")
			{
				cat('       <option value="additive" selected>Log-additive');
			}
			else
			{
				cat('       <option value="additive">Log-additive');
			}
			if (hap.int.model=="dom")
			{
				cat('       <option value="dominant" selected>Dominant');
			}
			else
			{
				cat('       <option value="dominant">Dominant');
			}
			if (hap.int.model=="rec")
			{
				cat('       <option value="recessive" selected>Recessive');
			}
			else
			{
				cat('       <option value="recessive">Recessive');
			}
			cat('       </select>');
		}
		else
		{
			cat('       <select name="haplointmodel">
							<option value="additive" selected>Log-additive
							<option value="dominant">Dominant
							<option value="recessive">Recessive
						</select>');
		}

        cat('
                        </td>
                    </tr>');
    }
    else
    {
        cat('       <tr>
						<td colspan=2>
							<input type="hidden" name="chk_hapinteract" value="no">
						</td>
					</tr>');
    }

    cat('<tr><td colspan=2>');

    cat('<input type="hidden" name="tmp" value="',tmp,'">', sep="");

    cat('</form>');

    cat('<form name="frm_custom_bck" method="post" action="gen_preproc.php" enctype="multipart/form-data">');
    cat('<input type="hidden" name="tmp" value="',tmp,'">',sep="");
    cat('</form>');

 cat('<font size="2" face="Verdana, Arial, Helvetica, sans-serif">');
 cat('<br><br>Processing will stop at 10min computing time. Please select required analyses carefully to avoid failures.<br><br>');
 cat('</font>');

    cat('<input type="submit" onClick="JavaScript:document.frm_custom_bck.submit();" value="<<< Step 2: Data preprocessing">');
    cat('<input type="button" onClick="JavaScript:ErrControl();" value="Get my results! >>>">');
    cat('</td></tr>')
    cat('</table>');
    cat('</body>');
    cat('</html>');
    sink();
}

generate.custom.page();
save.image(paste(tmp.files.path,tmp,"/.RData",sep=""));