<?php
include("paths.inc");


// VM capture error tmp not set => send to start page
$tmp_hash = isset($_POST["tmp"])?$_POST["tmp"]:"";
if ($tmp_hash == "") {
    echo "Some problem ocurred :( restarting ...";
    header('Refresh: 2; url=https://www.snpstats.net/start.htm?');
    exit;
}

$session_path_htdocs = $tmp_html_files_path . "/" . $_POST["tmp"] . "/";
$tmp_script = $tmp_script_files_path . "/" . $_POST["tmp"] . "/snp.R";
$f = fopen($tmp_script,"wb");

fwrite($f,"load(\"${tmp_script_files_path}/${_POST["tmp"]}/.RData\")\n");
fwrite($f,"tmp <- \"${_POST["tmp"]}\"\n");
fwrite($f,"docroot <- \"${_SERVER['DOCUMENT_ROOT']}\"\n");
fwrite($f,"log.path <- \"${log_path}\"\n");


if (isset($_POST["chk_descr_covdesc"]) && $_POST["chk_descr_covdesc"]=="yes")
{
	fwrite($f,"descr.covdesc <- 1\n");
}
else
{
	fwrite($f,"descr.covdesc <- 0\n");
}

if (isset($_POST["chk_descr_allfreq"]) && $_POST["chk_descr_allfreq"]=="yes")
{
	fwrite($f,"descr.allfreq <- 1\n");
}
else
{
	fwrite($f,"descr.allfreq <- 0\n");
}

if (isset($_POST["chk_descr_genofreq"]) && $_POST["chk_descr_genofreq"]=="yes")
{
	fwrite($f,"descr.genofreq <- 1\n");
}
else
{
	fwrite($f,"descr.genofreq <- 0\n");
}

if (isset($_POST["chk_descr_hweq"]) && $_POST["chk_descr_hweq"]=="yes")
{
	fwrite($f,"descr.hweq <- 1\n");
}
else
{
	fwrite($f,"descr.hweq <- 0\n");
}

if (isset($_POST["chk_snpassoc"]) && $_POST["chk_snpassoc"]=="yes")
{
	fwrite($f,"descr.snpassoc <- 1\n");
}
else
{
	fwrite($f,"descr.snpassoc <- 0\n");
}

if (isset($_POST["chk_descr_ldd"]) && $_POST["chk_descr_ldd"]=="yes")
{
	fwrite($f,"descr.ldd <- 1\n");
}
else
{
	fwrite($f,"descr.ldd <- 0\n");
}

if (isset($_POST["chk_descr_lddp"]) && $_POST["chk_descr_lddp"]=="yes")
{
	fwrite($f,"descr.lddp <- 1\n");
}
else
{
	fwrite($f,"descr.lddp <- 0\n");
}

if (isset($_POST["chk_descr_ldr"]) && $_POST["chk_descr_ldr"]=="yes")
{
	fwrite($f,"descr.ldr <- 1\n");
}
else
{
	fwrite($f,"descr.ldr <- 0\n");
}

if (isset($_POST["chk_descr_ldpval"]) && $_POST["chk_descr_ldpval"]=="yes")
{
	fwrite($f,"descr.ldpval <- 1\n");
}
else
{
	fwrite($f,"descr.ldpval <- 0\n");
}

if (isset($_POST["subpop"]) && $_POST["subpop"]=="yes")
{
	fwrite($f,"descr.subpop <- 1\n");
}
else
{
	fwrite($f,"descr.subpop <- 0\n");
}

if (isset($_POST["hapassoc"]) && $_POST["hapassoc"]=="yes")
{
	fwrite($f,"assoc <- 1\n");
}
else
{
	fwrite($f,"assoc <- 0\n");
}

if (isset($_POST["chk_descr_haplofreq"]) && $_POST["chk_descr_haplofreq"]=="yes")
{
	fwrite($f,"descr.haplofreq <- 1\n");
    if (is_numeric($_POST["txt_haplofreqmin"]))
    {
		fwrite($f,"haplo.freqmin <- ${_POST["txt_haplofreqmin"]}\n");
    }
    else
    {
		fwrite($f,"haplo.freqmin <- 0.01\n");
    }
}
else
{
	fwrite($f,"descr.haplofreq <- 0\n");
}

if (isset($_POST["interact"]) && $_POST["interact"]=="yes")
{
	fwrite($f,"interact <- 1\n");
	fwrite($f,"intvar1.name <- \"${_POST["intvar1"]}\"\n");
	fwrite($f,"intvar2.name <- \"${_POST["intvar2"]}\"\n");
	fwrite($f,"intmodel <- \"${_POST["intmodel"]}\"\n");
}
else
{
	fwrite($f,"interact <- 0\n");
}

if (isset($_POST["chk_hapinteract"]) && $_POST["chk_hapinteract"]=="yes")
{
	fwrite($f,"hap.interact <- 1\n");
	fwrite($f,"hap.intvar.name <- \"${_POST["haplointvar"]}\"\n");
	fwrite($f,"hap.int.model <- \"${_POST["haplointmodel"]}\"\n");
}
else
{
	fwrite($f,"hap.interact <- 0\n");
}

//Now we copy the remaining part of the script
$fscript = fopen ($cgi_bin_path . 'snp.R', "r");
while (!feof ($fscript)) 
{
	$buffer = fgets($fscript); //Omitting line length
	fwrite($f,$buffer);
}
fclose($fscript);
fclose($f);

// VM161212 capture errors to log file
exec($rcall . " --no-save --no-restore --silent < " . $tmp_script . " 2>> " . $log_path . "snpstats_R_err");

//We delete temp files (R script and data)
//@unlink($tmp_script);

include($_SERVER['DOCUMENT_ROOT'] . "/". $session_path_htdocs . "snp.html");
//Once sent to the user, we also delete the results file
//@unlink($_SERVER['DOCUMENT_ROOT'] . "/snpstats/tmp/" . $_POST["tmp"] . "/snp.html");
?>
