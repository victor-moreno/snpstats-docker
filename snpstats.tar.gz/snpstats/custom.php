<?php
include("paths.inc");
//We have two temp paths: one for the html pages (doc_root/snpstats/tmp/xxx) and other for the scripts and data (/tmp/snpstats/xxx)


// VM capture error tmp not set => send to start page
$tmp_hash = isset($_POST["tmp"])?$_POST["tmp"]:"";
if ($tmp_hash == "") {
    echo "Some problem ocurred :( restarting ...";
    header('Refresh: 2; url=start.htm');
    exit;
    }

$session_path = $tmp_script_files_path . "/" . $_POST["tmp"] . "/";
$session_path_htdocs = $tmp_html_files_path . "/" . $_POST["tmp"] . "/";

$tmp_custom_script = $session_path . "custom.R";

$f = fopen($tmp_custom_script,"wb");

//We only do this if we are going forwards (var "back" is set in the results page by snp.R)
if (!isset($_POST["back"])) 
{
	fwrite($f,"load(\"${tmp_script_files_path}/${_POST["tmp"]}/.RData\")\n");
	fwrite($f,"covdesc <- 0\n");
	fwrite($f,"allfreq <- 0\n");
	fwrite($f,"genofreq <- 0\n");
	fwrite($f,"hweq <- 0\n");
	fwrite($f,"snpassoc <- 0\n");
	fwrite($f,"ldd <- 0\n");
	fwrite($f,"lddp <- 0\n");
	fwrite($f,"ldr <- 0\n");
	fwrite($f,"ldpval <- 0\n");
	fwrite($f,"haplofreq <- 0\n");
	fwrite($f,"haplo.freqmin <- 0.01\n");
	fwrite($f,"hapassoc <- 0\n");
	fwrite($f,"interact <- 0\n");
	fwrite($f,"subpop <- 1\n");

	$i = 1;

	$type = "";
    $discard = "";

    while ($i <= $_POST["numcols"])
    {
        if (count($_POST["discard"])>0)
        {
            if (in_array($i,$_POST["discard"]))
            {
                $discard = $discard . "0,";
            }          
            else
            {
                $discard = $discard . "1,";
            }
        }
        else
        {
            $discard = $discard . "1,";
        }

        $type = $type . '"' . $_POST['s' . $i] . '"' . ",";

        $refcat = "";
        $j = 0;
        $numchars = 0;

		fwrite($f, "refcat${i} <- NULL\n");

        while ($j<count($_POST['c'. $i]))
        {
            if ($numchars>500) //R has a maximum of 1024 characters for a single-line command. We cut it at ~500 chars
            {
            	$refcat = $refcat . $_POST['c'. $i][$j] . ",";
            	$refcat = "c(refcat" . $i ."," . substr($refcat,0,strlen($refcat)-1) . ")";
            	fwrite($f, "refcat${i} <- ${refcat}\n");
            	$refcat="";
            	$numchars=0;
            }
            else
            {
                $refcat = $refcat . $_POST['c'. $i][$j] . ",";
                $numchars = strlen($refcat);
            }
            $j++;
        }
        if ($refcat!="")
        {
            $refcat = "c(refcat" . $i ."," . substr($refcat,0,strlen($refcat)-1) . ")";
            fwrite($f, "refcat${i} <- ${refcat}\n");
        }
        $i++;
    }

    $type = "c(" . substr($type,0,strlen($type)-1) . ")";
    $discard = "c(" . substr($discard,0,strlen($discard)-1) . ")";

    //$type = str_replace('ccov','\"ccov\"',$type);
    //$type = str_replace('qcov','\"qcov\"',$type);
    //$type = str_replace('snp','\"snp\"',$type);
    //$type = str_replace('status','\"status\"',$type);

    fwrite($f, "discard <- ${discard}\n");
    //$aux = addslashes($type);
    fwrite($f, "type <- " . $type . "\n");

	$ip = isset($_SERVER["REMOTE_HOST"]) ? $_SERVER["REMOTE_HOST"] : @gethostbyaddr($_SERVER["REMOTE_ADDR"]);
	fwrite($f,"ip <- \"${ip}\"\n");
}
else
{
	fwrite($f,"load(\"${tmp_script_files_path}/${_POST["tmp"]}/.RData\")\n");

	$aux = trim($_POST["descr_covdesc"]);
	fwrite($f,"covdesc <- ${aux}\n");

	$aux = trim($_POST["descr_allfreq"]);
	fwrite($f,"allfreq <- ${aux}\n");

	$aux = trim($_POST["descr_genofreq"]);
	fwrite($f,"genofreq <- ${aux}\n");

	$aux = trim($_POST["descr_hweq"]);
	fwrite($f,"hweq <- ${aux}\n");

	$aux = trim($_POST["descr_snpassoc"]);
	fwrite($f,"snpassoc <- ${aux}\n");

	$aux = trim($_POST["descr_ldd"]);
	fwrite($f,"ldd <- ${aux}\n");

	$aux = trim($_POST["descr_lddp"]);
	fwrite($f,"lddp <- ${aux}\n");

	$aux = trim($_POST["descr_ldr"]);
	fwrite($f,"ldr <- ${aux}\n");

	$aux = trim($_POST["descr_ldpval"]);
	fwrite($f,"ldpval <- ${aux}\n");

	$aux = trim($_POST["descr_haplofreq"]);
	fwrite($f,"haplofreq <- ${aux}\n");

	$aux = trim($_POST["haplo_freqmin"]);
	fwrite($f,"haplo.freqmin <- ${aux}\n");

	$aux = trim($_POST["assoc"]);
	fwrite($f,"hapassoc <- ${aux}\n");

	$aux = trim($_POST["descr_subpop"]);
	fwrite($f,"subpop <- ${aux}\n");

	$aux = trim($_POST["interact"]);
	fwrite($f,"interact <- ${aux}\n");

	$aux = trim($_POST["haplointeract"]);
	fwrite($f,"haplo.interact <- ${aux}\n");

    if (isset($_POST["intvar1"]))
    {
		$aux = trim($_POST["intvar1"]);
		fwrite($f,"intvar1.name <- ${aux}\n");

		$aux = trim($_POST["intvar2"]);
		fwrite($f,"intvar2.name <- ${aux}\n");
    }

    if (isset($_POST["hapintvarname"]))
    {
		$aux = trim($_POST["hapintvarname"]);
		fwrite($f,"hap.intvar.name <- ${aux}\n");
    }

	$ip = isset($_SERVER["REMOTE_HOST"]) ? $_SERVER["REMOTE_HOST"] : @gethostbyaddr($_SERVER["REMOTE_ADDR"]);
	fwrite($f,"ip <- \"${ip}\"\n");

	fwrite($f,"save.image(\"${tmp_script_files_path}/${_POST["tmp"]}/.RData\")\n");
}

//Now we copy the remaining part of the script
$fscript = fopen ($cgi_bin_path . 'custom.R', "r");
while (!feof ($fscript)) 
{
	$buffer = fgets($fscript); //Omitting line length
	fwrite($f,$buffer);
}
fclose($fscript);
fclose($f);

//VM 161212 capture errors to log
exec($rcall . " --no-save --no-restore --silent < " . $tmp_custom_script . " 2>> " . $log_path . "snpstats_R_err");

include($_SERVER['DOCUMENT_ROOT'] . "/" . $session_path_htdocs . "custom.html");

//We delete temp files (R script, HTML customization file-generated with R)
@unlink($tmp_script_files_path . "custom.R"); //Strange (though irrelevant) bug: do not know why this happens
//@unlink($_SERVER['DOCUMENT_ROOT'] . "/snpstats/" . $session_path_htdocs . "custom.html");

?>