<?php

if ( isset($_FILES["snp_file"]) || isset($_POST["txtsnps"]))
{
if ($_FILES["snp_file"]["tmp_name"]=="")
{
    if (trim($_POST["txtsnps"])=="")
    {
        echo '<center><font color="#FF0000"><b>Fatal error:</b> No data found. Please upload a file with your SNPs or paste your data in the textbox below.</font></center>';
        include('start.htm');
        return NULL;
    }
}
} else {
        echo '<center><font color="#FF0000"><b>Fatal error:</b> No data found. Please upload a file with your SNPs or paste your data in the textbox below.</font></center>';
        include('start.htm');
        return NULL;
}

//We generate random string for the temporary files
include('functions.php');
include('paths.inc');
$tmp = str_rand(15);

//We have two temp paths: one for the html pages (doc_root/snpstats/tmp/xxx) and other for the scripts and data (/tmp/snpstats/xxx)
$session_path = "$tmp_script_files_path/$tmp/";
$session_path_htdocs = "$tmp_html_files_path/$tmp/";

//We create a new directory for storing temp pages and data
$oldumask = umask(0);
mkdir($session_path, 0750);
mkdir($session_path_htdocs, 0750);
umask($oldumask);

if ($_FILES["snp_file"]["tmp_name"]!="")
{
    copy($_FILES["snp_file"]["tmp_name"],$session_path . "orig_data.txt");
}
else
{
    if (!$fhandler = fopen($session_path . "orig_data.txt", 'a'))
    {
        echo '<b>Fatal error:</b> error creating temporary file, please try again. If problems persist contact the <a href="mailto:x.sole@ico.scs.es">webmaster</a>.';
        return NULL;
    }

    if (!fwrite($fhandler, trim($_POST["txtsnps"])))
    {
        echo '<b>Fatal error:</b> error writing temporary file, please try again. If problems persist contact the <a href="mailto:x.sole@ico.scs.es">webmaster</a>.';
        return NULL;
    }

    fclose($fhandler);
}

//First we perform data preprocessing
$tmp_preproc_script = $session_path . "preproc.R";

$f = fopen($tmp_preproc_script,"wb");

fwrite($f,"os <- \"${os}\"\n");
fwrite($f,"tmp <- \"${tmp}\"\n");
fwrite($f,"tmp.files.path <- \"${tmp_script_files_path}/\"\n");
fwrite($f,"tmp.html.path <- \"${tmp_html_files_path}/\"\n");
fwrite($f,"docroot <- \"${_SERVER['DOCUMENT_ROOT']}\"\n");
fwrite($f,"file.name <- \"{$_FILES['snp_file']['name']}\"\n");
fwrite($f,"read.data <- TRUE\n");

if ($_POST["delimiter"]=="tab")
{
	fwrite($f,"delim <- \"tab\"\n");
}

if ($_POST["delimiter"]=="space")
{
	fwrite($f,"delim <- \"sp\"\n");
}

if ($_POST["delimiter"]=="semicol")
{
	fwrite($f,"delim <- \"semicol\"\n");
}

if ($_POST["header"]=="yes")
{
	fwrite($f,"header <- TRUE\n");
}
else
{
	fwrite($f,"header <- FALSE\n");
}

if (trim($_POST["txt_miss"])!="")
{
	$aux = trim($_POST["txt_miss"]);
	fwrite($f,"na.string <- \"$aux\"\n");
}
else
{
	fwrite($f,"na.string <- \"NA\"\n");
}

if ($_POST["dec"]=="comma")
{
	fwrite($f,"dec <-\",\"\n");
}
else //If anything is chosen the default value for the decimal separator is the dot "."
{
	fwrite($f,"dec <-\".\"\n");
}


//Now we copy the remaining part of the script
$fscript = fopen ($cgi_bin_path . 'preproc.R', "r");
while (!feof ($fscript)) 
{
	$buffer = fgets($fscript); //Omitting line length
	fwrite($f,$buffer);
}
fclose($fscript);
fclose($f);

// VM 161212 capture errors to log
exec($rcall . " --no-save --no-restore --silent < " . $tmp_preproc_script . " 2>> " . $log_path . "snpstats_R_err");

if (file_exists( $session_path_htdocs . "preproc.html"))
{
   include($session_path_htdocs . "preproc.html");
}
else
{
    echo '<center><font color="#FF0000"><b>Fatal error:</b> Preprocessing failed. Please check the consistency of your data file.</font></center>';
    include('start.htm');
    return NULL;
}
//We delete temp files (R script, data file and HTML preprocessing file-generated with R)
//@unlink($tmp_preproc_script);
//@unlink($session_path . "orig_data.txt");
//@unlink($_SERVER['DOCUMENT_ROOT'] . "/snpstats/" . $session_path_htdocs . "preproc.html");
?>
