<?php
include("paths.inc");
include('functions.php');

// capture cases tmp folder not set
$tmp_hash = isset($_POST["tmp"])?$_POST["tmp"]:"";
if ($tmp_hash == "") {
    echo "Some problem ocurred :( restarting ...";
    header('Refresh: 2; url=start.htm');
    exit;
}

$session_path_htdocs = $tmp_html_files_path . "/"  . $_POST["tmp"] . "/";
//We create the R script
$tmp_script = $tmp_script_files_path."/" . $_POST["tmp"] . "/" . str_rand() . ".R";

$f = fopen($tmp_script,"wb");
//We don't have to read the data matrix again
fwrite($f,"load(\"${tmp_script_files_path}/${_POST["tmp"]}/.RData\")\n");
fwrite($f,"count.snp <- 0\n");
fwrite($f,"count.var <- 0\n");
fwrite($f,"read.data <- 0\n");
fwrite($f,"save.image(\"${tmp_script_files_path}/${_POST["tmp"]}/.RData\")\n");
fwrite($f,"generate.preproc.page()");
fclose($f);

// VM 161212 capture errors to log
exec($rcall . " --no-save --no-restore --silent < " . $tmp_script . " 2>> " . $log_path . "snpstats_R_err");

include($_SERVER['DOCUMENT_ROOT'] . "/". $session_path_htdocs . "preproc.html");
//We delete temp files (R script, data file and HTML preprocessing file-generated with R)
@unlink($tmp_script);
@unlink($_SERVER['DOCUMENT_ROOT'] . "/". $session_path_htdocs . "preproc.html");
?>

