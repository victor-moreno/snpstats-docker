<?php
	$ip = isset($_SERVER["REMOTE_HOST"]) ? $_SERVER["REMOTE_HOST"] : @gethostbyaddr($_SERVER["REMOTE_ADDR"]);
	echo $ip;
?>